#!/usr/bin/python
base='INST "inst_mcs_amcs.inst_readout/%s_port.channel_procs[%i].*" AREA_GROUP = "pblock_%i";'
for i in range(0,16):
    block=1
    if i==12: block=3
    elif i>10: block=2
    print(base%("one",i,block))
for i in range(0,8):
    block=1
    if i==6: block=3
    elif i>5: block=2
    print(base%("two",i,block))
