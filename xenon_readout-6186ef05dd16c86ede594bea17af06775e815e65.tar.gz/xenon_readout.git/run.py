from os.path import join, dirname
from vunit import VUnit


root = dirname(__file__)

ui = VUnit.from_argv()
## need to compile xilinx libs first:
# > ghdl/build/lib/ghdl/vendors/compile-xilinx-ise.sh --src /Xilinx/14.7/ISE_DS/ISE/vhdl/src/ --unisim --unimacro --corelib --vhdl2008
ghdl_install = '/home/gotzl/workspace/ghdl'
ui.add_external_library('unisim', join(ghdl_install,"xilinx-ise"))
ui.add_external_library('unimacro', join(ghdl_install,"xilinx-ise"))
ui.add_external_library('xilinxcorelib', join(ghdl_install,"xilinx-ise"))

lib = ui.add_library("lib")
lib.add_source_file(join(root, "../../rtl/dspGTA/top_level_desc.vhd"))
lib.add_source_file(join(root, "../../rtl/dspGTA/G_PARAMETERS.vhd"))

lib.add_source_file(join(root, "ipcore/channel_data_fifo/channel_data_fifo.vhd"))
lib.add_source_file(join(root, "ipcore/two_port_channel_data_fifo/two_port_channel_data_fifo.vhd"))
lib.add_source_file(join(root, "ipcore/sys_time_counter/sys_time_counter.vhd"))

lib.add_source_files(join(root, "*.vhd"))
ui.set_compile_option("ghdl.flags", ["--ieee=synopsys","-frelaxed-rules"])

ui.set_sim_option("ghdl.elab_flags", ["--ieee=synopsys","-frelaxed-rules"])
ui.set_sim_option("ghdl.sim_flags", [])
ui.main()
