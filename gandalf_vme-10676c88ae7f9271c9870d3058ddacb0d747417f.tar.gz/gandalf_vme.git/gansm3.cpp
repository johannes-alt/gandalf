//============================================================================
// Name        : gansm3.cpp
// Author      : Matthias Gorzellik
//============================================================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

#include <MEN/vme4l.h>
#include <MEN/vme4l_api.h>

#define MODULE_VME_ADDR	0xe0000000
#define TIMEOUT 100000

static inline unsigned int swapbe32(unsigned int val)
{
	return (((val & 0xff000000) >> 24) | ((val & 0xff0000) >> 8) |
		((val & 0xff00) << 8) | ((val & 0xff) << 24));
}


int main(int argc, char *argv[]) {


	unsigned int val=0;
	bool error=true;

	int k, i, ret;
	int spaceFd,spaceFd_blk;

	FILE *fp1, *fp2;
	size_t flen1, flen2;
	void *wrbuf1;
	void *wrbuf2;

	char *endptr;
	int nBoards;
	int GA;
	int maxGA;
	int rightBoard=-1;
	std::string msg;

	unsigned long addr;
	unsigned long baseaddr[32];

	if(argc<4) {
		printf("gansm3 - Gandalf Configuration Tool\n");
		printf("  arg1 = bin-file of DSP FPGA\n");
		printf("  arg2 = bin-file of QDR FPGA\n");
		printf("  arg3 = Board ID in hex\n");
		exit(1);
	}

	spaceFd = VME4L_Open( VME4L_SPC_A32_D32 );
	spaceFd_blk = VME4L_Open( VME4L_SPC_A32_D32_BLT );
	if( spaceFd < 0 || spaceFd_blk < 0 ){
		printf("!ERROR:1001:cannot open VME space \n");
		exit(1);
	}

	if( (fp1=fopen(argv[1],"rb"))==NULL ) {
		printf("!ERROR:1002:cannot open file %s\n", argv[1]);
		exit(1);
	}
	if( (fp2=fopen(argv[2],"rb"))==NULL ) {
		printf("!ERROR:1002:cannot open file %s\n", argv[2]);
		exit(1);
	}

	fseek(fp1, 0, SEEK_END);
	flen1 = ftell(fp1);
	rewind(fp1);

	fseek(fp2, 0, SEEK_END);
	flen2 = ftell(fp2);
	rewind(fp2);

	flen2 += 0x2000;		// + some extra cycles


	// test the boards
	msg="Testing boards";
	nBoards = 0;
	maxGA = -1;
	for(i=3; i<argc; i++) {
		addr = MODULE_VME_ADDR + ((strtoul(argv[i],&endptr,16) & 0xff)<<16);
		ret = VME4L_Read( spaceFd , (vmeaddr_t)( addr + 0xFC) , 4 , 4 , (void *)&val , VME4L_RW_NOFLAGS );
		if( ret < 0 || ret != 4 )
			goto error;
		else {
			baseaddr[nBoards] = addr;
			val = swapbe32(val);
			GA = (val>>12) & 0x1F;
			if(GA>maxGA) {
				maxGA = GA;
				rightBoard = nBoards;
			}
			nBoards++;
		}
	}

	if(!nBoards || rightBoard==-1) {
		printf("!ERROR:1004:no boards selected\n");
		exit(1);
	}


	// reset the boards
	msg="reseting boards";
	val = 0;
	for(i=0; i<nBoards; i++) {
		ret = VME4L_Write( spaceFd , (vmeaddr_t)(baseaddr[i]+0x10), 4 , 4 , (void *)&val , VME4L_RW_NOFLAGS );
		if (ret<0 || ret !=4 )
			goto error;
	}

	// wait for init flags
	msg = "waiting for init flags";
	for(i=0, k=0; i<nBoards; k++) {
		ret = VME4L_Read( spaceFd , (vmeaddr_t)(baseaddr[i]+0xFC), 4 , 4 , (void *)&val , VME4L_RW_NOFLAGS );
		if (ret<0 || (unsigned int)ret !=4 )
			goto error;
		val = swapbe32(val);
		if((val>>29)&1) i++;	// init high
		if(k > TIMEOUT) {
			printf("!ERROR:1006:timeout while waiting on init flags\n");
			exit(1);
		}
	}

	// Allocate memory for the buffers
	if( posix_memalign((void **)&wrbuf1, 4, flen1) ||
			posix_memalign((void **)&wrbuf2, 4, flen2) ) {
		printf("!ERROR:1007:failed to allocate buffer (%s)\n", strerror(errno));
		exit(1);
	}

	fread(wrbuf1, 4, flen1/4, fp1);

	if(ferror(fp1)) {
		printf("!ERROR:1008:failed to read from file 1\n");
		exit(1);
	}

	msg = "setting request mode";
	ret = VME4L_RequesterModeSet( spaceFd_blk , 1 );
	if ( ret<0 )
		goto error;

	// write 1st file
	msg = "writing dsp file";
	ret = VME4L_Write( spaceFd_blk , (vmeaddr_t)(baseaddr[rightBoard]+0x8000), 4 , flen1 , wrbuf1 , VME4L_RW_NOFLAGS );
	if ( ret<0 || (unsigned int)ret != flen1 )
		goto error;

	// switch to 2nd FPGA
	msg="switching to mem FPGA";
	val = 0;
	for(i=0; i<nBoards; i++) {
		ret = VME4L_Write( spaceFd , (vmeaddr_t)(baseaddr[i]+0x14), 4 , 4 , (void *)&val , VME4L_RW_NOFLAGS );
		if (ret<0 || ret !=4 )
			goto error;
	}

	fread(wrbuf2, 4, flen2/4, fp2);

	if(ferror(fp2)) {
		printf("!ERROR:1008:failed to read from file 2\n");
		exit(1);
	}

	// write 2nd file
	msg = "writing mem file";
	ret = VME4L_Write( spaceFd_blk , (vmeaddr_t)(baseaddr[rightBoard]+0x8000), 4 , flen2 , wrbuf2 , VME4L_RW_NOFLAGS );
	if (ret<0 || (unsigned int)ret !=flen2 )
		goto error;

	// print status
	msg="printing status";
	for(i=0; i<nBoards; i++) {
		ret = VME4L_Read( spaceFd , (vmeaddr_t)(baseaddr[i]+0xFC), 4 , 4 , (void *)&val , VME4L_RW_NOFLAGS );
		if (ret<0 || (unsigned int)ret !=4 )
			goto error;

		val = swapbe32(val);
		if ( ((val>>28)&1)==0 ) {
			printf("!ERROR:1011:configuration of board %02x failed\n", (unsigned int)(baseaddr[i]>>16));
		}
		else {
			printf("%08x\n", val);
		}
	}

	fclose(fp1);
	fclose(fp2);

	free(wrbuf1);
	free(wrbuf2);

	// everything went well
	error=false;

error:
	if (error)
	{
		printf("!ERROR: (%s): (%s , ret= %4d)\n", strerror(errno),msg.c_str(),ret);
		VME4L_Close( spaceFd ); // try to close the handle
		VME4L_Close( spaceFd_blk ); // try to close the handle
		return EXIT_FAILURE;
	}

	ret = VME4L_Close( spaceFd );
	if (ret<0)
		goto error;
	ret = VME4L_Close( spaceFd_blk );
	if (ret<0)
		goto error;

	return EXIT_SUCCESS;
}



