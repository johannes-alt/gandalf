//============================================================================
// Name        : gandalf_status.cpp
// Author      : Matthias Gorzellik
//===========================================================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

#include <MEN/vme4l.h>
#include <MEN/vme4l_api.h>

#define MODULE_VME_ADDR	0xe0000000

static inline unsigned int swapbe32(unsigned int val)
{
	return (((val & 0xff000000) >> 24) | ((val & 0xff0000) >> 8) |
		((val & 0xff00) << 8) | ((val & 0xff) << 24));
}

struct board {
	unsigned short sn;
	unsigned char hex;
	unsigned short srcid;
	unsigned char ga;
	unsigned char init;
	unsigned short si_g;
	unsigned short si_b;
	unsigned short si_a;
	unsigned short tcs_sl;
	unsigned short reset;
	unsigned short mcsup_typ;
	unsigned short mcsdn_typ;
	unsigned char mcsup_sn;
	unsigned char mcsdn_sn;
	float temp;
	float vccint;
	float vccaux;
	unsigned short sysmon;
	unsigned short head;
};



int main(void) {


	unsigned int val=0;
	struct board slot[32];
	unsigned char lastSlot;
	bool error=true;

	int h, i, ret;
	int spaceFd;

	size_t size=4;

	memset(slot, 0, 32*sizeof(struct board));
	spaceFd = VME4L_Open( VME4L_SPC_A32_D32 );

	if( spaceFd < 0 ) {
		printf("!ERROR:1001:cannot open VME space \n");
		exit(1);
	}

//	ret = VME4L_SysReset(spaceFd);
//	if (ret<0)
//		goto error;

	i = 0;
	lastSlot = 0;
	for(h=0; h<255; h++) {
		ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0xFC) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
		if(  ret < 0 || (unsigned int)ret != size ) // handle bus error first
		{
			if (ret < 0)
				continue;
			else if ((unsigned int)ret!= size)
				goto error;
		}

		// this Gandalf is alive ! get its status

		val = swapbe32(val);
		slot[i].sn = val & 0x3FF;
		slot[i].hex = (val>>20) & 0xFF;
		slot[i].ga = (val>>12) & 0x1F;
		slot[i].init = (val>>28) & 0xF;

		// if Gandalf is initiated, get more info
		if (slot[i].init==0xf) {
			// read id
			ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2804) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
                        if (ret<0 || (unsigned int)ret!= size) goto next;
                        val = swapbe32(val);
			slot[i].srcid = val & 0x3FF;
			// request status flags
			val = swapbe32(2);
			ret = VME4L_Write( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x7058) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
			if (ret<0 || (unsigned int)ret!= size) goto next;
			// request temp info
                        val = swapbe32(2);
                        ret = VME4L_Write( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x7010) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
                        if (ret<0 || (unsigned int)ret!= size) goto next;
			 // dummy readout because of timing
                        ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x280c) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
                        if (ret<0 || (unsigned int)ret!= size) goto next;
                        val = swapbe32(val);
			
			// read status flags
			ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x280c) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
			if (ret<0 || (unsigned int)ret!= size) goto next;
			val = swapbe32(val);
			slot[i].si_g = val & 0x7;
			slot[i].si_b = (val>>4) & 0x7;
			slot[i].si_a = (val>>8) & 0x7;
			slot[i].tcs_sl = (val>>12) & 0x7;
			slot[i].reset = (val>>16) & 0x7;
			slot[i].sysmon = (val>>20) & 0x7;
			slot[i].head = (val>>24);
			// read MCS up info
			ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2000) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
			if (ret<0 || (unsigned int)ret!= size) goto next;
			val = swapbe32(val);
			slot[i].mcsup_sn = val & 0xFFF;
			slot[i].mcsup_typ = (val>>12) & 0x7;
			// read MSC down info
			ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2400) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
			if (ret<0 || (unsigned int)ret!= size) goto next;
			val = swapbe32(val);
			slot[i].mcsdn_sn = val & 0xFFF;
			slot[i].mcsdn_typ = (val>>12) & 0x7;
			 // read G temp
			ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2840) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
			if (ret<0 || (unsigned int)ret!= size) goto next;
			val = swapbe32(val);
			slot[i].temp = (( (val & 0x3FF)*503.975)/1024.0)-273.15;
			 // read G VCCAUX
                        ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2860) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
                        if (ret<0 || (unsigned int)ret!= size) goto next;
                        val = swapbe32(val);
                        slot[i].vccaux = (( (val & 0x3FF)/1024.0) * 3.0);
 			// read G VCCINT
                        ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0x2880) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
                        if (ret<0 || (unsigned int)ret!= size) goto next;
                        val = swapbe32(val);
                        slot[i].vccint = (( (val & 0x3FF)/1024.0)* 3.0);


		}

next:
		if( slot[lastSlot].ga < slot[i].ga )
			lastSlot = i;
		i++;
	}

	printf("  SN  HEX  GA  INIT SRCID  TCS_SL  SI_G  SI_A  SI_B  RESET  MCSup  MCSd   Gtemp  VCCAUX VCCINT SYSMON\n");
	printf("----------------------------------------------------------  ------------  ------ ------ ------ ------\n");
	for(i=0; i<32; i++) {
		if(slot[i].init > 0) {
			printf("%4d  %02Xh  %2d    %x", slot[i].sn, slot[i].hex, slot[i].ga, slot[i].init );
			if (slot[i].init==0xf){
				if(slot[i].head == 0xcf)
					printf("   %3d    %2d     %2d    %2d    %2d     %2d    %1d/%3d  %1d/%3d  %3.2f   %3.2f   %3.2f    %2d",slot[i].srcid, slot[i].tcs_sl, slot[i].si_g, slot[i].si_a, 
slot[i].si_b, 
slot[i].reset, slot[i].mcsup_typ, slot[i].mcsup_sn, slot[i].mcsdn_typ, slot[i].mcsdn_sn, slot[i].temp, slot[i].vccaux, slot[i].vccint, slot[i].sysmon
);
				else printf("       status word header mismatch: %03Xh", slot[i].head);
			}
			printf("\n");
		}
	}

	// everything went well
	error=false;

error:
	if (error)
	{
		printf("!ERROR: (%s)\n", strerror(errno));
		VME4L_Close( spaceFd ); // try to close the handle
		return EXIT_FAILURE;
	}

	ret = VME4L_Close( spaceFd );
	if (ret<0)
		goto error;

	return EXIT_SUCCESS;
}
