/***********************  I n c l u d e  -  F i l e  ************************
 *
 *         Name: oss_rtai_sig.h
 *
 *       Author: kp
 *        $Date: 2006/09/27 18:36:24 $
 *    $Revision: 2.5 $
 *
 *  Description: Typedefs for RTAI kernel mode signal handling
 *
 *     Switches: -
 *
 *-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_rtai_sig.h,v $
 * Revision 2.5  2006/09/27 18:36:24  ts
 * added support for Xenomai
 *
 * Revision 2.4  2005/07/07 17:50:26  cs
 * Copyright line changed
 *
 * Revision 2.3  2004/10/27 14:34:09  kp
 * adapted to RTAI 3.0
 *
 * Revision 2.2  2003/04/11 16:13:06  kp
 * changed CONFIG_RTHAL switch to MDIS_RTAI_SUPPORT
 *
 * Revision 2.1  2003/02/21 11:27:02  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/
#ifndef _OSS_RTAI_SIG_H
#define _OSS_RTAI_SIG_H

#ifdef __cplusplus
   extern "C" {
#endif

#include <linux/types.h>
#include <MEN/men_mdis_rt.h>


/*-----------------------------------------+
|  DEFINES & CONST                         |
+------------------------------------------*/
#ifdef MDIS_RTAI_SUPPORT
#define OSS_RtaiSigTaskUnregister	men_OSS_RtaiSigTaskUnregister
#define OSS_RtaiSigTaskRegister		men_OSS_RtaiSigTaskRegister
#define OSS_TaskToSigEntry			men_OSS_TaskToSigEntry

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/

# if defined(_RTAI_SCHED_H) || defined(MDIS_XENOMAI)
typedef struct {
	OSS_DL_NODE node;		/* link to next/prev OSS_RTAI_SIG_TASK 	*/
	OSS_DL_LIST sigList; 	/* installed signals list 				*/
	RT_TASK *task;			/* task that called UOS_SigInit 		*/

#ifdef MDIS_XENOMAI
	RT_QUEUE *queue;		/* message queue for that task 			*/
#else
	MBX *mbx;				/* mailbox for that task 				*/
#endif /*XENOMAI*/

	RT_TASK *sigTask;		/* signal task (null if none) 			*/
	void (*sigHandler)(u_int32 sigCode); /* users signal handler
											(null if none) */
} OSS_RTAI_SIG_TASK;

/*-----------------------------------------+
|  GLOBALS                                 |
+------------------------------------------*/

/*-----------------------------------------+
|  PROTOTYPES                              |
+------------------------------------------*/

#ifdef MDIS_XENOMAI
extern int32 OSS_RtaiSigTaskUnregister( RT_QUEUE **queueP );
extern int32 OSS_RtaiSigTaskRegister( RT_QUEUE *queue );
#else
extern int32 OSS_RtaiSigTaskUnregister( MBX **mbxP );
extern int32 OSS_RtaiSigTaskRegister( MBX *mbx );
#endif


extern OSS_RTAI_SIG_TASK *OSS_TaskToSigEntry( const RT_TASK *task );
# endif /* _RTAI_SCHED_H_ */




#endif /* MDIS_RTAI_SUPPORT */


#ifdef __cplusplus
   }
#endif
#endif /*_OSS_RTAI_SIG_H*/







