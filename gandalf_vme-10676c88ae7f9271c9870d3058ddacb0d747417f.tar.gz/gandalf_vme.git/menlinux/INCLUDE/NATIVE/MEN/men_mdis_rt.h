/***********************  I n c l u d e  -  F i l e  ************************/
/*!
 *        \file  men_mdis_rt.h
 *
 *      \author  ts
 *        $Date: 2006/11/06 19:17:51 $
 *    $Revision: 2.4 $
 *
 *	   \project  MDIS4Linux
 *       \brief  central header for classic RTAI / Xenomai dependent defines.
 *				 Avoid numerous #defines in each c file
 *
 *    \switches  CONFIG_IPIPE	From .config, to distinguish between classic 
 *								RTAI and Xenomai enabled kernel.
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: men_mdis_rt.h,v $
 * Revision 2.4  2006/11/06 19:17:51  ts
 * include all classic RTAI header files
 *
 * Revision 2.3  2006/10/26 14:16:18  ts
 * made ulldiv() dependent on XENOMAI presence
 *
 * Revision 2.2  2006/09/27 18:37:11  ts
 * use only MDIS_Xenomai as switch to decide if Xenomai support
 *
 * Revision 2.1  2006/09/26 10:07:35  ts
 * Initial Revision
 *
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2000 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/
#ifndef _MEN_RTAI_H
#define _MEN_RTAI_H

#ifdef __cplusplus
   extern "C" {
#endif

#include <linux/kernel.h>

#ifdef MDIS_XENOMAI
# include <native/types.h>
# include <native/task.h>
# include <native/alarm.h>
# include <native/event.h>
# include <native/heap.h>
# include <native/intr.h>
# include <native/mutex.h>
# include <native/pipe.h>				   
# include <native/queue.h>
# include <native/registry.h>			   
# include <native/sem.h>
# include <native/timer.h>
#else	/* classic RTAI */
# include <rtai.h>
# include <rtai_malloc.h>
# include <rtai_sem.h>
# include <rtai_mbx.h>
# include <rtai_fifos.h>
# include <rtai_proc_fs.h>
#endif

/*-----------------------------------------+
|  DEFINES & CONST                         |
+------------------------------------------*/

/*****************************************************************************/
/*                RTAI/Fusion (Xenomai) interface 
 */

#ifdef MDIS_USE_XENOMAI
# define men_rt_printk(x...) 			printk(x)
# define men_rt_malloc(size)			xnheap_alloc(&kheap,size)
# define men_rt_free(x)					rt_free(x)
# define men_rt_this()		    		rt_task_self()
# define men_rt_busy_wait(x)			rt_timer_spin(x)

/* - Memory related wrappers - */
# define rt_alloc(size)					xnheap_alloc(&kheap,size)
# define rt_free(ptr)					xnheap_free(&kheap,ptr)



/* - interrupt related wrappers - */
# define men_rt_save_cli(x)  			rt_global_save_flags_and_cli(x)


/* - Semaphore related wrappers - */
 typedef RT_SEM SEM;
# define men_rt_sem_get_immediate(semP)	rt_sem_p(semP, TM_NONBLOCK)
# define men_rt_sem_get_forever(semP)	rt_sem_p(semP, TM_INFINITE)
# define men_rt_sem_get_time(semP,t)	rt_sem_p(semP,t)
# define men_rt_sem_put(semP)			rt_sem_v(semP)
# define men_rt_sem_init(semP, val)		rt_sem_create(semP,"MDIS-XENO",\
                                        val, S_FIFO)
# define MDIS_RT_SEM_TIMEOUT			-ETIMEDOUT

/* - Time related wrappers - */
# define men_rt_ns2tick(x)				(x)	/* xenomai only uses ns */
# define men_rt_sleep(x)				rt_task_sleep(x)
# define men_cnt2nano(x)				rt_timer_ticks2ns(x)
# define men_rt_get_time(x)				rt_timer_read(x)

/* - task related wrappers - */
static inline int men_rt_task_init(RT_TASK *task,
								   void(*rt_thread)(int), 
								   int data, 
								   int stack_size, 
								   int priority, 
								   int uses_fpu, 
								   void(*signal)(void))
{

	char taskname[XNOBJECT_NAME_LEN];
	int mode = uses_fpu? T_FPU:0;

	/*
	 *	The task is left in an innocuous state until it is actually started by
	 *	rt_task_start() (From Xenomai API)
	 */

	sprintf(taskname, "MDIS_RT_TASK%08x", 
			(unsigned int)( rt_timer_read() & 0xffffffff));

	return rt_task_create( task, taskname, stack_size, priority, mode);

}



/* - Misc Stuff - */
# define DBG_Write(dbh,fmt,args...) printk( __LDL fmt, ## args )

/* mk_rtai defines */
#define MKRTAI_LOCK						rt_sem_p(&G_rtMkSem, 1e9) 
#define MKRTAI_UNLOCK					rt_sem_v(&G_rtMkSem)



/*****************************************************************************/
/*            		classic RTAI (Kilauea...) interface
 */
#else

/* - Memory related wrappers - */
# define men_rt_malloc(x) 				rt_malloc(x)
# define men_rt_free(x)					rt_free(x)

# define men_rt_busy_wait(x)			rt_busy_sleep(x) 
# define men_rt_this(x)					rt_whoami()		

# define men_rt_printk(x...) 			rt_printk(x)

/* - interrupt related wrappers - */
# define men_rt_save_cli(x)  			rt_global_save_flags_and_cli(x)

/* - Semaphore related wrappers - */
# define men_rt_sem_get_immediate(semP)	rt_sem_wait_if(semP)
# define men_rt_sem_get_forever(semP)	rt_sem_wait(semP)
# define men_rt_sem_get_time(semP,t)	rt_sem_wait_timed(semP,t)
# define men_rt_sem_put(semP)			rt_sem_signal(semP)
# define men_rt_sem_init(semP, val)		rt_typed_sem_init(semP,val,RES_SEM )
# define MDIS_RT_SEM_TIMEOUT			SEM_TIMOUT 

/* - Time related wrappers - */
# define men_rt_ns2tick(x)				nano2count(x)
# define men_rt_sleep(x)				rt_sleep(x)
# define men_cnt2nano(x)				count2nano(x)
# define men_rt_get_time(x)				rt_get_time(x)


/* - Task related wrappers - */

/* 	int rt_task_init (RT_TASK *task, void(*rt_thread)(int), int data, 
	int stack_size, int priority, int uses_fpu, void(*signal)(void)) */

#define men_rt_task_init(tsk,fnc,dat,stck,prio,fpu,sig)  \
                          rt_task_init(tsk,fnc,dat,stck,prio,fpu,sig)
	   

# define DBG_Write(dbh,fmt,args...) 	rt_printk( KERN_DEBUG fmt, ## args )



/* lock/unlock access to global MK-RTAI resources */
#define MKRTAI_LOCK						rt_sem_wait(&G_rtMkSem)
#define MKRTAI_UNLOCK					rt_sem_signal(&G_rtMkSem)


#endif

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/


/*-----------------------------------------+
|  GLOBALS                                 |
+------------------------------------------*/
/* none */

/*-----------------------------------------+
|  PROTOTYPES                              |
+------------------------------------------*/


#ifdef MDIS_XENOMAI /* rtai(kilauea) uses its own ulldiv */
/* 
 * 64bit-by-32bit division routine:
 * ULLDIV as modified by Marco Morandini (morandini@aero.polimi.it) to work 
 * with gcc-3.x.x even if the option -fnostrict-aliasing is forgotten, 
 * otherwise it does not work properly with -O2. RTAI making should enforce 
 * -fnostrict-aliasing always so it should be just in case one uses it on
 * his/her own.
 * taken from rtai-legacy.h
 */

#ifdef _BIG_ENDIAN_ /* PPC */
	#define LOW  0
	#define HIGH 1 
#else	/* x86 */
	#define LOW  1
	#define HIGH 0  
#endif

static inline unsigned long long ulldiv(unsigned long long ull, 
										unsigned long uld, unsigned long *r)
{
	unsigned long long qf, rf;
	unsigned long tq, rh;
	union { unsigned long long ull; unsigned long ul[2]; } p, q;

	p.ull = ull;
	q.ull = 0;
	rf = 0x100000000ULL - (qf = 0xFFFFFFFFUL / uld) * uld;
	while (p.ull >= uld) {
		q.ul[HIGH] += (tq = p.ul[HIGH] / uld);
		rh = p.ul[HIGH] - tq * uld;
		q.ull  += rh * qf + (tq = p.ul[LOW] / uld);
		p.ull   = rh * rf + (p.ul[LOW] - tq * uld);
	}
	*r = p.ull;
	return q.ull;
}
#endif


#ifdef __cplusplus
   }
#endif
#endif /*_MEN_RTAI_H*/

