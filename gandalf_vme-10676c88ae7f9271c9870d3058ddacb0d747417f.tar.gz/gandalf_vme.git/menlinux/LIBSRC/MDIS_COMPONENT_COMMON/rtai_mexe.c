/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  rtai_mexe.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2004/10/27 14:38:23 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  Execution environment for MDIS programs in RTAI kernel mode.
 *				 To be linked together with MDIS program
 *     Switches: -
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: rtai_mexe.c,v $
 * Revision 1.2  2004/10/27 14:38:23  kp
 * RTAI 3.0 adaption
 *
 * Revision 1.1  2003/04/11 16:26:52  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/
#include <linux/types.h>
#include <linux/module.h>
#include <linux/init.h>
#include <rtai.h>
#include <rtai_sched.h>
#include <rtai_fifos.h>
#include <rtai_sem.h>
#include <rtai_mbx.h>
#include <MEN/RTAI_STDC/stdio.h>

#include <MEN/men_typs.h>
#include <MEN/mdis_err.h>
#include <MEN/oss.h>
#include <MEN/usr_oss.h>
#include <MEN/mdis_api.h>

#include <MEN/rtagent.h>


/* timer period length in ns  */
#define TICK_PERIOD   (2 * 1000 * 1000) /* 2ms */
/* 0 is highest priority, RT_LOWEST_PRIORITY is lowest */
#define TASK_PRIORITY 10
#define AGENT_COM_TASK_PRIORITY 20
#define USES_FPU      1
#define STACK_SIZE    16384
#define FIFO_SIZE	  ((sizeof(RTA_SDB)+RTA_MAX_DATALEN)*2)

static RT_TASK rt_task0;
static RT_TASK G_agentComTask;

static int G_fifoNum=0;

int tmrMode=1;
MODULE_PARM( tmrMode, "i" );	/* RTAI timing mode  0=periodic 1=one shot */
MODULE_PARM_DESC( tmrMode, "RTAI timing mode  0=periodic 1=one shot");

static SEM G_servDoneSem;		/**< semaphore to signal MexeService   */
static SEM G_fifo1Sem;			/**< resource semaphore for mexe->agent fifo */
static SEM G_fifo0Sem;			/**< fifo event for mexe<-agent fifo */
static RTA_SDB *G_pendRspSdb;
static void *G_pendRspData;

static u_int8 G_cmdLine[RTA_MAX_DATALEN]; /**< command line for main */
static int G_cmdLineLen;
static int G_execState;		/**< exec program state: 
							   0=not initialized, 1=initialized, 2=self term.*/
RTIME tick_period;

extern int main( int argc, char **argv );

/**********************************************************************/
/** Execute service within mdis_rtagent
 * 
 * Puts service into FIFO and waits until mdis_rtagent has finished the
 * request.
 *
 * Only one service can be pending at the same time. If a second service
 * is requested while another is pending, the second must wait for the first.
 * 
 * \param reqSdb	filled service description block to be sent
 * \param reqData	optional service specific REQ data 
 *					(can be NULL if reqSdb.dataLen=0), 512 bytes max.
 * \param rspSdb	will contain response SDB from mdis_rtagent
 * \param rspData	ptr to buffer wher optional service specific RSP data
 *					will be stored (can be NULL), must have space for 512 
 *					bytes.
 * \return 0=success -1=FIFO error or bad service
 */
int MexeService( 
	const RTA_SDB *reqSdb,
	const void *reqData,
	RTA_SDB *rspSdb,
	void *rspData)
{
	int n;

	/*rt_printk("MexeService %d\n", reqSdb->service );*/

	/* claim output fifo */
	rt_sem_wait( &G_fifo1Sem );

	rspSdb->service = reqSdb->service;
	G_pendRspSdb = rspSdb;
	G_pendRspData = rspData;

	/* send sdb */
	if( (n=rtf_put( G_fifoNum+1, (void*)reqSdb, sizeof(RTA_SDB))) != 
		sizeof(RTA_SDB) ){

		rt_printk( "*** MexeService: rtf_put sdb %d\n", n);
		rt_sem_signal( &G_fifo1Sem );
		return -1;
	}
	
	/* send data */
	if( reqSdb->dataLen ){
		if( (n=rtf_put( G_fifoNum+1, (void*)reqData, reqSdb->dataLen )) != 
			reqSdb->dataLen ){

			rt_printk( "*** MexeService: rtf_put data %d\n", n);
			rt_sem_signal( &G_fifo1Sem );
			return -1;
		}
	}
	
	rt_sem_signal( &G_fifo1Sem );

	/* wait for response */
	rt_sem_wait( &G_servDoneSem );
	G_pendRspSdb = NULL;

	/*rt_printk("MexeService %d done\n", reqSdb->service );*/

	return rspSdb->u.rsp.result == RTA_OK ? 0 : -1;	
}


/**********************************************************************/
/** executes the main routine of the test program 
 *
 * This is run in context of rt_task0
 */
static void ExecProgram(int arg)
{
	int rv;
	int argc=0;
	const int maxArgc=30;
	char *argv[maxArgc];
	char *p = G_cmdLine;
	RTA_SDB reqSdb, rspSdb;

	/* build command line arguments */
	argv[argc++] = "RT-app";			/* dummy name */
	
	while( ((p-(char*)G_cmdLine) < G_cmdLineLen) && (argc<maxArgc) ){
		/*rt_printk( "argv[%d] = %s\n", argc, p );*/
		argv[argc++] = p;
		p += strlen(p) + 1;
	}

	/*--- run main ---*/
	/*rt_printk( "MEXE program activated\n" );*/
	rv = main( argc, argv );
	/*rt_printk( "MEXE program finished rv=%d\n", rv );*/

	/* tell mdis_rtagent that we're done */
	RTA_SDB_REQ( &reqSdb, RTA_DONE, 0 );
	reqSdb.u.req.param1.i = rv;
	MexeService( &reqSdb, NULL, &rspSdb, NULL );
	
	G_execState = 2;
	rt_task_suspend( rt_whoami());
}


/** communication task with RT-agent */
static void AgentCom(int arg)
{
	int err, n;
	RTA_SDB sdb;

	for(;;){
		/* wait until signalled by FifoHandler */
		rt_sem_wait( &G_fifo0Sem );
		/*rt_printk( "AgentCom awake\n" );*/
		
		while ((err = rtf_get(G_fifoNum, &sdb, sizeof(sdb))) == sizeof(sdb)) {
			if( sdb.magic != RTA_SDB_MAGIC ){
				rt_printk( "*** AgentCom: bad magic in FIFO\n");
				continue;
			}
			/*rt_printk( "got SDB: prim=%d serv=%d dlen=%d\n", 
			  sdb.primitive, sdb.service, sdb.dataLen );*/

			switch( sdb.primitive ){
			case RTA_REQ:
			{
				u_int8 result = RTA_OK;

				switch( sdb.service ){
				case RTA_START:
					/*rt_printk("RTA_START\n"); */
					if( G_execState != 1){
						if( G_execState == 2 )
							rt_task_delete(&rt_task0);

						/* wait for data */
						if( sdb.dataLen ){
							rt_sem_wait( &G_fifo0Sem );
							if( rtf_get(G_fifoNum, G_cmdLine, sdb.dataLen) !=
								sdb.dataLen ){
								rt_printk( "*** AgentCom: error waiting for "
										   "cmdLine\n");
								result = RTA_BAD_PARAMETER;
								break;
							}
						}
						/*rt_printk("RTA_START cmdLine=%s\n", G_cmdLine ); */
						G_cmdLineLen = sdb.dataLen;

						/* try with FPU enable, if failed without FPU */
						if( rt_task_init(&rt_task0, ExecProgram, 0, STACK_SIZE, 
										 TASK_PRIORITY, USES_FPU, 0) != 0 ){
							rt_printk("*** WARNING: Try to start APP without "
									  "FPU support\n");
							if( rt_task_init(&rt_task0, ExecProgram, 0, 
											 STACK_SIZE, 
											 TASK_PRIORITY, 0, 0) != 0 ){
								rt_printk("*** Could not start APP task\n");
								result = RTA_BAD_PARAMETER;
								break;								
							}
						}

						rt_task_make_periodic( &rt_task0, 
											   rt_get_time() + tick_period, 
											   tick_period);
						/*rt_task_resume( &rt_task0 );*/
						G_execState = 1;
					}
					else
						result = RTA_BAD_PARAMETER;
					break;

				case RTA_STOP:
					/*rt_printk("RTA_STOP\n"); */
					if( G_execState == 1 )
						rt_printk("*** RT-APP was killed. Resources may not "
								  "be released!\n");
					if( G_execState != 0 ){
						rt_task_delete(&rt_task0);
						G_execState = 0;
					}
					else
						result = RTA_BAD_PARAMETER;
					break;

				default:
					result = RTA_BAD_SERVICE;
					break;
				}

				/* send response */
				sdb.primitive = RTA_RSP;
				sdb.u.rsp.result = result;
				sdb.u.rsp.errNum = 0;
				sdb.u.rsp.param.u32 = 0;
				sdb.dataLen = 0;

				rt_sem_wait( &G_fifo1Sem );

				if( (n=rtf_put( G_fifoNum+1, &sdb, sizeof(sdb))) 	
					!= sizeof(sdb) ){
					rt_printk( "*** AgentCom: rtf_put %d\n", n);
				}

				rt_sem_signal( &G_fifo1Sem );

				break;
				
			}
			case RTA_RSP:
				/*rt_printk("RTA_RSP\n"); */
				if( G_pendRspSdb && G_pendRspSdb->service == sdb.service ){

					*G_pendRspSdb = sdb;

					if( sdb.dataLen && G_pendRspData ){
						/* wait for data */
						rt_sem_wait( &G_fifo0Sem );
						if( rtf_get(G_fifoNum, G_pendRspData, sdb.dataLen) !=
							sdb.dataLen ){
							rt_printk( "*** AgentCom: error waiting for "
									   "data\n");
							break;
						}
					}

					rt_sem_signal( &G_servDoneSem );
				}
				else {
					rt_printk( "*** AgentCom: response to bad service\n" );
				}
				break;

			default:
				rt_printk( "*** AgentCom: bad primitive %d\n", 
						   sdb.primitive);
				continue;
			}
		}
	}
}


/* executed in Linux kernel context! */
static int FifoHandler( unsigned int fifo, int rw )
{
	/*rt_printk( "FifoHandler %d %c\n", fifo, rw );*/

	if (rw == 'r') {
		return -EINVAL;
	}

	rt_sem_signal( &G_fifo0Sem ); /* wakeup AgentCom */

	return 0;
}

static int __init init_mexe(void)
{
	if( UOS_RtaiInit() != 0 )
		goto ABORT;

	rt_printk( "[ RTAI MEXE %s module executing in %s mode %d ]\n", 
			   COMP_NAME, tmrMode ? "oneshot" : "periodic", tmrMode);

	if( tmrMode )
		rt_set_oneshot_mode();
	else
		rt_set_periodic_mode();

    /* initializing the tasks */
    rt_task_init(&G_agentComTask, AgentCom, 0, STACK_SIZE, 
				 AGENT_COM_TASK_PRIORITY, 
				 0 /* no fpu */, 0);
    /* start timer */
    tick_period = start_rt_timer(nano2count(TICK_PERIOD));

	OSS_RtaiTimingInit( tmrMode );

	if( rtf_create( G_fifoNum+0, FIFO_SIZE ) != 0 )
		goto ABORT;
	if( rtf_create( G_fifoNum+1, FIFO_SIZE ) != 0 )
		goto ABORT;

	rt_typed_sem_init( &G_fifo0Sem, 0, CNT_SEM );
	rt_typed_sem_init( &G_fifo1Sem, 1, RES_SEM );
	rt_typed_sem_init( &G_servDoneSem, 0, BIN_SEM );

	rtf_create_handler( G_fifoNum, X_FIFO_HANDLER(FifoHandler) );

	rt_task_resume( &G_agentComTask );

    return 0;
 ABORT:
	return -1;
}

static void __exit cleanup_mexe(void)
{
	rt_printk( "[ RTAI MEXE %s module unloaded ]\n", COMP_NAME );

    /* kill task */
    rt_task_delete(&G_agentComTask);

	rtf_destroy(G_fifoNum+0);
	rtf_destroy(G_fifoNum+1);

	rt_sem_delete( &G_fifo0Sem );
	rt_sem_delete( &G_fifo1Sem );
	rt_sem_delete( &G_servDoneSem );

    /* kill timer */
    stop_rt_timer();

	UOS_RtaiExit();
}

module_init(init_mexe);
module_exit(cleanup_mexe);

