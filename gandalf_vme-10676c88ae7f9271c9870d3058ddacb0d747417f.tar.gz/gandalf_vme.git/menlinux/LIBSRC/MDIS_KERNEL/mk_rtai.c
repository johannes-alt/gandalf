/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  mk_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2011/05/23 11:51:57 $
 *    $Revision: 2.10 $
 * 
 *  	 \brief  RTAI MDIS kernel and RTAI MDIS API
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: mk_rtai.c,v $
 * Revision 2.10  2011/05/23 11:51:57  CRuff
 * R: 1. avoid irq status changes in low level device while changing bbis irq
 *       status
 * M: 1. call MK_UNLOCK() before calling MDIS_EnableIrq in MDIS_RtaiInitialOpen
 *       and MDIS_RtaiFinalClose() to avoid deadlock
 *
 * Revision 2.9  2006/12/15 12:56:44  ts
 * replaced all direct rtai calls with men_xx wrappers
 *
 * Revision 2.8  2005/01/20 13:52:55  ts
 * corrected build problem when no CONFIG_MEN_VME_KERNELIF defined
 * added lock for VME irq requests under RTAI
 *
 * Revision 2.7  2005/01/19 15:52:00  ts
 * G_rtIrqTbl[] removed, RTAI irq handling directly by sharing module, cosmetic
 *
 * Revision 2.6  06.12.2004 12:04:54 ts
 * Added RTAI support for VME
 *
 * Revision 2.5  27.10.2004 14:38:21 kp
 * RTAI 3.0 adaption
 *
 * Revision 2.4  09.06.2004 11:12:36 kp
 * replaced OSS_IrqMask with OSS_IrqMaskR
 *
 * Revision 2.3  06.06.2003 09:09:39 kp
 * changed everything for doxygen docu.
 * minor fixes in RTAI interrupt installation
 *
 * Revision 2.2  2003/04/11 16:26:29 kp
 * finalized RTAI port
 *
 * Revision 2.1  2003/02/21 13:34:46 kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#include "mk_intern.h"
#ifdef MDIS_RTAI_SUPPORT
#include <asm/irq.h>
#include <MEN/men_mdis_rt.h>   	/* all RTAI/Xenomai related stuff 	*/
#include <MEN/mdis_ers.h>   	/* MDIS error string table   		*/
# include <MEN/men_vme_kernelif.h>
#ifdef CONFIG_MEN_VME_KERNELIF
# include <MEN/vme4l.h>
#endif

/*--------------------------------------+
|   DEFINES                             |
+--------------------------------------*/
#define MKRTAI_IRQS		NR_IRQS /* max irqs supported(linux asm/irq.h) */

/* max. number of total open MDIS/RTAI paths */
#define MKRTAI_MAX_PATHS	64

#define MKRTAI_VMELOCK(__flags) __flags=rt_spin_lock_irqsave(&G_lockVme)
#define MKRTAI_VMEUNLOCK(__flags) rt_spin_unlock_irqrestore(__flags,\
															&G_lockVme)

/*--------------------------------------+
|   TYPDEFS                             |
+--------------------------------------*/
/*--------------------------------------+
|   EXTERNALS                           |
+--------------------------------------*/

/*--------------------------------------+
|   GLOBALS                             |
+--------------------------------------*/
/* 
 * global MDIS RTAI path table.
 * unused entries have a null <dev> field
 */
static MK_PATH G_rtPathTbl[MKRTAI_MAX_PATHS]; 

static SEM G_rtMkSem;	/* semaphore to lock accesses to path table etc.*/

static spinlock_t	G_lockVme; /* lock call to vme_rt functions */
/** true as long STD MDIS is modifying G_devList */
static int 	   G_devListLockFlag; 
									  

/*--------------------------------------+
|   PROTOTYPES                          |
+--------------------------------------*/

/** called by STD linux kernel when the global device list is modified */
void MDIS_RtaiSetDevListLockFlag( int flag )
{
	G_devListLockFlag = flag;
}

void MDIS_RtaiWaitForDevListLock(void)
{
	while( G_devListLockFlag )
		men_rt_sleep( 100 );		/* give STD MDIS chance to execute */
}


/******************************* SetErrno *******************************
 *
 *  Description:  Sets "errno" of the current RTAI task
 *                
 *---------------------------------------------------------------------------
 *  Input......:  err		error code to pass to errno
 *  Output.....:  -
 *  Globals....:  -
 ****************************************************************************/
static void SetErrno( int err )
{
#if 0	/* ts: TODO */
	RT_TASK *tsk = rt_whoami(); /* 'this' */
	tsk->errno = err;
#endif
} 


/******************************* MDIS_RtaiInit *******************************
 *
 *  Description:  Init the RTAI MDIS
 *                
 *  called from mk_module.c::init_module
 *---------------------------------------------------------------------------
 *  Input......:  -
 *  Output.....:  -
 *  Globals....:  -
 ****************************************************************************/
void MDIS_RtaiInit(void)
{

	memset( G_rtPathTbl, 0, sizeof(G_rtPathTbl) );
	men_rt_sem_init(&G_rtMkSem, 1);
	spin_lock_init( &G_lockVme );

}

/******************************* MDIS_RtaiExit *******************************
 *
 *  Description:  Exit from RTAI MDIS
 *                
 *  called from mk_module.c::exit_module
 *---------------------------------------------------------------------------
 *  Input......:  -
 *  Output.....:  -
 *  Globals....:  -
 ****************************************************************************/
void MDIS_RtaiExit(void)
{
	rt_sem_delete( &G_rtMkSem );
}

/******************************* MDIS_RtaiInitia lOpen ************************
 *
 *  Description:  Perform rest of initialisation of device
 *                
 *  Performs the steps that MDIS_InitialOpen() has skipped
 *---------------------------------------------------------------------------
 *  Input......:  dev	device to initialize
 *  Output.....:  returns error number
 *  Globals....:  -
 ****************************************************************************/
int32 MDIS_RtaiInitialOpen( MK_DEV *dev )
{
	int32 error;
	DBGCMD(const char fname[] = "MKRTAI:InitialOpen: ";) 
	static int _flags = 0;

	DBGWRT_1((DBH, "MDIS_RtaiInitialOpen\n"));
	/*-----------------------------------+
	|  install interrupt                 |
	+-----------------------------------*/

	DBGWRT_1((DBH, "dev->devName '%s' dev->irqUse=%08x dev->irqInfo=%08x\n", 
			  dev->devName, dev->irqUse, dev->irqInfo));

	if (dev->irqUse || (dev->irqInfo & BBIS_IRQ_EXPIRQ)){

		MKRTAI_VMELOCK(_flags);
		/* thats the very first distinction between VME/ non VME */
		if( dev->busType != OSS_BUSTYPE_VME ){
			DBGWRT_2((DBH,"%s: installing a nonVME System Interrupt\n",
					  __FUNCTION__));

			if((error = MDIS_RtaiInstallSysirq(dev)) )
				goto errexit;
		} else {
#ifdef CONFIG_MEN_VME_KERNELIF 
			/* Mind: dev->irqVector is the VME Vector here, no PIC irq. */
			DBGWRT_2((DBH,"%s: installing a VME Interrupt\n",
					  __FUNCTION__));

			error=vme_rt_request_irq( dev->irqVector,
			  (void(*)(int, void *, struct pt_regs *))MDIS_IrqHandler, 	
									  dev->devName, 
									  dev);

#endif
		}

		MKRTAI_VMEUNLOCK(_flags);
	}

	/*------------------------------+
	|  init device                  |
	+------------------------------*/
	if ((error = dev->llJumpTbl.init(dev->rtDevSpec,
									 dev->osh,
									 dev->ma,
									 dev->semDev,
									 NULL, /* irq handle */
									 &dev->ll ))) {
		dev->ll = NULL;
		DBGWRT_ERR((DBH, "*** %s: can't init device "
					"error=0x%lx\n", fname, error));
	}
	else
		dev->initialized = TRUE;

	if( dev->exceptionOccurred ){
		men_rt_printk( KERN_WARNING 
					   "*** MDIS/RTAI: %d BBIS exceptions on %s / %s during "
					   "device init. Check for correct module slot\n",
					   dev->exceptionOccurred, dev->brdName, dev->devName );
		error = ERR_BUSERR;
		goto errexit;
	}
	if( error )
		goto errexit;
		
	/*------------------------------+
	|  get nr of device channels    |
	+------------------------------*/
	if ((error = dev->llJumpTbl.getStat(dev->ll,
										M_LL_CH_NUMBER,
										0,
										(int32*)&dev->devNrChan ))) {
		DBGWRT_ERR((DBH," *** %s: can't get M_LL_CH_NUMBER\n", fname));
		goto errexit;
	}

	DBGWRT_2((DBH," device channels: %d channels\n",dev->devNrChan));

	/*------------------------------+
	|  prepare process locking      |
	+------------------------------*/
	if ((error = MDIS_InitLockMode(dev)))
		goto errexit;

	/*------------------------------+
	|  get irq enable               |
	|  enable interrupt             |
	+------------------------------*/
	if (dev->irqUse) {
		MK_UNLOCK;
		MDIS_EnableIrq(dev, dev->irqEnableKey);
		MK_LOCK(error);
	}

	return ERR_SUCCESS;

 errexit:	
	MDIS_RtaiFinalClose( dev );
	DBGWRT_ERR((DBH,"*** %s %s failed error=0x%lx\n", fname, dev->devName, 
				error ));
	return error;
	
}

/******************************** MDIS_RtaiFinalClose ************************
 *
 *  Description: Close last path to device
 *
 *  Note: Device is not fully deinitialized. We clean up here only those
 *  things that have been setup by MDIS_RtaiInitial Open
 *---------------------------------------------------------------------------
 *  Input......: dev	 device structure
 *  Output.....: return  success (0) or error code
 *  Globals....: -
 ****************************************************************************/
int32 MDIS_RtaiFinalClose( MK_DEV *dev )
{
    int32 error;     /* error holder */
	static int _flags=0;
    DBGWRT_2((DBH,"MKRTAI:FinalClose: device=%s\n", dev->devName));

	if( dev == NULL ) return ERR_SUCCESS;

	/*------------------------------+
	|  de-init device               |
	+------------------------------*/
	/* disable irqs (if installed), ignore error */
	if (dev->irqUse) {
		MK_UNLOCK;
		MDIS_EnableIrq( dev, FALSE );
		MK_LOCK(error);
	}
	dev->initialized = FALSE;

	/* de-init device */
#ifdef DBG
	if( dev->ll ) DBGWRT_2((DBH,"de-init dev\n"));
#endif
	if (dev->ll && (error = dev->llJumpTbl.exit(&dev->ll ))) {
		DBGWRT_ERR((DBH," *** FinalClose: device exit failed\n"));
	}

	/*------------------------------+
	|  Terminate process locking    |
	+------------------------------*/
	MDIS_TermLockMode( dev );

	/*------------------------------+
	|  cleanup interrupt            |
	+------------------------------*/
	DBGWRT_2((DBH," irq installed: %d\n", dev->irqInstalled ));

	if( dev->busType != OSS_BUSTYPE_VME )
		MDIS_RtaiRemoveSysirq( dev );
	else{ /* VME IRQs are maintained by bridge driver. remove IRQ from list */
#ifdef CONFIG_MEN_VME_KERNELIF
		MKRTAI_VMELOCK(_flags);	
		vme_rt_free_irq(dev->irqVector, dev );
		MKRTAI_VMEUNLOCK(_flags);
#endif
	}

    return(ERR_SUCCESS);
}




/******************************* MDIS_RtaiInstallSysirq *********************
 *
 *  Description: Install & enable the (non VME) system interrupt
 *			   
 *---------------------------------------------------------------------------
 *  Input......: dev 	 device structure
 *  Output.....: return  success (0) or error code
 *  Globals....: 
 ****************************************************************************/
int32 MDIS_RtaiInstallSysirq(MK_DEV *dev)
{

	OSS_IRQ_STATE state;

	if( dev->irqVector >= MKRTAI_IRQS ){
		DBGWRT_ERR((DBH," *** RTAI: InstallSysirq: irq %d out of limit. ",
					dev->irqVector ));
		return(ERR_MK_IRQ_INSTALL);
	}

	state = OSS_IrqMaskR( dev->osh, NULL );
	OSS_IrqRestore( dev->osh, NULL, state );
	
	if(SHIRQ_RequestSharedIrq( dev->irqVector,
							   "MDIS_RTAI",
	   (void(*)(int, void *, struct pt_regs *))MDIS_IrqHandler,  
							   (void*)dev)){
								
		DBGWRT_ERR((DBH," *** %s: can't install Handler\n", __FUNCTION__ ));
		return(ERR_MK_IRQ_INSTALL);

	} else
		rt_enable_irq( dev->irqVector );

	dev->irqInstalled = 1;
	return(ERR_SUCCESS);
}





/******************************* MDIS_RtaiRemoveSysirq ***********************
 *
 *  Description: Remove & disable the (non VME) system interrupt
 *			   
 *---------------------------------------------------------------------------
 *  Input......: dev 	 device structure
 *  Output.....: return  success (0) or error code
 *  Globals....: 
 ****************************************************************************/
int32 MDIS_RtaiRemoveSysirq(MK_DEV *dev)
{
	
	DBGWRT_2((DBH," RTAI remove system interrupt: vect=%d level %d\n", 
			  dev->irqVector, dev->irqLevel)); 

	if( dev->irqVector >= MKRTAI_IRQS )
		return(ERR_MK_IRQ_REMOVE);
   	DBGWRT_2((DBH," last device on vector %d\n", dev->irqVector ));

	rt_disable_irq( dev->irqVector );
	
	if (SHIRQ_RemoveSharedIrq( dev->irqVector, 
				   (void(*)(int, void *, struct pt_regs *))MDIS_IrqHandler,
							   (void*)dev)){
		DBGWRT_ERR((DBH," *** %s: cant remove system IRQ\n", __FUNCTION__ ));
		return(ERR_MK_IRQ_INSTALL);
	}

	dev->irqInstalled = 0;
	OSS_IrqUnMask( dev->osh, NULL );
	return ERR_SUCCESS;
}





/*----------------------------------------------------------------------
 * MDIS for RTAI API functions
 *
 */

/*! \mainpage 
 
 This is the documentation of the MDIS API for RTAI kernel space.

 Refer to the \ref mdisapicommonspec "MDIS_API Common Specification" for the
 plain common specification.

 These functions are intended to be called by RTAI tasks only (not
 from Linux kernel and not from LXRT tasks)
*/

/**********************************************************************/
/** Open path to device
 *
 * \copydoc mdis_api_specification.c::M_open()
 *
 * \rtai Before a path can be opened to a device, the device
 * must have been created by the linux tool \b mdis_createdev.
 *
 * \sa M_close
 */
int32 M_open(const char *device)
{
	MK_DEV *dev;
	int32 error;

	/* if device name begins with a slash, skip slash */
	if( *device == '/' )
		device++;

	DBGWRT_1((DBH, "RTAI::M_open %s ", device ));
	MDIS_RtaiWaitForDevListLock();

	/* is it a known device? */
	dev = MDIS_FindDevByName( device );
	
	if( dev == NULL ){
		/* device not found */
		DBGWRT_ERR((DBH, "*** RTAI::M_open device %s not found\n", device ));
		SetErrno( ENOENT );
		return -1;
	}

	/* be sure that device is opened for rtMode */
	if( !dev->rtMode ){
		DBGWRT_ERR((DBH, "*** RTAI::M_open: %s not initialized for "
					"RT-Mode\n", device ));
		SetErrno( ENOENT );
		return -1;
	}
	MKRTAI_LOCK;

	/*
	 * check if device is already fully initialized. If not, do it now
	 */
	if( dev->initialized == FALSE ){		
		error = MDIS_RtaiInitialOpen( dev );
		if( error ){
			MKRTAI_UNLOCK;
			DBGWRT_ERR((DBH, "*** RTAI::M_open %s initial open failed "
						"error 0x%0x\n", device, error ));
			SetErrno( error );
			return -1;
		}
	}

	/*
	 * find an unused path table entry rt_enable_irq
	 */
	{
		int path;
		MK_PATH *mkPath = G_rtPathTbl;

		for( path=0; path<MKRTAI_MAX_PATHS; path++, mkPath++ )
			if( mkPath->dev == NULL )
				break;

		if( path == MKRTAI_MAX_PATHS ){
			MKRTAI_UNLOCK;
			DBGWRT_ERR((DBH, "*** RTAI::M_open %s: out of free paths\n",
						device ));
			SetErrno( ERR_PATH_FULL );			
			return -1;
		}

		mkPath->dev 	= dev;
		mkPath->chan 	= 0;
		mkPath->ioMode 	= M_IO_EXEC;
		dev->useCount++;	
		MKRTAI_UNLOCK;

		DBGWRT_1((DBH, "RTAI::M_open %s finished path=%d\n", device, path ));

		return path;	
	}
}

/**********************************************************************/
/** Close path to device
 *
 * \copydoc mdis_api_specification.c::M_close()
 * \sa M_open
 */
int32 M_close(int32 path)
{
	MK_DEV *dev;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		SetErrno( ERR_BAD_PATH );
		return -1;
	}		

	MKRTAI_LOCK;

	dev = G_rtPathTbl[path].dev;
	G_rtPathTbl[path].dev = NULL; /* invalidate path */
	
	/* de-initialize device on last close */
	if( --dev->useCount == 0 )
		MDIS_RtaiFinalClose( dev );

	MKRTAI_UNLOCK;
	return 0;
}

/**********************************************************************/
/** Read 32-bit integer value from device
 *
 * \copydoc mdis_api_specification.c::M_read()
 * \sa M_getblock, M_write
 */
int32 M_read(int32 path, int32 *valueP)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"RTAI:M_read %s chan %d\n", 
			  dev->devName, mkPath->chan ));

	if( (error = MDIS_DevLock( mkPath, dev->semRead )))
		goto errexit;

	error = dev->llJumpTbl.read(dev->ll, mkPath->chan, valueP );

	MDIS_DevUnLock( mkPath, dev->semRead );

	/* increment channel */
	if (mkPath->ioMode==M_IO_EXEC_INC && error==0)
		if (++(mkPath->chan) == dev->devNrChan)
			mkPath->chan = 0;

	return 0;

 errexit:
	SetErrno( error );
	return -1;
}

/**********************************************************************/
/** Write 32-bit integer value to device
 * 
 * \copydoc mdis_api_specification.c::M_write()
 * \sa M_setblock, M_read
 */	
int32 M_write(int32 path, int32 value)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"RTAI:M_write %s chan %d = 0x%08x\n", 
			  dev->devName, mkPath->chan, value ));

	if( (error = MDIS_DevLock( mkPath, dev->semWrite )))
		goto errexit;

	error = dev->llJumpTbl.write( dev->ll, mkPath->chan, value );

	MDIS_DevUnLock( mkPath, dev->semWrite );

	/* increment channel */
	if (mkPath->ioMode==M_IO_EXEC_INC && error==0)
		if (++(mkPath->chan) == dev->devNrChan)
			mkPath->chan = 0;

	return 0;

 errexit:
	SetErrno( error );
	return -1;
}

//**********************************************************************/
/** Get status from device
 *  
 * \copydoc mdis_api_specification.c::M_getstat()
 * \sa M_setstat
 */	
int32 M_getstat(int32 path, int32 code, int32 *dataP)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;


	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"mk_rtai.c::M_getstat %s chan %d code 0x%x\n", 
			  dev->devName, mkPath->chan, code ));

	switch( code & 0x0f00 ){
	case M_OFFS_LL:
	case M_OFFS_DEV:
		error = MDIS_LlGetStat( mkPath, code, dataP );
		break;
	case M_OFFS_BB:
	case M_OFFS_BRD:
		error = MDIS_BbGetStat( mkPath, code, dataP ); 
		break;
	case M_OFFS_MK:
		error = MDIS_MkGetStat( mkPath, code, dataP );
		break;
	default:
		error = ERR_MK_UNK_CODE;
	}

	DBGWRT_1((DBH, "RTAI:M_getstat: %s exit error=0x%lx\n", dev->devName, 
			  error ));
 errexit:

	if( error )
		SetErrno( error );
	return error ? -1 : 0;
}

/**********************************************************************/
/** Set status of device
 *  
 * \copydoc mdis_api_specification.c::M_setstat()
 * \sa M_getstat
 */	
int32 M_setstat(int32 path, int32 code, int32 data)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"RTAI:M_setstat %s chan %d code 0x%x\n", 
			  dev->devName, mkPath->chan, code ));

	switch( code & 0x0f00 ){
	case M_OFFS_LL:
	case M_OFFS_DEV:
		error = MDIS_LlSetStat( mkPath, code, (void *)data );
		break;
	case M_OFFS_BB:
	case M_OFFS_BRD:
		error = MDIS_BbSetStat( mkPath, code, (void *)data ); 
		break;
	case M_OFFS_MK:
		error = MDIS_MkSetStat( mkPath, code, (void *)data );
		break;
	default:
		error = ERR_MK_UNK_CODE;
	}

	DBGWRT_1((DBH, "RTAI:M_setstat: %s exit error=0x%lx\n", dev->devName, 
			  error ));
 errexit:
	if( error )
		SetErrno( error );
	return error ? -1 : 0;
}

/**********************************************************************/
/** Read data block from device
 *	
 * \copydoc mdis_api_specification.c::M_getblock()
 * \sa M_read, M_setblock
 */
int32 M_getblock(int32 path, u_int8 *buffer, int32 length)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;
	int32 readCount;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"RTAI:M_getblock %s max %d\n", dev->devName, length ));
	if( (error = MDIS_DevLock( mkPath, dev->semBlkRead )) == 0 ) {

		/*--- call LL driver's blockRead ---*/
		error = dev->llJumpTbl.blockRead( dev->ll, mkPath->chan, buffer,
										  length, &readCount);

		MDIS_DevUnLock( mkPath, dev->semBlkRead );
	}

	DBGWRT_1((DBH,"RTAI:M_getblock ex %s error 0x%x %d bytes read\n", 
			  dev->devName, error, readCount ));
 errexit:
	if( error )
		SetErrno( error );
	return error ? -1 : readCount;	
}

/**********************************************************************/
/** Write data block to device
 *	
 * \copydoc mdis_api_specification.c::M_setblock()
 * \sa M_write, M_getblock
 */
int32 M_setblock(int32 path, const u_int8 *buffer, int32 length)
{
	int32 error;
	MK_PATH *mkPath;
	MK_DEV *dev;
	int32 writeCount;

	if( (path < 0) || path >= MKRTAI_MAX_PATHS ){
		error = ERR_BAD_PATH;
		goto errexit;
	}		

	mkPath = &G_rtPathTbl[path];
	dev = mkPath->dev;

	DBGWRT_1((DBH,"RTAI:M_setblock %s max %d\n", dev->devName, length ));

	if( (error = MDIS_DevLock( mkPath, dev->semBlkWrite )) == 0 ) {

		/*--- call LL driver's blockWrite ---*/
		error = dev->llJumpTbl.blockWrite( dev->ll, mkPath->chan, 
										   (u_int8 *)buffer,
										   length, &writeCount);

		MDIS_DevUnLock( mkPath, dev->semBlkWrite );
	}

	DBGWRT_1((DBH,"RTAI:M_setblock ex %s error 0x%x %d bytes read\n", 
			  dev->devName, error, writeCount ));
 errexit:
	if( error )
		SetErrno( error );
	return error ? -1 : writeCount;	
}

/**********************************************************************/
/** Convert MDIS error code to static string
 * 
 * \copydoc mdis_api_specification.c::M_errstring()
 * \sa M_errstringTs
 */
char* M_errstring(int32 errCode)
{
    static char errMsg[128];

	return M_errstringTs( errCode, errMsg );
}
/**********************************************************************/
/** Convert MDIS error code to string
 * 
 * \copydoc mdis_api_specification.c::M_errstringTs()
 * \sa M_errstring
 */
char* M_errstringTs(int32 errCode, char *strBuf)
{
    char        *errString = NULL;
    u_int32     n;

    /*----------------------+
    |  MDIS error code      |
    +----------------------*/
	if (errCode==ERR_SUCCESS || IN_RANGE(errCode,ERR_OS,ERR_END)) {
		/* search in MDIS msg table */
		for (n=0; n < MDIS_NBR_OF_ERR; n++) {
			if (errCode == errStrTable[n].errCode) {   /* found ? */
				errString = errStrTable[n].errString;
				break;
			}
		}

		if (errString)
			sprintf(strBuf,"ERROR (MDIS) 0x%04lx: %s",errCode,errString);
		else 
			sprintf(strBuf,"ERROR (MDIS) 0x%04lx: unknown MDIS error",errCode);
    }
    /*----------------------+
    |  else: system error   |
    +----------------------*/
	else {
		sprintf(strBuf,"ERROR (LINUX) #%ld", errCode );
	}

    return(strBuf);
}

#endif /* MDIS_RTAI_SUPPORT */






