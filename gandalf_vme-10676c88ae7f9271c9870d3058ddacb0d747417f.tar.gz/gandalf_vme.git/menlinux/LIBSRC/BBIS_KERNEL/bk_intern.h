/***********************  I n c l u d e  -  F i l e  ************************
 *
 *         Name: bk_intern.h
 *
 *       Author: kp
 *        $Date: 2006/08/02 11:03:58 $
 *    $Revision: 1.4 $
 *
 *  Description: MDIS4LINUX BBIS kernel internal header file
 *
 *     Switches: -
 *
 *-------------------------------[ History ]---------------------------------
 *
 * $Log: bk_intern.h,v $
 * Revision 1.4  2006/08/02 11:03:58  ts
 * removed include of <linux/segment.h>
 *
 * Revision 1.3  2004/06/09 09:07:44  kp
 * 2.6 enhancements
 *
 * Revision 1.2  2002/05/31 15:10:07  kp
 * include slab.h
 *
 * Revision 1.1  2001/01/19 14:37:59  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2000 by MEN mikro elektronik GmbH, Nuernberg, Germany
 ****************************************************************************/


#include <linux/kernel.h> /* printk() */
#include <linux/slab.h> /* kmalloc() */
#include <linux/fs.h>     /* everything... */
#include <linux/errno.h>  /* error codes */
#include <linux/types.h>  /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>        /* O_ACCMODE */
#include <linux/kmod.h>

#include <asm/system.h>   /* cli(), *_flags */

#include <MEN/sysdep.h>

#include <MEN/men_typs.h>
#include <MEN/dbg.h>
#include <MEN/oss.h>
#include <MEN/desc.h>
#include <MEN/maccess.h>
#include <MEN/bb_defs.h>
#include <MEN/bb_entry.h>
#include <MEN/bbis_bk.h>
#include <MEN/mdis_err.h>

/*-----------------------------------------+
|  DEFINES                                 |
+------------------------------------------*/
#define DBG_MYLEVEL bk_dbglevel
#define DBH			G_dbh
#define OSH			G_osh

#define BK_MAX_DRVNAME	39		/* maximum length of BB driver name */

/* macros to lock global BBIS sempahore */
#define BK_LOCK(err)		\
 err=OSS_SemWait(OSH,G_bkLockSem,OSS_SEM_WAITFOREVER)

#define BK_UNLOCK OSS_SemSignal(OSH,G_bkLockSem)

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/

/* driver node structure */
typedef struct {
	OSS_DL_NODE node;			  /* node in registered drivers list */
	char drvName[BK_MAX_DRVNAME+1]; /* driver name */
	void (*getEntry)(BBIS_ENTRY *); /* GetEntry function ptr */
	struct module	*module;		/* LL driver linux module structure */
} BK_DRV;

/* BBIS device structure */
typedef struct {
	OSS_DL_NODE node;			  /* node in registered devices list */
	char		    devName[BK_MAX_DEVNAME+1]; /* device name */
    int				useCount;		/* number of opens */

	OSS_HANDLE		*osh;			/* bb driver's OSS handle */

	/* bb driver */
	BK_DRV			*drv;			/* driver structure */
	BBIS_HANDLE		*bb;			/* bb driver's handle */
} BK_DEV;


/*-----------------------------------------+
|  GLOBALS                                 |
+------------------------------------------*/

/*-----------------------------------------+
|  PROTOTYPES                              |
+------------------------------------------*/


