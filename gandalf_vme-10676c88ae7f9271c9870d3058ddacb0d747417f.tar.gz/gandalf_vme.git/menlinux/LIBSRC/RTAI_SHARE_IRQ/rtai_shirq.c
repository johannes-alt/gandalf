/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  rtai_shirq.c
 *
 *      \author  thomas.schnuerer@men.de
 *        $Date: 2006/12/15 13:15:30 $
 *    $Revision: 1.4 $
 * 
 *  	 \brief  additional RTAI module on top of RTAIs regular IRQ handling
 *				 to hookup shared IRQ handlers. The main funcions exported 
 *				 to the world are:
 *				 MDIS_RequestSharedIrq,
 *				 MDIS_RemoveSharedIrq
 *
 *     Switches: __KERNEL__
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: rtai_shirq.c,v $
 * Revision 1.4  2006/12/15 13:15:30  ts
 * include men_mdis_rt.h instead rtai includes
 *
 * Revision 1.3  2005/01/19 13:59:08  ts
 * Functions renamed, cosmetics, handler parameter changed to Linux ISR type
 *
 * Revision 1.2  2004/12/09 10:42:40  ts
 * cosmetics
 *
 * Revision 1.1  2004/11/26 10:47:13  ts
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2004 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#include <linux/module.h>
#include <linux/version.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/irq.h>

#ifdef CONFIG_SMP
#include <linux/openpic.h>
#endif

#include <asm/system.h>
#include <asm/hw_irq.h>
#include <asm/smp.h>
#include <asm/io.h>
#include <asm/atomic.h>  /* irq count */
#include <linux/console.h>
#include <MEN/men_mdis_rt.h>

#ifdef CONFIG_PROC_FS
#include <linux/stat.h>
#include <linux/proc_fs.h>
#endif /* CONFIG_PROC_FS */

#ifdef CONFIG_IPIPE
# include <rtai/rtai_proc_fs.h>
#else
# include <MEN/men_typs.h>
# include <MEN/dbg.h>
# include <MEN/men_rtai_shirq.h>
#endif

#include <MEN/sysdep.h> /* redef MOD_ Macros right */
/*-----------------------------+
 |     DEFINES                 |
 +----------------------------*/

#define RTAI_SHIRQ_IRQ_FREE		(1)
#define RTAI_SHIRQ_IRQ_USED		(2)

#define SHIRQ_NR_IRQS			NR_IRQS
#define RTAI_SHIRQ_MAX_SHARES   4	/* max. # of handlers allowed to share 	*/
#define RTAI_SHIRQ_NAMELEN  	10  /* max. chars allowed for handler name 	*/
#define SHIRQ_TEST_PATTERN		(0xAFFEDEAD) /* check memory integrity 		*/
#define SHIRQ_PROC_FILENAME		"rtai/shared"
#define SHIRQ_COMP_NAME			"men_rtai_shirq"

#ifdef DBG
# define SHIRQDBG(x...)   	men_rt_printk(x)
# define DBG_FCTNNAME  		men_rt_printk("--> %s\n", __FUNCTION__ )
# define DBG_LEAVE     		men_rt_printk("<-- %s\n", __FUNCTION__ )
#else
# define SHIRQDBG(x...) 
# define DBG_FCTNNAME
# define DBG_LEAVE   
#endif

/*------------------------+
 |  TYPEDEFS              |
 +------------------------*/

/* linked list of handlers */
struct RT_IRQ {
	unsigned long	internalCheck;	/* for internal data integrity check */
	void(*handler)( int, void *, struct pt_regs *);
	char *name;	
	void *data;
	struct RT_IRQ * next;
};

/* Information to maintain per-Interrupt */
struct RT_SHIRQINFO {
	unsigned long	internalCheck;	/* used for internal mem integrity chk 	*/
	int  			state; 			/* free or assigned						*/
	int 			irq;			/* which IRQ shares these handlers 		*/
#ifdef MDIS_XENOMAI
/*  int rt_intr_create(RT_INTR *intr, unsigned irq, int mode); */
	RT_INTR			rt_intr;
#endif
    struct RT_IRQ 	*base; 			/* base ptr to irqaction list 			*/
};


/*------------------------+
 |     STATICS            |
 +------------------------*/

#ifdef MDIS_XENOMAI
static int SHIRQ_ShareIrqMetaHandler(struct xnintr *intr);
#else
static void SHIRQ_ShareIrqMetaHandler(unsigned int irq);
#endif

static int  SHIRQ_AddHandler(unsigned int irq, 	
							 char *handlername, 
							 void(*handler)(int, void *, struct pt_regs *),
							 void *data	);
static int  SHIRQ_RemoveHandler(unsigned int irq, 
								void(*handler)( int, void *, struct pt_regs *),
								void *data);

static void SHIRQ_KfreeElement(struct RT_IRQ *ptr);
static struct RT_IRQ *SHIRQ_KmallocElement(void);
static int SHIRQ_ReleaseIrq( unsigned int irq);


/*------------------------+
 |  GLOBALS               |
 +------------------------*/

/* array keeping status of all IRQs */
static struct RT_SHIRQINFO G_rt_shared_irqs[SHIRQ_NR_IRQS];
static atomic_t	G_irqCount[SHIRQ_NR_IRQS];/*might only use 24bit(wrap after 8M)*/
static struct proc_dir_entry *G_shirq_proc_root;

DECLARE_MUTEX(G_mutex);

/*************************************************************************/
/** Interface to the world for requesting a realtime IRQ to be shared
 *
 * \param \IN irq	  IRQ number to request 
 * \param \IN name    optional name for handler, if omited a default is used.
 *                    its also used in the PROC info dump. 
 *					  Must be NULL if not used.
 * \param \IN handler IRQ vector 
 * \param \IN data	  private data for each handler, holds e.g. dev_id
 *
 * \returns 0 		  success
 *			-EINVAL   if wrong parameters were given
 *			-EBUSY	  if the requested IRQ already taken by other extern caller
 *			-ENOMEM	  if the handler could not be attached
 *
 * \brief  SHIRQ_RequestSharedIrq is the basic function to hook a RT handler
 *         to an RTAI Interrupt. up to \RTAI_SHIRQ_MAX_SHARES handlers can be
 *		   chained to be executed.
 */
int SHIRQ_RequestSharedIrq(
	unsigned int irq, 
	char *name, 
	void(*handler)(int, void *, struct pt_regs * ), 
	void *data)
{

	int err = 0;
	DBG_FCTNNAME;

	if( down_interruptible( &G_mutex )) 
		return -ERESTARTSYS; 

	/* sanity checks */
	if ( (irq <= 0 ) || (irq > SHIRQ_NR_IRQS ))
		goto REQERR;

	if (NULL == handler)
		goto REQERR;

	/* paranoia check */
	if (( G_rt_shared_irqs[irq].state != RTAI_SHIRQ_IRQ_FREE ) && \
		( G_rt_shared_irqs[irq].state != RTAI_SHIRQ_IRQ_USED )){
		SHIRQDBG(" *** %s: internal data error (state)\n",	__FUNCTION__ );
		return -EINVAL;
	}

#ifdef MDIS_XENOMAI
	/* 
	 * If IRQ slot was free register meta handler and hook 1st handler 
	 */
	if ( RTAI_SHIRQ_IRQ_FREE == G_rt_shared_irqs[irq].state ) {
		/* Create the RT_INTR object */	
		if ((err = rt_intr_create( &G_rt_shared_irqs[irq].rt_intr,
								   irq, SHIRQ_ShareIrqMetaHandler,
								   NULL)) <0 ) {
			printk(KERN_ERR "*** SHIRQ: rt_intr_create error %d!\n", err);
			return(err);
		}

		/* store irq # in user data field to retrieve it in Metahandler */
		G_rt_shared_irqs[irq].rt_intr.private_data = irq;
		
		/* add the passed handler as the 1st one for this interrupt line */
		if (SHIRQ_AddHandler(irq, name,
							 (void(*)(int,void *,struct pt_regs*))handler,
							 data)){
			printk(KERN_ERR " *** %s: Cant attach handler for IRQ %d\n", 
				   __FUNCTION__ , irq);
			return -ENOMEM;
		}

		/* mark this IRQ slot as used */
		G_rt_shared_irqs[irq].state = RTAI_SHIRQ_IRQ_USED;

		/* and enable it */
		rt_intr_enable(&G_rt_shared_irqs[irq].rt_intr);


	} else {		
		/* IRQ serves a handler already, just hook in next handler */
		SHIRQ_AddHandler(irq, name, 
						 (void (*)( int, void *, struct pt_regs *))handler,
						 data);
	}

#else 	/* - Classic RTAI Irq Registration - */
	
	/* 
	 * If IRQ slot was free register meta handler and hook 1st handler 
	 */
	if ( RTAI_SHIRQ_IRQ_FREE == G_rt_shared_irqs[irq].state ) {

		if (rt_request_global_irq( irq, (void*)SHIRQ_ShareIrqMetaHandler )) {
			SHIRQDBG(" *** %s: cant request shared IRQ %d\n", 
					 __FUNCTION__ , irq );
			return -EBUSY;
		} else {/* success, setup 1st element */			
			if (SHIRQ_AddHandler(irq, name, 
								 (void (*)(int,void *,struct pt_regs*))handler,
								 data)){
 				SHIRQDBG(" *** %s: Cant attach handler for IRQ %d\n", 
						 __FUNCTION__ , irq);
				return -ENOMEM;
			}

			/* enabling better done from outer app? */
			rt_enable_irq( irq );
		}

		/* mark this IRQ slot as used */
		G_rt_shared_irqs[irq].state = RTAI_SHIRQ_IRQ_USED;

	} else {		

		/* 
		 * IRQ serves a handler already, just hook in next handler
		 */
		SHIRQ_AddHandler(irq, name, 
						 (void (*)( int, void *, struct pt_regs *))handler,
						 data);
	}
#endif

	up( &G_mutex );	
	DBG_LEAVE;
	return 0;

 REQERR:
	SHIRQDBG(" *** %s Wrong parameter(s)\n", __FUNCTION__ );
	up( &G_mutex);
	return -EINVAL;

}

EXPORT_SYMBOL(SHIRQ_RequestSharedIrq);






/*************************************************************************/
/** Interface to the world to free a shared realtime IRQ(handler)
 *
 * \param \IN irq	  IRQ from which this to be free (PIC irq)
 * \param \IN name    optional name for handler, if ommited a default is used
 * \param \IN handler handler function to be freed
 *
 * \returns  0 		  on success
 *			 -EINVAL  when a parameter was wrong or given handler not found
 *
 * \brief This function is the counterpart to SHIRQ_RequestSharedIrq. 
 *        It is to be called for each Handler
 *
 */
int SHIRQ_RemoveSharedIrq(
	unsigned int irq, 
	void(*handler)(int, void *, struct pt_regs *),
	void *data)
{	

	DBG_FCTNNAME;
	/* sanity checks */
	if ( (irq <= 0) || (irq > SHIRQ_NR_IRQS ))
		return -EINVAL;

	if (NULL == handler)
		return -EINVAL;

	if ( SHIRQ_RemoveHandler( irq, handler, data)){
		SHIRQDBG(" *** %s cant remove IRQ/handler\n", __FUNCTION__ );
		return -EINVAL;
	}
	DBG_LEAVE;
	return 0;

}

EXPORT_SYMBOL(SHIRQ_RemoveSharedIrq);


/*************************************************************************/
/** remove all handlers and free IRQ globally
 *
 * \param \IN  handler	pointer to function to remove
 *
 * \returns 0 on success
 *          -EINVAL on Error (eg. invalid irq)
 *
 * \brief 
 *        
 */
int SHIRQ_FreeSharedIrqGlobal( unsigned int irq )
{

	struct RT_IRQ *ptr=NULL;

	/* sanity checks */
	if ( !irq || (irq > SHIRQ_NR_IRQS) ){
		SHIRQDBG(" *** %s cant remove IRQ/handler\n", __FUNCTION__ );
		return -EINVAL;
	}

	ptr = G_rt_shared_irqs[irq].base;
	SHIRQ_ReleaseIrq( irq );

	return 0;
}


/* ----------- Interface to the world end  --------------- */
/*************************************************************************/
/** Adding a handler to a particular IRQs linked handler chain
 *
 * \param \IN  irq			(PIC) irq for which this handler is to register
 * \param \IN  handlername  an optional identifyer for the /proc entry
 * \param \IN  handler 		ISR-like handler function to call
 * \param \IN  data			a unique void* which serves to identify the entry
 *
 * \returns 0 on success
 *          -EINVAL on Error (eg. invalid irq)
 *			-EBUSY 	if the function is not found
 *			-ENOMEM if memory for additional Element cant be allocated
 *
 */
static int SHIRQ_AddHandler(
	unsigned int irq,
	char *handlername,
	void (*handler)(int, void *, struct pt_regs *),
	void *data)
{

	struct RT_IRQ *ptr 		= NULL;
	struct RT_IRQ *newPtr	= NULL;

	DBG_FCTNNAME;

	/* sanity checks */
	if ( (irq <= 0) || (irq > SHIRQ_NR_IRQS) )
		goto ERR_ADD;	

	if (NULL == handler)
		goto ERR_ADD;
	
	SHIRQDBG("handler=0x%08x name='%s' data = 0x%08x\n", 
			 handler, handlername, data );

	ptr = G_rt_shared_irqs[irq].base;
	if (NULL == ptr){
		/* its the first handler of this IRQ */
		if (! (ptr = SHIRQ_KmallocElement()) ) {
			SHIRQDBG(" %s: No memory available\n", __FUNCTION__ );
			return -ENOMEM;
		}
	
		G_rt_shared_irqs[irq].base 			= ptr;
		G_rt_shared_irqs[irq].base->handler	= handler;
		G_rt_shared_irqs[irq].base->data 	= data;
		
	} else {
		/* skip to tail, hook there */
		while ( ptr->next)
			ptr = ptr->next;

		newPtr = SHIRQ_KmallocElement();
		if (NULL == newPtr){
			SHIRQDBG(" %s: No memory available\n", __FUNCTION__ );
			return -ENOMEM;
		}

		ptr->next 		= newPtr;
		newPtr->handler = handler;
		newPtr->data	= data;

	}

	strncpy(ptr->name, handlername, RTAI_SHIRQ_NAMELEN );
	MOD_INC_USE_COUNT;

	DBG_LEAVE;	
	return 0;

 ERR_ADD:
	SHIRQDBG(" *** %s: Wrong parameter(s)\n", __FUNCTION__ );
	up( &G_mutex);
	return -EINVAL;

}


/*************************************************************************/
/** Completely release an IRQ
 *
 * \param \IN  irq	IRQ number to release completely
 *
 * \returns 0 or Linux error code (negative)
 *          
 * \brief  releasing the metahandler when the last shared handler of an
 *		   IRQ was removed
 *		  
 */
static int SHIRQ_ReleaseIrq( unsigned int irq)
{
	DBG_FCTNNAME;

	if (!irq)
		return -EINVAL;

	printk("Release IRQ vector %d\n", irq);
#ifdef MDIS_XENOMAI
	rt_intr_disable(&G_rt_shared_irqs[irq].rt_intr);
	rt_intr_delete(&G_rt_shared_irqs[irq].rt_intr);
#else
	rt_free_global_irq( irq );
#endif
	G_rt_shared_irqs[irq].state  = RTAI_SHIRQ_IRQ_FREE;
	G_rt_shared_irqs[irq].base   = NULL;		

	DBG_LEAVE;

	return 0;

}




/*************************************************************************/
/** Removing a handler from the list of handlers for a particular IRQ
 *
 * \param \IN  irq      PIC irq of Handler to remove
 * \param \IN  handler	hand
 * \param \IN  data		unique data that was passed upon RequestSharedIrq
 *
 * \returns 0 on success
 *          -EINVAL on Error (eg if function not found)
 *
 * \brief SHIRQ_RemoveHandler is called by the public rt_free_shared_irq. 
 *  	  A list element is removed if the passed \ref data argument matched. 
 *		  If it was the last handler, the IRQ is freed globally.
 */
static int  SHIRQ_RemoveHandler(unsigned int irq, 
								void(*handler)(int, void *, struct pt_regs *),
								void *data)
{
	struct RT_IRQ *ptr = NULL, *ptrnext	= NULL, *base = NULL;
	int found = 0;
	DBG_FCTNNAME;

	if( down_interruptible( &G_mutex )) 
		return -ERESTARTSYS;

	/* sanity checks */
	if ( (irq <= 0) || (irq > SHIRQ_NR_IRQS ))
		goto ERROR;

	if (NULL == handler)
		goto ERROR;	

	/* paranoia checks */
	if ( G_rt_shared_irqs[irq].state != RTAI_SHIRQ_IRQ_USED ){
		men_rt_printk(KERN_ERR "%s:intern error (usage)\n", __FUNCTION__);
		goto ERROR;	
	}

	if ( NULL == G_rt_shared_irqs[irq].base ){
		men_rt_printk(KERN_ERR "%s:intern error (base==NULL)\n", __FUNCTION__);
		goto ERROR;
	}

	base = G_rt_shared_irqs[irq].base; 
	
	if ( base->data == data ){
		/* 1st list Element is to be removed. */
		ptr = base->next;
		SHIRQ_KfreeElement( base );
		G_rt_shared_irqs[irq].base = ptr;		
		found = 1;
		MOD_DEC_USE_COUNT;
	}else{
		base = G_rt_shared_irqs[irq].base; 
		ptr = base;		

		while( ptr->next ){
			ptrnext = ptr->next;
			if ( ptrnext->data == data ){
				ptr->next = ptrnext->next;
				SHIRQ_KfreeElement(ptrnext);
				found = 1;
				MOD_DEC_USE_COUNT;
				break;
			}
			ptr = ptr->next;
		}
	}

	if (!found){
		men_rt_printk("%s: handler not found\n", __FUNCTION__ );
		return -EINVAL;
	}
	
	/* if last handler was removed release IRQ global */
	base = G_rt_shared_irqs[irq].base;
	if (NULL == base){
		SHIRQ_ReleaseIrq(irq);
	}
	DBG_LEAVE;

	up( &G_mutex);
	return 0;

 ERROR:
	SHIRQDBG(" *** %s: Wrong parameter(s)\n", __FUNCTION__ );
	up( &G_mutex);
	return -EINVAL;
}





/*************************************************************************/
/** The Metahandler to be registered in rt_request_global_irq
 *
 * \param \IN  irq	IRQ number(vector) which caused the call to the metahandler
 *
 * \returns -
 *
 * \brief SHIRQ_ShirqMetaHandler itself calls all linked list handlers
 *        that are to be shared for a particular IRQ. This function serves  
 * 	 	  as the primary connection between RTAI and the rtai_shirq module.
 */
#ifdef MDIS_XENOMAI
static int SHIRQ_ShareIrqMetaHandler(struct xnintr *intr)
#else
static void SHIRQ_ShareIrqMetaHandler(unsigned int irq)
#endif
{

#ifdef MDIS_XENOMAI
	unsigned int irq = 0;
	/* retrieve the irq number from the intr struct */
	RT_INTR *pIntr = I_DESC(intr);
	irq = (unsigned int)pIntr->private_data;
#endif

	struct RT_IRQ *ptrP = G_rt_shared_irqs[irq].base;

	SHIRQDBG("--> SHIRQ_ShareIrqMetaHandler irq=%d\n", irq);
	/* paranoia check */
	if (!ptrP){
		men_rt_printk("%s:IRQ %d internal Error! base == NULL!\n", irq );
		return;
	}

	atomic_inc( &G_irqCount[irq] );

	while ( ptrP ){
		/* TODO: passing a value also for 2nd void* data Parameter? */
		ptrP->handler(irq, ptrP->data, NULL );
		ptrP = ptrP->next;
	}
}


#ifdef CONFIG_PROC_FS
/*  ----------- add info file /proc/rtai/shared to the proc fs -------- */

/*************************************************************************/
/** proc filesystem read function to get Information about interrupts
 *
 * \param \IN -
 *
 * \returns Errorcode  or 0 on success
 *
 * \brief rtai_shirq_info gives a short list of all registered shared irq
 *        handlers 
 */
static int rtai_shirq_info(char *page, char **start, off_t off, 
						   int count,	int *eof, void *data)
{
	PROC_PRINT_VARS;
	int i;
	int lstCnt = 0;

	struct RT_IRQ *ptr;
	PROC_PRINT("\nRTAI_MDIS IRQ share module build %s %s\n", 
			   __DATE__, __TIME__ );
	PROC_PRINT("(NR_IRQS=%d) shared IRQs registered:\n\n", NR_IRQS);


  	for (i = 0; i <= SHIRQ_NR_IRQS; i++) {
		if ( G_rt_shared_irqs[i].state == RTAI_SHIRQ_IRQ_USED){

			ptr = G_rt_shared_irqs[i].base; 

			PROC_PRINT("\n chain list: G_rt_shared_irqs[%d].base=0x%08x\n", 
					   i, (unsigned int)ptr );
			PROC_PRINT("IRQ%d (%ld) handler:\n", i, 
					   atomic_read( &(G_irqCount[i])) );

			while ( ptr ){
				PROC_PRINT("'%s'(0x%08x)",	
						   ptr->name, (unsigned int)ptr->handler);
			 PROC_PRINT(" ptr=0x%08x .next=0x%08x .data=0x%08x\n", 
						(unsigned int)ptr, 
						(unsigned int)ptr->next,
						(unsigned int)ptr->data );
				ptr = ptr->next;
				lstCnt++;
			}			
            PROC_PRINT("\n" );
		}
	}
	PROC_PRINT_DONE;
}    

#else
static int rtai_shirq_info(char *page, char **start, off_t off, 
						   int count,	int *eof, void *data) {return 0};
#endif



/*************************************************************************/
/** Routine to do all kfree-ing in one place
 *
 * \param \IN ptr	address of rt_irq element to remove
 *
 * \returns  pointer to element after the one to be kfree'd 
 *
 * \brief concentrating all calls to kfree in one routine for better 
 * 		  debugging. Additional internal memory integrity test is done
 *        prior to releasing. 
 *		  
 */
static void SHIRQ_KfreeElement(struct RT_IRQ *ptr)
{

	DBG_FCTNNAME;

	if ( SHIRQ_TEST_PATTERN != ptr->internalCheck ){
		/* should *never* happen but who knows */
		printk(KERN_CRIT "%s: WARNING! handler %s(0x%08x): "
			   " possible memory corruption\n",
			   __FUNCTION__ , ptr->name, (unsigned int)ptr );
	}

	/* shredder the Elements prior to freeing */
	ptr->next 	= NULL;
	ptr->data	= 0;
	kfree( ptr->name);
	kfree( ptr );

	DBG_LEAVE;
	
}


/*************************************************************************/
/** Routine to do all kmalloc for an rt_irq element in one place
 *
 * \param \IN ptr	address of rt_irq element to remove
 *
 * \returns pointer to initialized rt_irq element or NULL if no Mem
 *			available
 *
 * \brief SHIRQ_KmallocElement returns pointer to a completely initialized
 *        empty rt_irq element.
 */
static struct RT_IRQ *SHIRQ_KmallocElement(void)
{

	int nCnt = 0;
	struct RT_IRQ *newP = NULL;	
	char *pName;

	DBG_FCTNNAME;

	newP = (struct RT_IRQ*)(kmalloc( sizeof(struct RT_IRQ), GFP_KERNEL));
	if ( NULL == newP)
		goto NOMEM;
	
	newP->name = (char*)(kmalloc( RTAI_SHIRQ_NAMELEN + 1 ,GFP_KERNEL));
	if ( NULL == newP->name)
		goto NOMEM;

	pName = newP->name;
	for (nCnt = 0; nCnt < RTAI_SHIRQ_NAMELEN + 1; nCnt++)
		*pName++ = '\x0';

	newP->internalCheck	=	SHIRQ_TEST_PATTERN;
	newP->next		=	NULL;
	newP->handler	=	NULL;

	DBG_LEAVE;

	return newP;

 NOMEM:
	SHIRQDBG( "*** %s: cant alloc memory for new handler\n", __FUNCTION__ );

	return NULL;

}


/*************************************************************************/
/** proc filesystem read function to get Information about shared handlers
 *
 * \param \IN -
 *
 * \returns - 
 *
 * \brief create an entry to allow users to get info about shared handlers
 *        with cat /proc/rtai/shared . The routine assumes that /proc/rtai 
 *		  already exists.
 */
#ifdef CONFIG_PROC_FS
static int rtai_shirq_proc_register(void)
{

	DBG_FCTNNAME;

	G_shirq_proc_root = create_proc_entry(SHIRQ_PROC_FILENAME, 
										S_IFREG|S_IRUGO|S_IWUSR, 
										NULL );
	if (!G_shirq_proc_root) {
		men_rt_printk("Unable to initialize /proc/rtai/shared\n");
		return -ENOMEM;
	}

	G_shirq_proc_root->read_proc 	= rtai_shirq_info;
	G_shirq_proc_root->owner 		= THIS_MODULE;

	return(0);

}  /* End function - rtai_proc_register */
#else
static int rtai_shirq_proc_register(void) {return 0};
#endif


/*************************************************************************/
/** remove proc filesystem entry
 *
 * \param \IN -
 *
 * \returns - 
 *
 * \brief  remove the file /proc/rtai/shared 
 *        
 */
#ifdef CONFIG_PROC_FS
static void rtai_shirq_proc_unregister(void)
{

	DBG_FCTNNAME;
	remove_proc_entry( SHIRQ_PROC_FILENAME, NULL);

}
#endif /* CONFIG_PROC_FS */


/* -----  Module stuff -------- */

/*************************************************************************/
/** initialization of different Arrays, variables etc
 *
 * \param \IN -
 *
 * \returns 0   	on sucess
 *			-EBUSY 	if proc file couldnt be build
 *
 * \brief  Init our primary Array for keeping Information about our IRQs
 *        
 */
int init_module(void)
{
	int i;

	DBG_FCTNNAME;

	printk( KERN_INFO "MEN MDIS IRQ sharing init_module\n");
	/* init shirqinfo main array */
	for (i = 0; i< SHIRQ_NR_IRQS; i++){

		G_rt_shared_irqs[i].internalCheck	= 0;
		G_rt_shared_irqs[i].state  			= RTAI_SHIRQ_IRQ_FREE;
		G_rt_shared_irqs[i].irq	  			= 0;
		G_rt_shared_irqs[i].base			= NULL;
		atomic_set( &(G_irqCount[i]), 0);

	}

	/* add file /proc/rtai/shared */
#ifdef CONFIG_PROC_FS	
	if (rtai_shirq_proc_register()){
		men_rt_printk("%s: cant register rtai_shirq proc entry", __FUNCTION__);
		return -EBUSY;
	}
#endif

	return 0;
}


/*************************************************************************/
/** Module destruction and unload
 *
 * \param \IN -
 * \returns 0 on success or errorcode
 *
 * \brief  standard Linux module init function
 */

void cleanup_module(void)
{

	DBG_FCTNNAME;
#ifdef CONFIG_PROC_FS
	rtai_shirq_proc_unregister();
#endif

}

MODULE_DESCRIPTION( SHIRQ_COMP_NAME "MDIS module");
MODULE_AUTHOR("thomas.schnuerer@men.de");
#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif

/* #endif /\* MODULE *\/ */
/* ------------- Unittest declarations --------------------------- */


/* ------------- End of Unittest declarations -------------------- */

