/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_mem_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:17:46 $
 *    $Revision: 2.4 $
 * 
 *	   \project  MDIS4Linux/RTAI
 *  	 \brief  Memory handling functions of the OSS module
 *      
 *    \switches: MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_mem_rtai.c,v $
 * Revision 2.4  2006/09/26 10:17:46  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.3  2005/07/07 17:17:26  cs
 * Copyright line changed
 *
 * Revision 2.2  2003/04/11 16:13:46  kp
 * Comments changed to Doxygen
 *
 * Revision 2.1  2003/02/21 11:25:22  kp
 * Initial Revision
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/
#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT

/**********************************************************************/
/** Allocates general memory block.	
 *
 * \copydoc oss_specification.c::OSS_MemGet()
 *
 * \rtai Uses rt_malloc. Therefore the maximum size one can allocate
 * depends on the configuration of \c rt_mem_mgr.
 *
 * \sa OSS_RtaiMemFree
 */
void* OSS_RtaiMemGet(
    OSS_HANDLE  *oss,
    u_int32     size,
    u_int32     *gotsizeP
)
{
	void *mem = men_rt_malloc( size );
	if( mem != NULL )
		*gotsizeP = size;
	else
		*gotsizeP = 0;

	DBGWRT_1((DBH,"OSS_MemGet (RTAI): size=0x%lx allocated addr=0x%p\n", 
			  size, mem ));
	return mem;
}/*OSS_MemGet*/

/**********************************************************************/
/** Return memory block.
 *
 * \copydoc oss_specification.c::OSS_MemFree()
 * \sa OSS_RtaiMemGet
 */
int32 OSS_RtaiMemFree(
    OSS_HANDLE *oss,
    void       *addr,
    u_int32    size
)
{
	DBGWRT_1((DBH,"OSS_MemFree (RTAI): addr=0x%p size=0x%lx\n", addr, size));
	men_rt_free(addr);
    return(0);
}/*OSS_MemFree*/

#endif /* MDIS_RTAI_SUPPORT */

