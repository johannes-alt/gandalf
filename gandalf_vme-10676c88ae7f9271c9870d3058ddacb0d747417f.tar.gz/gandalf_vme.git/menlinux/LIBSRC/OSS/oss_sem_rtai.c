/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_sem_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:20:10 $
 *    $Revision: 2.5 $
 * 
 *	   \project  MDIS4LINUX/RTAI
 *  	 \brief  Semaphore routines for RTAI
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_sem_rtai.c,v $
 * Revision 2.5  2006/09/26 10:20:10  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.4  2005/07/07 17:17:33  cs
 * Copyright line changed
 *
 * Revision 2.3  2004/12/09 09:46:03  ts
 * adapted for RTAI 3.0
 *
 * Revision 2.2  2003/04/11 16:13:48  kp
 * Comments changed to Doxygen
 *
 * Revision 2.1  2003/02/21 11:25:23  kp
 * Initial Revision
 *
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#define _OSS_SEM_C
#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT

/*! \page rtaisemusage

  \section rtaisemusagesect RTAI notes to OSS semaphores

  This implementation uses native RTAI semaphores.
  
  This works fine. However when the semaphore's value reaches 0xffff
  we run into troubles because this is the same value as \c SEM_ERR.
  Hopefully, the RTAI guys will fix this some day.

  Semaphore waits cannot be aborted by signals under RTAI.
  
  See \ref osssemusagesect for more info.
*/

/*-----------------------------------------+
|  DEFINES                                 |
+------------------------------------------*/
#ifndef SEM_ERR
# define SEM_ERR 0xffff			/* should be in rtai_sched.h */
#endif

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/
#undef OSS_SEM_HANDLE
#define OSS_SEM_HANDLE OSS_RTAI_SEM_HANDLE

typedef struct OSS_RTAI_SEM_HANDLE
{
  SEM rtSem;					/* RTAI sem control structure */
} OSS_RTAI_SEM_HANDLE;

/**********************************************************************/
/** Create a semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemCreate()
 *
 * See \ref rtaisemusagesect for more info.
 *
 * \rtai \linrtai For Linux implementation, see OSS_SemCreate().
 *
 * \sa OSS_RtaiSemRemove, OSS_RtaiSemWait, OSS_RtaiSemSignal
 */
int32 OSS_RtaiSemCreate(
    OSS_HANDLE 	   *oss,
    int32          semType,
    int32          initVal,
    OSS_SEM_HANDLE **semP)
{
    DBGCMD( static const char functionName[] = "OSS_RtaiSemCreate"; )
    OSS_SEM_HANDLE *semHandle;

    DBGWRT_1((DBH,"%s()\n", functionName));

	*semP = NULL;

	/* allocate memory for semaphore */
	semHandle = men_rt_malloc( sizeof(OSS_SEM_HANDLE) );
	if( semHandle == NULL )
		return( ERR_OSS_MEM_ALLOC );

	men_rt_sem_init(&semHandle->rtSem, initVal);

	*semP = semHandle;

    return( 0 );
}/*OSS_RtaiSemCreate*/

/**********************************************************************/
/** Destroy semaphore handle.
 *
 * \copydoc oss_specification.c::OSS_SemRemove()
 *
 * See \ref rtaisemusagesect for more info.
 *
 * \rtai \linrtai For Linux implementation, see OSS_SemRemove().
 *
 * \sa OSS_RtaiSemCreate, OSS_RtaiSemWait, OSS_RtaiSemSignal
 */
int32 OSS_RtaiSemRemove(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE** semHandleP)
{
    DBGCMD( static const char functionName[] = "OSS_RtaiSemRemove"; )
    OSS_SEM_HANDLE *semHandle;

    DBGWRT_1((DBH,"%s() OSS_SEM_HANDLE = 0x%p\n", functionName, *semHandleP ));

	semHandle   = *semHandleP;

	if( semHandle ){
		if( rt_sem_delete( &semHandle->rtSem ) == SEM_ERR ){
			DBGWRT_ERR((DBH,"*** %s error deleting sem\n", functionName ));
			return ERR_OSS_SEM_REMOVE;
		}
		men_rt_free( semHandle );
		*semHandleP = NULL;
	}
    return( 0 );
}/*OSS_RtaiSemRemove*/

/**********************************************************************/
/** Wait for semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemWait()
 *
 * See \ref rtaisemusagesect for more info.
 *
 * \rtai \linrtai For Linux implementation, see OSS_SemWait().
 *
 * \sa OSS_RtaiSemCreate, OSS_RtaiSemRemove, OSS_RtaiSemSignal
 */
int32 OSS_RtaiSemWait(
    OSS_HANDLE      *oss,
    OSS_SEM_HANDLE  *sem,
    int32           msec)
{
	int32 error=0;
	int32 count;	/* signed for different return values in timeout case */
    DBGCMD( static const char functionName[] = "OSS_RtaiSemWait"; )

    DBGWRT_1((DBH,"%s sem = 0x%p\n", functionName, sem ));

	switch( msec ){

	case OSS_SEM_NOWAIT:
		count = men_rt_sem_get_immediate( &sem->rtSem );
		if( count <= 0 ){
			DBGWRT_2((DBH, " semnowait sem not avail\n"));
			error = ERR_OSS_TIMEOUT;
		}
		break;

	case OSS_SEM_WAITFOREVER:
		count = men_rt_sem_get_forever( &sem->rtSem );
		break;

	default:
		count =  men_rt_sem_get_time( &sem->rtSem, 
									  men_rt_ns2tick((RTIME)1E6 * msec));

		if( count == MDIS_RT_SEM_TIMEOUT ){
			DBGWRT_ERR((DBH,"*** %s timeout waiting for sem\n", 
						functionName ));
			error = ERR_OSS_TIMEOUT;
		}
		break;
	}

	if( count == SEM_ERR ){
		DBGWRT_ERR((DBH,"*** %s invalid rtsem handle\n", functionName ));
		error = ERR_OSS;
	}
    return error;
}/*OSS_RtaiSemWait*/

/**********************************************************************/
/** Signal semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemSignal()
 *
 * See \ref rtaisemusagesect for more info.
 *
 * \rtai \linrtai For Linux implementation, see OSS_SemSignal().
 *
 * \sa OSS_RtaiSemCreate, OSS_RtaiSemRemove, OSS_RtaiSemWait
 */
int32 OSS_RtaiSemSignal(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE* sem)
{
    DBGCMD( static const char functionName[] = "OSS_RtaiSemSignal"; )

    DBGWRT_1((DBH,"%s() sem = 0x%p\n", functionName, sem ));
	
	if( men_rt_sem_put( &sem->rtSem ) == SEM_ERR ){
		DBGWRT_ERR((DBH,"*** %s invalid rtsem handle\n", functionName ));
		return ERR_OSS;
	}
    return 0;
}/*OSS_RtaiSemSignal*/

#endif /* MDIS_RTAI_SUPPORT */

