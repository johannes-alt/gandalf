/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_time_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:19:40 $
 *    $Revision: 2.5 $
 * 
 *	   \project  MDIS4Linux
 *  	 \brief  Time related routines of the OSS module (RTAI version)
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_time_rtai.c,v $
 * Revision 2.5  2006/09/26 10:19:40  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.4  2005/07/07 17:17:47  cs
 * Copyright line changed
 *
 * Revision 2.3  2004/12/09 09:46:08  ts
 * cosmetics
 *
 * Revision 2.2  2003/04/11 16:13:54  kp
 * Comments changed to Doxygen
 *
 * Revision 2.1  2003/02/21 11:25:27  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT


/*! \page rtaitimernotes
 * \section rtaitimernotessect RTAI timer notes
 *
 * All depends wether scheduler is running in 
 * - oneshot mode 	(set with rt_set_oneshot_mode()) or
 * - periodic mode 	(default or set with rt_set_periodic_mode())
 * 
 * The following time units exist:
 *
 * - \b counts: Most rtai sched functions take a count argument.
 *   - In oneshot mode, the count is related to the cpu frequency (timestamp
 *	   counter on Pentium or timebase on PPC). I.e. 
 *	   - for a 1GHz pentium, count is a time quantum of 1ns
 *     - for a PPC with 100 MHz mem clock, count is a time quantum of 40ns
 *   - In periodic mode, the count is related (typically) to the 8254 timer
 *     frequency, i.e. count is a time quantum of 838ns (1/1193180)
 * - \b tick \b period: this is the value passed to start_rt_timer(). 
 *   Tick period is used for task scheduling (e.g. round robin mode).
 *	 
 * In periodic mode, rt_sleep() sleeps only in the given granularity
 * of a "tick period". E.g. when "tick period" is programmed to 1ms, a
 * rt_sleep(nano2count(1500*1000)) would sleep only 1ms, not 1.5ms as
 * specified. Also rt_get_time() is based on the "tick period", i.e.
 * calling rt_get_time() twice within the same tick period returns the
 * same value.
 *
 * In oneshot mode however, rt_sleep() and rt_get_time() is
 * independend on the "tick period". Instead, it operates on the
 * granularity of "counts", i.e. timestamp/timebase counter of the
 * CPU. For example, it is possible to do rt_sleep() for 500us even if
 * the tick period is set to 1ms
 *
 * Another note: Most time variables are of type "RTIME". This is a 
 * "long long" (64 bit) type. Therefore the RTAI timers will wrap
 * arround after a very long time (e.g in oneshot mode on a 1Ghz Pentium
 * after 584 years). I don't have time to wait for so long...
 */
#define CHK_TIMING_IS_INIT \
 if( OSS_tmrOneShotMode == -1 ){\
     DBGWRT_ERR((DBH,"*** OSS: forgot to call OSS_RtaiTimingInit\n"));\
     return ERR_OSS;\
 }

int OSS_tmrOneShotMode=-1;		/* -1=undefined, 0=periodic mode, 1=oneshot */

int OSS_tmrPeriod;		/* copy of rt_times.period_tick. Length of 
						   one tick period in units of "counts" */

/**********************************************************************/
/** Initialize OSS RTAI timing 
 *
 * RTAI specific call. Must be called \b after start_rt_timer() and
 * every time the RTAI timer mode is changed.
 * 
 * Required since OSS must know wether RTAI is in oneshot or periodic mode
 * and there is currently no RTAI API function to query this mode.
 * For use with Xenomai, rt_timer_inquire is used.
 *
 * Sets up globals OSS_tmrOneShotMode and OSS_tmrPeriod
 *
 * See also \ref rtaitimernotessect.
 *
 * \param oneShotMode		\IN 0=periodic mode, 1=oneshot mode
 */
void OSS_RtaiTimingInit( int oneShotMode )
{
	OSS_tmrOneShotMode 	= !!oneShotMode;
	OSS_tmrPeriod 		= 42; /* rt_times.periodic_tick; */   /* ts: TODO */

#ifdef DBG /* no OSS_HANDLE here */
	men_rt_printk("OSS_RtaiTimingInit::oneShotMode=%d\n", oneShotMode );
#endif

}

/**********************************************************************/
/** Convert milliseconds to RTAI count value
 *
 * RTAI specific call. Called internally from OSS and from USR_OSS.
 *
 * \param msec				\IN time value in milliseconds
 * \param countP			\OUT will receive converted time value in RTAI 
 *								 counts
 * \return 0 on success or \c ERR_OSS_xxx error code on error
 * \sa OSS_RtaiTimingInit()
 * See also \ref rtaitimernotessect.
 */
int32 OSS_RtaiMsToCount( int32 msec, RTIME *countP )
{
	RTIME count;
	unsigned long rem;

	if( OSS_tmrOneShotMode == -1 )
		return 0;			/* timing not initialized */

	/*--- round time, and correct for timer inaccuracy ---*/
	count = men_rt_ns2tick( (long long)1E6 * msec );
	if( !OSS_tmrOneShotMode ){

		/* don't know where we are in current period... */
		count += OSS_tmrPeriod;
		
		/* if count is not exactly a multiple of tick period, 
		   add one period */
		ulldiv( count, OSS_tmrPeriod, &rem );
		if( rem )
			count += (OSS_tmrPeriod-rem);
	}
	*countP = count;
	return 0;
}

/**********************************************************************/
/** Let process sleep for specified time.
 * 
 * \copydoc oss_specification.c::OSS_Delay()
 *
 * \rtai \linrtai For Linux implementation, see OSS_Delay(). 
 * \rtai You must have called OSS_RtaiTimingInit() before!
 *
 * See also \ref rtaitimernotessect.
 * \sa OSS_RtaiMikroDelay
 */
int32 OSS_RtaiDelay( OSS_HANDLE *oss, int32 msec )
{
	unsigned long rem;
	RTIME count;
	int32 error;

	CHK_TIMING_IS_INIT;

	if( (error = OSS_RtaiMsToCount( msec, &count )) )
		return error;
	
	DBGWRT_1((DBH,"OSS_RtaiDelay %d ms count=%ld\n", msec, (long)count ));

	men_rt_sleep( count ); /* not busy waiting */

	/* determine return value */
	count = ulldiv( men_cnt2nano(count), 1E6, &rem );
	if( rem >= 500000 )	
		count++;
		
	return (int32)count;
}/*OSS_Delay*/

/**********************************************************************/
/** Delay execution of a process by using a busy-loop.
 * 
 * \copydoc oss_specification.c::OSS_MikroDelay()
 *
 * \rtai \linrtai For Linux implementation, see OSS_MikroDelay(). 
 * \rtai \em rt_busy_sleep() is used.
 * See also \ref rtaitimernotessect.
 */
int32 OSS_RtaiMikroDelay( OSS_HANDLE *oss, u_int32 usec )
{
	unsigned long long ns;

	ns = usec * 1000;
	DBGWRT_1((DBH,"OSS_MikroDelay us=%ld\n", usec));

	if( ns > 0x7fffffff ){
		DBGWRT_ERR((DBH,"*** OSS_MikroDelay us=%u out of range\n", usec )); 
		return ERR_OSS_NO_MIKRODELAY;
	}

	men_rt_busy_wait((int)ns); 
    return(0);
}/*OSS_MikroDelay*/

/**********************************************************************/
/** Get the tick rate.
 * 
 * \copydoc oss_specification.c::OSS_TickRateGet()
 *
 * \rtai \linrtai For Linux implementation, see OSS_TickRateGet(). 
 *
 * \rtai To avoid too huge tickrates in \b oneshot mode, the RTAI
 * tickrate is devided by 4096.  For example, in oneshot mode on a 
 * 1 GHz pentium, the tickrate value would be 244140 (1E9/4096). 
 * For periodic mode, the tickrate corresponds to the frequency of
 * one RTAI scheduler period.
 *
 * \rtai You must have called OSS_RtaiTimingInit() before!
 * \sa OSS_RtaiTickGet
 * See also \ref rtaitimernotessect.
 */
int32 OSS_RtaiTickRateGet( OSS_HANDLE *oss )
{
	u_int32 tickrate;

	CHK_TIMING_IS_INIT;

	if( OSS_tmrOneShotMode ){
		unsigned long rem;
		RTIME ns = men_cnt2nano( 1000 ); /* get ns of 1000 ticks */
		tickrate = ulldiv( 1E12, ns, &rem );
		tickrate >>= 12;
	}
	else {
		/* periodic mode */
		RTIME ns = men_cnt2nano( OSS_tmrPeriod );
		tickrate = (u_int32)1E9/(u_int32)ns;
	}
    return tickrate;
}/*OSS_TickRateGet*/

/**********************************************************************/
/** Get the current system tick.
 * 
 * \copydoc oss_specification.c::OSS_TickGet()
 *
 * \rtai \linrtai For Linux implementation, see OSS_TickGet(). 
 * \linux uses \em rt_get_time().
 * \rtai You must have called OSS_RtaiTimingInit() before!
 * \sa OSS_RtaiTickRateGet
 * See also \ref rtaitimernotessect.
 *
 * In both RTAI classic and Xenomai behaviour is mode dependent. In periodic 
 * mode, clock ticks are expressed as periodic jiffies. In oneshot mode, clock 
 * ticks are expressed as nanoseconds.
 */
u_int32 OSS_RtaiTickGet(OSS_HANDLE *oss)
{
	CHK_TIMING_IS_INIT;

	if( OSS_tmrOneShotMode ){
		return (u_int32)(men_rt_get_time() >> 12);
	}
	else {
		unsigned long rem;
		return ulldiv( men_rt_get_time(), OSS_tmrPeriod, &rem );
	}
}/*OSS_TickGet*/

EXPORT_SYMBOL(OSS_RtaiTimingInit);       
EXPORT_SYMBOL(OSS_RtaiMsToCount);

#endif /* MDIS_RTAI_SUPPORT */





