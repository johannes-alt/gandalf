/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_task_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:19:30 $
 *    $Revision: 2.4 $
 * 
 *	   \project  MDIS4Linux
 *  	 \brief  Task routines for RTAI
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_task_rtai.c,v $
 * Revision 2.4  2006/09/26 10:19:30  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.3  2005/07/07 17:17:43  cs
 * Copyright line changed
 *
 * Revision 2.2  2003/04/11 16:13:52  kp
 * Comments changed to Doxygen
 *
 * Revision 2.1  2003/02/21 11:25:25  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT
/**********************************************************************/
/** Get current task id.
 *
 * \copydoc oss_specification.c::OSS_GetPid()
 *
 * \rtai \linrtai For Linux implementation, see OSS_GetPid().
 */
u_int32 OSS_RtaiGetPid(OSS_HANDLE *oss)
{
	u_int pid;

	pid = (u_int32)men_rt_this();

    DBGWRT_1((DBH,"OSS_RtaiGetPid = 0x%08x\n", pid));

	return(pid);
}/*OSS_GetPid*/

#endif /* MDIS_RTAI_SUPPORT */


