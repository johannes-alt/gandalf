/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_sem.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2007/12/04 16:26:58 $
 *    $Revision: 2.2 $
 * 
 *	   \project  MDIS4Linux
 *  	 \brief  Semaphore routines
 *      
 *    \switches  MDIS_RTAI_SUPPORT 
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_sem.c,v $
 * Revision 2.2  2007/12/04 16:26:58  ts
 * removed warning about possible use of uninitialized signal_t members
 *
 * Revision 2.1  2005/07/07 17:17:31  cs
 * Copyright line changed
 *
 * Revision 2.0  2004/06/09 09:25:04  kp
 * - reimplementation using spin locks and schedule_timeout
 *
 * Revision 1.3  2003/04/11 16:13:31  kp
 * Comments changed to Doxygen
 *
 * Revision 1.2  2003/02/21 11:25:13  kp
 * added RTAI dispatching functions
 *
 * Revision 1.1  2001/01/19 14:39:15  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2000-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#define _OSS_SEM_C
#include "oss_intern.h"

struct OSS_RTAI_SEM_HANDLE;

/*
 * Dispatcher functions. They switch between the std linux or RT 
 * implementations depending of the oss->rtMode flag
 */
#ifdef MDIS_RTAI_SUPPORT

int32 OSS_LinSemCreate( OSS_HANDLE*, int32, int32, 
						struct OSS_LIN_SEM_HANDLE ** );
int32 OSS_LinSemRemove( OSS_HANDLE *, struct OSS_LIN_SEM_HANDLE** );
int32 OSS_LinSemWait( OSS_HANDLE *, struct OSS_LIN_SEM_HANDLE *, int32 );
int32 OSS_LinSemSignal( OSS_HANDLE *, struct OSS_LIN_SEM_HANDLE* );

int32 OSS_RtaiSemCreate( OSS_HANDLE*, int32, int32, 
						 struct OSS_RTAI_SEM_HANDLE ** );
int32 OSS_RtaiSemRemove( OSS_HANDLE *, struct OSS_RTAI_SEM_HANDLE ** );
int32 OSS_RtaiSemWait( OSS_HANDLE *, struct OSS_RTAI_SEM_HANDLE *, int32 );
int32 OSS_RtaiSemSignal( OSS_HANDLE *, struct OSS_RTAI_SEM_HANDLE * );

int32 OSS_SemCreate(
    OSS_HANDLE 	   *oss,
    int32          semType,
    int32          initVal,
    OSS_SEM_HANDLE **semP)
{
	if( oss->rtMode )
		return OSS_RtaiSemCreate( oss, semType, initVal, 
								  (struct OSS_RTAI_SEM_HANDLE**)semP );
	else
		return OSS_LinSemCreate( oss, semType, initVal, 
								 (struct OSS_LIN_SEM_HANDLE**) semP );
}

int32 OSS_SemRemove(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE** semHandleP)
{
	if( oss->rtMode )
		return OSS_RtaiSemRemove( oss, 
								  (struct OSS_RTAI_SEM_HANDLE**)semHandleP );
	else
		return OSS_LinSemRemove( oss, 
								 (struct OSS_LIN_SEM_HANDLE**)semHandleP );
}

int32 OSS_SemWait(
    OSS_HANDLE      *oss,
    OSS_SEM_HANDLE  *sem,
    int32           msec)
{
	if( oss->rtMode )
		return OSS_RtaiSemWait( oss, (struct OSS_RTAI_SEM_HANDLE*)sem, msec );
	else
		return OSS_LinSemWait( oss, (struct OSS_LIN_SEM_HANDLE*)sem, msec );
}

int32 OSS_SemSignal(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE* sem)
{
	if( oss->rtMode )
		return OSS_RtaiSemSignal( oss, (struct OSS_RTAI_SEM_HANDLE*)sem );
	else
		return OSS_LinSemSignal( oss, (struct OSS_LIN_SEM_HANDLE*)sem );
}

#undef  OSS_SemCreate
#define OSS_SemCreate	OSS_LinSemCreate

#undef  OSS_SemRemove
#define OSS_SemRemove	OSS_LinSemRemove

#undef  OSS_SemWait
#define OSS_SemWait		OSS_LinSemWait

#undef  OSS_SemSignal
#define OSS_SemSignal	OSS_LinSemSignal


#endif /* MDIS_RTAI_SUPPORT */

/************* LINUX Implementation ******************/

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/
#undef OSS_SEM_HANDLE
#define OSS_SEM_HANDLE OSS_LIN_SEM_HANDLE

/*! \page linsemusage

  \section linsemusagesect Linux notes to OSS semaphores

  This implementation uses Linux waitqueues for semaphores.
  There may be a better way to implement OSS semaphores using kernel
  semaphores, however I didn't find enough docs on these.
  
  Semaphore waits can be aborted by deadly signals under Linux.

  See \ref osssemusagesect for more info.
*/

/**********************************************************************/
/** Create a semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemCreate()
 *
 * See \ref linsemusagesect for more info.
 *
 * \linux \linrtai For RTAI implementation, see OSS_RtaiSemCreate().
 *
 * \sa OSS_SemRemove, OSS_SemWait, OSS_SemSignal
 */
int32 OSS_SemCreate(
    OSS_HANDLE 	   *oss,
    int32          semType,
    int32          initVal,
    OSS_SEM_HANDLE **semP)
{
    DBGCMD( static const char functionName[] = "OSS_SemCreate()"; )
    OSS_SEM_HANDLE *semHandle;

    DBGWRT_1((DBH,"%s()\n", functionName));

	*semP = NULL;

	/* allocate memory for semaphore */
	semHandle = kmalloc( sizeof(OSS_SEM_HANDLE), GFP_KERNEL );
	if( semHandle == NULL )
		return( ERR_OSS_MEM_ALLOC );

	semHandle->value 	= initVal;
	semHandle->semType	= semType;

	init_waitqueue_head( &semHandle->wq );
	spin_lock_init( &semHandle->lock );

	*semP = semHandle;
    return( 0 );
}/*OSS_SemCreate*/

/**********************************************************************/
/** Destroy semaphore handle.
 *
 * \copydoc oss_specification.c::OSS_SemRemove()
 *
 * See \ref linsemusagesect for more info.
 *
 * \linux \linrtai For RTAI implementation, see OSS_RtaiSemRemove().
 *
 * \sa OSS_SemCreate, OSS_SemWait, OSS_SemSignal
 */
int32 OSS_SemRemove(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE** semHandleP)
{
    DBGCMD( static const char functionName[] = "OSS_SemRemove"; )
    OSS_SEM_HANDLE *semHandle;

    DBGWRT_1((DBH,"%s() OSS_SEM_HANDLE = 0x%p\n", functionName, *semHandleP ));

	semHandle   = *semHandleP;
	*semHandleP = NULL;

	if( semHandle )
		kfree( semHandle );
    return( 0 );
}/*OSS_SemRemove*/

static int32 HandleSig( OSS_HANDLE *oss, sigset_t *oldBlocked )
{
	unsigned long flags;
	/* 
	 * check if there is a signal <= 31 pending. 
	 * If so, the signal is assumed to be deadly and OSS_SemWait
	 * is aborted.
	 * All other signals are ignored, and OSS_SemWait continues to wait.
	 * But in order to allow the process to sleep again, we must block
	 * these signals. The original signal mask is saved here and restored when
	 * OSS_SemWait exits
	 *
	 */

	/* ok. the following uses internas of sigsets, but fastest way to do it */
	TASK_LOCK_SIGNALS( current, flags );

	if( (current->TASK_SIGPENDING[0] & 0x7fffffff) & 
		~(current->blocked.sig[0])){

		DBGWRT_ERR((DBH,"*** OSS_SemWait killed by deadly signal mask=0x%x\n", 
					current->TASK_SIGPENDING[0]));
		TASK_UNLOCK_SIGNALS( current, flags );
		return 1;
	}

	/* non-deadly signal pending, block all signals 31..__SIGRTMAX (63) */
	DBGWRT_2((DBH,"OSS_SemWait interrupted by non-deadly sig\n"));
	*oldBlocked = current->blocked;
	sigorsets( &current->blocked, &current->blocked, &OSS_allRtSigs );
	RECALC_SIGPENDING();

	TASK_UNLOCK_SIGNALS( current, flags );

	return 0;
}

/**********************************************************************/
/** Wait for semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemWait()
 *
 * See \ref linsemusagesect for more info.
 *
 * \linux 
 * - all signals < \c SIGRTMIN are assumed to be deadly.
 * - LL drivers trying to ignore \b all signals while waiting for a
 * signal will cause a busy loop under linux, because the scheduler
 * awakes a process always immediately when a non masked signal is
 * pending.
 * - \linrtai For RTAI implementation, see OSS_RtaiSemWait().
 *
 * \sa OSS_SemCreate, OSS_SemRemove, OSS_SemSignal
 */
int32 OSS_SemWait(
    OSS_HANDLE      *oss,
    OSS_SEM_HANDLE  *sem,
    int32           msec)
{
	unsigned long flags;
	u_int32 ticks=0, i = 0;
	sigset_t oldBlocked;
	int oldBlockedValid=FALSE;
	int32 error=0;
    DBGCMD( static const char functionName[] = "OSS_SemWait"; )

    DBGWRT_1((DBH,"%s sem = 0x%p\n", functionName, sem ));

	/* keep gcc from complaining about using possibly uninitialized values*/
	for (i = 0; i < _NSIG_WORDS; i++)
		oldBlocked.sig[i]=0;

	/*--- try to claim semaphore ---*/

	spin_lock_irqsave( &sem->lock, flags );

	if( sem->value > 0 ){
		sem->value--;			/* ok, got the semaphore */
		DBGWRT_2((DBH, " got sem immediately\n"));
		spin_unlock_irqrestore( &sem->lock, flags );
		return 0;
	}

	/* didn't get the semaphore, now block until semaphore is released */
	if( msec > 0 ){
		/*--- round time, and correct for timer inaccuracy ---*/
		ticks = (msec * HZ) / 1000;
		ticks++;

		if( (msec * HZ) % 1000 )
			ticks++;

	}
	else if( msec == OSS_SEM_NOWAIT ){
		DBGWRT_2((DBH, " sem not avail\n"));
		spin_unlock_irqrestore( &sem->lock, flags );
		return ERR_OSS_TIMEOUT;	
	}

	/* sem->lock is locked here */
	{
		wait_queue_t __wait;
		init_waitqueue_entry(&__wait, current);	

		add_wait_queue( &sem->wq, &__wait);
		for (;;) {
			set_current_state(TASK_INTERRUPTIBLE);

			if( sem->value > 0 ){
				spin_unlock_irqrestore( &sem->lock, flags );
				break;
			}
			spin_unlock_irqrestore( &sem->lock, flags );

			if (!signal_pending(current)) {
				if( msec != OSS_SEM_WAITFOREVER ){
					ticks = schedule_timeout( ticks );
					if (!ticks)		/* time elapsed */
						break;
				}
				else {
					/* wait forever */
					schedule();
				}
			}
			else {
				/* signal pending */
				if( HandleSig( oss, &oldBlocked )){
					/* the signal was deadly, */
					error = ERR_OSS_SIG_OCCURED;
					break;
				}
				else {
					/* non deadly signal */
					oldBlockedValid = TRUE;
				}
			}
			spin_lock_irqsave( &sem->lock, flags );
		}
		set_current_state(TASK_RUNNING);
		remove_wait_queue( &sem->wq, &__wait);
	}

	/* sem->lock is unlocked here */
	spin_lock_irqsave( &sem->lock, flags );
	
	if( sem->value > 0 ){
		sem->value--;			/* ok, got the semaphore */
		DBGWRT_2((DBH, " got sem\n"));
		error = 0;
	}
	spin_unlock_irqrestore( &sem->lock, flags );

	if( error == 0 && ticks == 0 && msec != OSS_SEM_WAITFOREVER){
		DBGWRT_ERR((DBH,"*** %s timeout waiting for sem\n", functionName ));
		error = ERR_OSS_TIMEOUT;
	}

	if( oldBlockedValid ){
		TASK_LOCK_SIGNALS( current, flags );
		/* restore org. process signal mask */
		current->blocked = oldBlocked;
		RECALC_SIGPENDING();
		TASK_UNLOCK_SIGNALS( current, flags );
	}


    return error;
}/*OSS_SemWait*/



/**********************************************************************/
/** Signal semaphore.
 *
 * \copydoc oss_specification.c::OSS_SemSignal()
 *
 * See \ref linsemusagesect for more info.
 *
 * \linux \linrtai For RTAI implementation, see OSS_RtaiSemSignal().
 *
 * \sa OSS_SemCreate, OSS_SemRemove, OSS_SemWait
 */
int32 OSS_SemSignal(
    OSS_HANDLE *oss,
    OSS_SEM_HANDLE* sem)
{
	unsigned long flags;
    DBGCMD( static const char functionName[] = "OSS_SemSignal"; )

    DBGWRT_1((DBH,"%s() sem = 0x%p\n", functionName, sem ));

	spin_lock_irqsave( &sem->lock, flags );

	if( sem->semType == OSS_SEM_BIN )
		sem->value = 1;
	else
		sem->value++;

	spin_unlock_irqrestore( &sem->lock, flags );

	wake_up_interruptible( &sem->wq ); /* wake up any waiting processes */

    return(0);
}/*OSS_SemSignal*/


