/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_alarm_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:17:12 $
 *    $Revision: 2.6 $
 * 
 *	   \project  MDIS4LINUX/RTAI
 *  	 \brief  Alarm routines for RTAI
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_alarm_rtai.c,v $
 * Revision 2.6  2006/09/26 10:17:12  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.5  2005/07/07 17:17:06  cs
 * Copyright line changed
 *
 * Revision 2.4  2004/10/27 14:34:14  kp
 * don't allow to use FPU in alarm thread
 *
 * Revision 2.3  2003/06/06 09:19:59  kp
 * added OSS_AlarmMask etc.
 *
 * Revision 2.2  2003/04/11 16:13:42  kp
 * Comments changed to Doxygen
 * Filled functions with life
 *
 * Revision 2.1  2003/02/21 11:25:21  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#define _OSS_ALARM_C
#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT

/*! \page rtaiossalarmusage
 *
 * \section rtaiossalarmusagesect RTAI notes to OSS alarms
 *
 * Under RTAI, alarms are implemented using a separate task for each 
 * alarm routine.
 *
 * User's alaram function is called in the context of this task which
 * runs at a fixed priority of 1 (change TASK_PRIORITY define if you
 * don't like this).
 *
 * Cyclic alarms are implemented using the \c rt_task_make_periodic()a feature.
 *
 * Under Xenomai, Alarms are part of the native API and therefore MDIS Alarm
 * Services are implemented using these functions:
 *
 *  	rt_alarm_create		Create an alarm object from kernel space. 
 *		rt_alarm_delete		Delete an alarm. 
 *		rt_alarm_start		Start an alarm. 
 *		rt_alarm_stop     	Stop an alarm. 
 *
 * The granularity of alarm cycles depends on the scheduling algorithm
 * of RTAI.
 */

/*-----------------------------------------+
|  DEFINES                                 |
+------------------------------------------*/
#define TASK_PRIORITY 1			/* of alarm task */
#define USES_FPU      0			/* can use the FPU */
#define STACK_SIZE    4096		/* relatively small... */

/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/
#undef OSS_ALARM_HANDLE
#define OSS_ALARM_HANDLE OSS_RTAI_ALARM_HANDLE

typedef struct OSS_RTAI_ALARM_HANDLE
{
#ifdef MDIS_XENOMAI
	RT_ALARM alarm;				/* Xenomai has dedicated Alarm support 	*/
#else
	RT_TASK task;				/* the RTAI task that executes alarm 	*/
#endif
    void (*funct)(void *arg);	/* alarm routine to be called 			*/
	void *arg;					/* arg to pass to function 				*/
	int active;					/* timer routine started 				*/
	int cyclic;					/* flags cyclic alarm 					*/
	OSS_HANDLE *oss;
} OSS_RTAI_ALARM_HANDLE;

static void AlarmTask( int data );
int32 OSS_RtaiAlarmClear( OSS_HANDLE *oss, OSS_ALARM_HANDLE *alarm );

/**********************************************************************/
/** Create an alarm.
 *
 * \copydoc oss_specification.c::OSS_AlarmCreate()
 *
 * See \ref rtaiossalarmusagesect for more info.
 *
 * \linux \linrtai For Linux implementation, see OSS_AlarmCreate().
 *
 * \sa OSS_AlarmRemove, OSS_AlarmSet, OSS_AlarmClear
 */
int32 OSS_RtaiAlarmCreate( OSS_HANDLE *oss, void (*funct)(void *arg),
						   void *arg, OSS_ALARM_HANDLE **alarmP )
{
	OSS_ALARM_HANDLE *alm;

#ifdef MDIS_XENOMAI
	int retval = 0;
	char alarmName[XNOBJECT_NAME_LEN];
	sprintf( alarmName, "MDIS_RT_ALARM%08x",
			 (unsigned int)(rt_timer_read() & 0xffffffff ));
#endif

    DBGWRT_1((DBH,"OSS - OSS_RtaiAlarmCreate func=0x%p arg=0x%lx\n", 
			  funct, arg));

	*alarmP = NULL;

	/* alloc alarm structure */
	alm = men_rt_malloc( sizeof(*alm ));
	if( alm == NULL )
		return( ERR_OSS_MEM_ALLOC );
		
	memset( alm, 0, sizeof(*alm));
	
	alm->funct 	= funct;
	alm->arg	= arg;
	alm->oss	= oss;

#ifdef MDIS_XENOMAI /* Xenomai provides native Alarm services */
	if ( retval = rt_alarm_create(&alm->alarm, 
								  alarmName, 
								  (rt_alarm_t)funct, 
								  arg)) {
		switch (retval) {
		case -EPERM:
	        DBGWRT_ERR((DBH,"*** OSS_RtaiAlarmCreate: async Context!\n"));
			break;
		case -EEXIST:
			DBGWRT_ERR((DBH,"*** OSS_RtaiAlarmCreate: Name exist already!\n"));
			break;
		case -ENOMEM:
			DBGWRT_ERR((DBH,"*** OSS_RtaiAlarmCreate: no mem on rt heap\n"));
			break;
		default:
			DBGWRT_ERR((DBH,"*** OSS_RtaiAlarmCreate: unknown error!\n"));
		}
		return ERR_OSS_SIG_SEND;
	}

#else	/* classic RTAI emulates Alarms with regular tasks */

	if( rt_task_init(&alm->task, AlarmTask, (int)alm, STACK_SIZE, 
					 TASK_PRIORITY, USES_FPU, 0) != 0 ){
		rt_free(alm);
		return ERR_OSS_ALARM_CREATE;
	}
#endif

	*alarmP = alm;

	return ERR_SUCCESS;
}




/**********************************************************************/
/** Destroys alarm handle.
 *
 * \copydoc oss_specification.c::OSS_AlarmRemove()
 *
 * See \ref rtaiossalarmusagesect for more info.
 *
 * \linux \linrtai For Linux implementation, see OSS_AlarmRemove().
 *
 * \sa OSS_AlarmCreate, OSS_AlarmSet, OSS_AlarmClear
 */
int32 OSS_RtaiAlarmRemove( OSS_HANDLE *oss, OSS_ALARM_HANDLE **alarmP )
{
	int32 error;

    DBGWRT_1((DBH,"OSS - OSS_RtaiAlarmRemove alm=%p\n", *alarmP));

	/* de-activate alarm if activated */
	if ((*alarmP)->active && (error = OSS_RtaiAlarmClear(oss, *alarmP)))
		return(error);

#ifdef MDIS_XENOMAI
	rt_alarm_delete( &(*alarmP)->alarm );
#else
	rt_task_delete( &(*alarmP)->task );
#endif

	men_rt_free( *alarmP );
	*alarmP = NULL;

	return ERR_SUCCESS;
}

/**********************************************************************/
/** Activate an installed alarm routine
 *
 * \copydoc oss_specification.c::OSS_AlarmSet()
 *
 * See \ref rtaiossalarmusagesect for more info.
 *
 * \linux \linrtai For Linux implementation, see OSS_AlarmSet().
 *
 * \sa OSS_AlarmCreate, OSS_AlarmRemove, OSS_AlarmClear
 */
int32 OSS_RtaiAlarmSet( OSS_HANDLE *oss, OSS_ALARM_HANDLE *alarm, u_int32 msec,
						u_int32 cyclic, u_int32 *realMsecP )
{
	unsigned long rem;
	RTIME counts, interval;
	int32 error;

    DBGWRT_1((DBH,"OSS - OSS_AlarmSet: %p. a%s, msec=%d\n",
			  alarm, cyclic ? "cyclic":"single", msec));

	if( alarm == NULL )
		return(ERR_OSS_ALARM_SET);

	/* return error if already active */
	if (alarm->active) {
		DBGWRT_ERR((DBH," *** OSS_AlarmSet: alarm already active\n"));
		return(ERR_OSS_ALARM_SET);
	}

	/*--- round time, and correct for timer inaccuracy ---*/
	if( (error = OSS_RtaiMsToCount( msec, &counts )))
		return error;

	alarm->cyclic = cyclic;
	alarm->active = TRUE;

#ifdef MDIS_XENOMAI
	if (!alarm->cyclic)
		interval = TM_INFINITE;	/* makes Xenomai Alarms execute just once */
	else
		interval = counts;

	rt_alarm_start( &alarm->alarm, rt_timer_read() + counts, interval);
#else
	rt_task_make_periodic( &alarm->task, rt_get_time() + counts, counts );
#endif
	
	/* determine realMs value */
	counts = ulldiv( men_cnt2nano(counts), 1E6, &rem );
	if( rem >= 500000 )	
		counts++;

	*realMsecP = (int32)counts;

	return ERR_SUCCESS;
}

/**********************************************************************/
/** Deactivate an installed alarm routine
 *
 * \copydoc oss_specification.c::OSS_AlarmClear()
 *
 * See \ref rtaiossalarmusagesect for more info.
 *
 * \linux \linrtai For Linux implementation, see OSS_AlarmClear().
 *
 * \sa OSS_AlarmCreate, OSS_AlarmRemove, OSS_AlarmSet
 */
int32 OSS_RtaiAlarmClear(
    OSS_HANDLE       *oss,
    OSS_ALARM_HANDLE *alarm
)
{
    DBGWRT_1((DBH,"OSS - OSS_RtaiAlarmClear %p\n", alarm));

	if( (alarm==NULL) || (!alarm->active) ){
		DBGWRT_ERR((DBH," *** OSS_RtaiAlarmClear: alarm not active\n"));
		return(ERR_OSS_ALARM_CLR);
	}
	
#ifdef MDIS_XENOMAI
	if ( rt_alarm_stop(&alarm->alarm) < 0)
		DBGWRT_ERR((DBH, " *** OSS_RtaiAlarmClear: Alarm invalid/deleted!\n"));
#else
	rt_task_suspend( &alarm->task ); /* stop alarm task */
#endif
	alarm->active = FALSE;

	return ERR_SUCCESS;
}

/**********************************************************************/
/** Mask alarms
 *
 * \copydoc oss_specification.c::OSS_AlarmMask()
 *
 * \rtai Masks \b all processor interrupts
 * \linrtai For Linux implementation, see OSS_AlarmMask().
 * \sa OSS_AlarmRestore()
 */
OSS_ALARM_STATE OSS_RtaiAlarmMask( OSS_HANDLE *oss )
{
	OSS_ALARM_STATE flags;

	DBGWRT_1((DBH,"OSS_AlarmMask (RTAI)\n"));

	flags = rt_global_save_flags_and_cli();	/* mask interrupts */
	return flags;
}

/**********************************************************************/
/** Unmask alarms
 *
 * \copydoc oss_specification.c::OSS_AlarmRestore()
 * \linux \linrtai For Linux implementation, see OSS_AlarmRestore().
 *
 * \sa OSS_AlarmMask()
 */
void OSS_RtaiAlarmRestore( OSS_HANDLE *oss, OSS_ALARM_STATE oldState )
{
	DBGWRT_1((DBH,"OSS_AlarmRestore (RTAI)\n"));
	rt_global_restore_flags( oldState );
}

#ifndef MDIS_XENOMAI
/*
 * Alarms in Xenomai directly execute Function alarm->funct(void *arg)
 */

/******************************** AlarmTask **********************************
 *
 *  Description: Alarm task
 *
 *---------------------------------------------------------------------------
 *  Input......: data	    alarm handle
 *  Output.....: -
 *  Globals....: -
 ****************************************************************************/

static void AlarmTask( int data )
{
	OSS_ALARM_HANDLE *alarm = (OSS_ALARM_HANDLE *)data;
#ifdef DBG
	OSS_HANDLE *oss = alarm->oss;
#endif
	while(1){
		DBGWRT_3((DBH,">>> alarm handler\n"));
	
		/* jump into installed function */
		alarm->funct(alarm->arg);		

		if (!alarm->cyclic){
			/* mark single-alarm as inactive */
			alarm->active 	= 	FALSE;
			rt_task_suspend( men_rt_this());
		}
		else {
			/* suspend until next period */
			rt_task_wait_period();
		}
	}
}
#endif /* MDIS_XENOMAI */

#endif /* MDIS_RTAI_SUPPORT */

