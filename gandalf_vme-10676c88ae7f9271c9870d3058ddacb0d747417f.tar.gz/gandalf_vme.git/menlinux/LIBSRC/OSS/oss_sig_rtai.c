/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_sig_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:19:18 $
 *    $Revision: 2.5 $
 * 
 *	   \project  MDIS4Linux
 *  	 \brief  Signal routines for RTAI
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_sig_rtai.c,v $
 * Revision 2.5  2006/09/26 10:19:18  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.4  2005/07/07 17:17:37  cs
 * Copyright line changed
 *
 * Revision 2.3  2004/12/09 09:46:06  ts
 * adapted for RTAI 3.0
 *
 * Revision 2.2  2003/04/11 16:13:50  kp
 * Comments changed to Doxygen
 *
 * Revision 2.1  2003/02/21 11:25:24  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#define _OSS_SIG_C
#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT
#include <MEN/oss_rtai_sig.h>


/*! \page rtaisigusage

  \section rtaisigusagesect RTAI notes to OSS signals

  Since RTAI has no native signals, the RTAI OSS library emulates 
  signals together with the \em USR_OSS library. 

  For every task that wishes to receive signals a second task is
  started. This signal task will have a priority one higher than the
  original task (Unless the org. tasks priority is <= 1). For example,
  if the original task has prio 10, the signal handler task will have
  prio 9. The only purpose of the signal task is to execute the user's
  signal handler which is called asynchronously to the program flow of
  the original task.

  An RTAI \em mailbox provides the communication between the driver(s)
  and the signal task. This mailbox has a fixed number of signal entries
  that it can buffer, defined at compile time, typically 64. You can
  change this by modifying #SIG_TASK_TBL_ENTRIES.

  \subsection rtainativesig Native signal handling

  An alternative method to handle signals under RTAI is provided.
  When an application uses this method, it is no longer portable
  across OSes supported by MDIS. 

  Instead of starting a separate task, the application can directly
  read from the signal mailbox. This method provides a synchronous
  communication between driver(s) and application. 

  To use native signal handling, application must call UOS_RtaiSigInit()
  which returns a handle for the created mailbox:

  \code
    MBOX mbx;
	u_int32 sigCode;

    error = UOS_RtaiSigInit( &mbx );
	// wait for signals
	rt_mbx_receive( &mbx, &sigCode, sizeof(sigCode));
  \endcode	

  Under Xenomai (=RTAI/fusion) Mailboxes dont exist, instead Message queues are
  used. The usage is the same, with the difference that for using Xenomai the
  address of an RT_QUEUE struct is passed to UOS_RtaiSigInit() and the other
  Functions who expect a MBX struct address in classic RTAI usage.
  

  \code
  //Xenomai example
  RT_QUEUE q;
  u_int32 sigCode;	

  error = UOS_RtaiSigInit( &q );
  // wait for signals
  rt_queue_recv( &q, &sigCode, sizeof(sigCode));
  \endcode	

  See \ref osssigusagesect for more info.
*/

/*

Comparing of Queue Interface from Xenomai with RTAI classic Mailboxes:

int rt_queue_create(RT_QUEUE *q, 
                    const char *name, size_t poolsize,
                    size_t qlimit, 
					int mode);

int rt_queue_delete(RT_QUEUE *q);
void *rt_queue_alloc(RT_QUEUE *q, size_t size);
int rt_queue_free(RT_QUEUE *q, void *buf);
int rt_queue_send(RT_QUEUE *q, void *buf, size_t size, int mode);
ssize_t rt_queue_recv(RT_QUEUE *q, void **bufp, RTIME timeout);

int rt_queue_inquire(RT_QUEUE *q, RT_QUEUE_INFO *info);



Classic RTAI Mailbox functions

int rt_typed_mbx_init(struct rt_mailbox *mbx, int size, int qtype);
int rt_mbx_init(struct rt_mailbox *mbx, int size);
int rt_mbx_delete(struct rt_mailbox *mbx);
int rt_mbx_send(struct rt_mailbox *mbx,void *msg,int msg_size);
int rt_mbx_send_wp(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_send_if(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_send_until(struct rt_mailbox *mbx, void *msg, int msg_size,
		      RTIME time);
int rt_mbx_send_timed(struct rt_mailbox *mbx, void *msg, int msg_size,
		      RTIME delay);

int rt_mbx_ovrwr_send(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_evdrp(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_receive(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_receive_wp(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_receive_if(struct rt_mailbox *mbx, void *msg, int msg_size);
int rt_mbx_receive_until(struct rt_mailbox *mbx, void *msg, int msg_size,
			 RTIME time);
int rt_mbx_receive_timed(struct rt_mailbox *mbx, void *msg, int msg_size,
			 RTIME delay);

*/




/*-----------------------------------------+
|  DEFINES                                 |
+------------------------------------------*/

#define SIG_TASK_TBL_ENTRIES	64 /**< number of max signals in mailbox */

/*-----------------------------------------+
|  GLOBALS                                 |
+------------------------------------------*/

/** hash table to register tasks for (emulated) signal handling.  
 * table indexed by task hash value.
 * The double linked lists links entries of type OSS_RTAI_TASK_SIG 
 * with the same hash value.
 */
static OSS_DL_LIST G_sigTaskTbl[SIG_TASK_TBL_ENTRIES]; 

static SEM G_sigTblSem;	/* semaphore to lock accesses to G_sigTaskTbl */
static int G_useCount;
/*-----------------------------------------+
|  TYPEDEFS                                |
+------------------------------------------*/
#undef OSS_SIG_HANDLE
#define OSS_SIG_HANDLE OSS_RTAI_SIG_HANDLE

typedef struct OSS_RTAI_SIG_HANDLE
{
	OSS_DL_NODE node;
	RT_TASK 	*task;
#ifdef MDIS_XENOMAI
	RT_QUEUE	*queue;
#else
	MBX 		*mbx;
#endif
	int32 		sig;
} OSS_RTAI_SIG_HANDLE;


/**********************************************************************/
/** Basic initialisation of RTAI signalling subsystem
 *
 * Internally called from OSS_Init().
 *
 * \param oss 			\IN OSS handle, returned by OSS_Init()
 */
void OSS_RtaiSigInitialInit( OSS_HANDLE *oss )
{

    DBGWRT_1((DBH,"%s:\n", __FUNCTION__));

	if( G_useCount == 0 ){
		int i;

		men_rt_sem_init( &G_sigTblSem, 1 );
		for( i=0; i<SIG_TASK_TBL_ENTRIES; i++ )
			OSS_DL_NewList( &G_sigTaskTbl[i] );
	}
	G_useCount++;
}

/**********************************************************************/
/** Final termination of RTAI signalling subsystem
 *
 * Internally called from OSS_Exit().
 *
 * \param oss 			\IN OSS handle, returned by OSS_Init()
 */
void OSS_RtaiSigFinalExit( OSS_HANDLE *oss )
{

    DBGWRT_1((DBH,"%s:\n", __FUNCTION__));

	if( --G_useCount == 0 )
		rt_sem_delete( &G_sigTblSem );
}

/** compute hash value of \a task in range 0..SIG_TASK_TBL_ENTRIES-1 */
static inline int TaskHashValue( const RT_TASK *task )
{
	u_int32 n = (u_int32)task;

	return (((n & 0xff000000)>>24) + ((n & 0xff0000)>>16) +
			((n & 0xff00)>>8) + (n & 0xff)) %  SIG_TASK_TBL_ENTRIES;
}

/**********************************************************************/
/** find the OSS_RTAI_SIG_TASK entry of \a task in G_sigTaskTbl 
 *
 * internally called and called by the \em USR_OSS module
 *
 * \param task			\IN task to query 
 * \return 	pointer to task's signal entry in G_sigTaskTbl or NULL if
 * 			no entry exists.
 */
OSS_RTAI_SIG_TASK *OSS_TaskToSigEntry( const RT_TASK *task )
{
	OSS_RTAI_SIG_TASK *entry;

	men_rt_sem_get_forever(&G_sigTblSem);

	entry = (OSS_RTAI_SIG_TASK*)G_sigTaskTbl[ TaskHashValue( task ) ].head;

	while( entry->node.next ){
		if( entry->task == task )
			break;
		entry = (OSS_RTAI_SIG_TASK*)entry->node.next;
	}
	men_rt_sem_put(&G_sigTblSem);

	return entry->node.next == NULL ? NULL : entry;
}

/**********************************************************************/
/** Register task for signal handling
 *
 * called from UOS_SigInit() to register a task for signal handling.
 * Creates an OSS_RTAI_SIG_TASK structure and adds it to the G_sigTaskTbl
 * list. In Xenomai the Signals are passed to the Tasks via message queues.
 *
 * \param mbx \IN mailbox to use for that task
 * \return 0 on success or \c ERR_OSS_xxx error code on error:
 *				- \c ERR_OSS_BUSY_RESOURCE: task already registered
 *
 */
#ifdef MDIS_XENOMAI
int32 OSS_RtaiSigTaskRegister( RT_QUEUE *queue )
#else
int32 OSS_RtaiSigTaskRegister( MBX *mbx )
#endif /* MDIS_XENOMAI */
{
	OSS_RTAI_SIG_TASK *entry;
	OSS_DL_LIST *lst;

	if( OSS_TaskToSigEntry( men_rt_this()) != NULL )
		return ERR_OSS_BUSY_RESOURCE; /* task already registered */

	entry = men_rt_malloc( sizeof(OSS_RTAI_SIG_TASK) );
	if( !entry )
		return ERR_OSS_MEM_ALLOC;
	
	OSS_DL_NewList( &entry->sigList );

	entry->task 		= men_rt_this();

#ifdef MDIS_XENOMAI
	entry->queue  		= queue;
#else
	entry->mbx  		= mbx;
#endif

	entry->sigTask 		= NULL;
	entry->sigHandler 	= NULL;

	lst = &G_sigTaskTbl[ TaskHashValue( entry->task ) ];

	men_rt_sem_get_forever(&G_sigTblSem);
	OSS_DL_AddTail( lst, &entry->node );
	men_rt_sem_put(&G_sigTblSem);
	
	return 0;
}




/**********************************************************************/
/** Unregister task from signal handling
 * called from UOS_SigExit()
 * \param mbxP 	\OUT pointer to var where pointer to the task's mailbox will
 *					 be stored. This mailbox must be deleted by caller
 * \return 0 on success or \c ERR_OSS_xxx error code on error:
 *				- \c ERR_OSS_UNK_RESOURCE: task not registered
 */

#ifdef MDIS_XENOMAI
int32 OSS_RtaiSigTaskUnregister( RT_QUEUE **queueP )
{
	OSS_RTAI_SIG_TASK *entry;
	OSS_RTAI_SIG_HANDLE *sh;

	*queueP = NULL;
	if( (entry = OSS_TaskToSigEntry( men_rt_this())) == NULL )
		return ERR_OSS_UNK_RESOURCE; /* task not registered */
	*queueP = entry->queue;

	/* remove task sig entry from list */
	men_rt_sem_get_forever(&G_sigTblSem);
	OSS_DL_Remove( &entry->node );
	men_rt_sem_put(&G_sigTblSem);

	/* mark all installed signals as invalid */
	for( sh = (OSS_RTAI_SIG_HANDLE *)entry->sigList.head; sh->node.next;
		 sh = (OSS_RTAI_SIG_HANDLE *)sh->node.next ){
		sh->queue = NULL;
	}
	men_rt_free( entry );

	return 0;
}
#else
int32 OSS_RtaiSigTaskUnregister( MBX **mbxP )
{
	OSS_RTAI_SIG_TASK *entry;
	OSS_RTAI_SIG_HANDLE *sh;

	*mbxP = NULL;
	if( (entry = OSS_TaskToSigEntry( men_rt_this())) == NULL )
		return ERR_OSS_UNK_RESOURCE; /* task not registered */

	*mbxP = entry->mbx;

	/* remove task sig entry from list */
	men_rt_sem_get_forever(&G_sigTblSem);
	OSS_DL_Remove( &entry->node );
	men_rt_sem_put(&G_sigTblSem);

	/* mark all installed signals as invalid */
	for( sh = (OSS_RTAI_SIG_HANDLE *)entry->sigList.head; sh->node.next;
		 sh = (OSS_RTAI_SIG_HANDLE *)sh->node.next ){
		sh->mbx = NULL;
	}
	men_rt_free( entry );
	return 0;
}
#endif

/**********************************************************************/
/** Create signal handle.
 * 
 * \copydoc oss_specification.c::OSS_SigCreate()
 *
 * See \ref rtaisigusagesect for more info.
 *
 * \rtai \linrtai For RTAI implementation, see OSS_RtaiSigCreate().
 *
 * \sa OSS_RtaiSigRemove, OSS_RtaiSigSend
 */
int32 OSS_RtaiSigCreate(
    OSS_HANDLE       *oss,
    int32            signal,
    OSS_SIG_HANDLE   **sigP)
{
	OSS_SIG_HANDLE *sig;
	OSS_RTAI_SIG_TASK *entry;

    DBGWRT_1((DBH,"OSS - OSS_RtaiSigCreate: sig=0x%ld proc=0x%08x\n",
			  (long)signal,(long)men_rt_this() ));
	*sigP = NULL;

	if( (entry = OSS_TaskToSigEntry( men_rt_this())) == NULL )
		return ERR_OSS_SIG_SET;	/* task not registered */

	/* allocate memory for handle */
	sig = (OSS_SIG_HANDLE *)men_rt_malloc( sizeof(OSS_SIG_HANDLE));
	if( sig == NULL )
		return( ERR_OSS_MEM_ALLOC );

	sig->task 	= men_rt_this();

#ifdef MDIS_XENOMAI
	sig->queue 	= entry->queue;
#else
	sig->mbx 	= entry->mbx;
#endif

	sig->sig 	= signal;
	OSS_DL_AddTail( &entry->sigList, &sig->node );

	*sigP = sig;
	return 0;
}/*OSS_RtaiSigCreate*/

/**********************************************************************/
/** Destroy semaphore handle.
 *
 * \copydoc oss_specification.c::OSS_SigRemove()
 *
 * See \ref rtaisigusagesect for more info.
 *
 * \rtai \linrtai For RTAI implementation, see OSS_RtaiSigRemove().
 *
 * \sa OSS_RtaiSigCreate, OSS_RtaiSigSend
 */
int32 OSS_RtaiSigRemove(
    OSS_HANDLE     *oss,
    OSS_SIG_HANDLE **sigP)
{
    OSS_SIG_HANDLE *sig = *sigP;

    DBGWRT_1((DBH,"OSS - OSS_RtaiSigRemove: sig=%ld proc=0x%08x\n",
			  (long)sig->sig,(long)sig->task));

	if (sig->task != men_rt_this()) {		/* invalid process ? */
		DBGWRT_ERR((DBH," *** OSS_RtaiSigRemove: can't remove signal: "
					"wrong own pid\n"));
        return(ERR_OSS_SIG_CLR);
	}

	/* clear pointer before deallocating the handle to     */
	/* prevent interferences if interrupted by OSS_RtaiSigSend */
	*sigP = NULL;
	OSS_DL_Remove( &sig->node );
	men_rt_free( sig );
    return 0;
}




/**********************************************************************/
/** Send signal to a process
 * 
 * \copydoc oss_specification.c::OSS_SigSend()
 *
 * See \ref rtaisigusagesect for more info.
 *
 * \rtai \linrtai For RTAI implementation, see OSS_RtaiSigSend().
 *
 * \sa OSS_RtaiSigCreate, OSS_RtaiSigRemove
 */
int32 OSS_RtaiSigSend(
    OSS_HANDLE *oss,
    OSS_SIG_HANDLE* sig)
{
	int retval = 0;
    DBGWRT_1((DBH,"OSS - OSS_RtaiSigSend: sig=%ld proc=0x%08x\n",
			  (long)sig->sig, (long)sig->task));

#ifdef MDIS_XENOMAI	
	if( sig == NULL || sig->queue == NULL )
		return ERR_OSS_SIG_SEND;

	/* send to message queue in normal FIFO mode, signals have 32bit.  
	 * retval of rt_queue_send in Xenomai is different. API
	 * Documentation states:
	 * Upon success, [...] returns the number of receivers which got awaken 
	 * as a result of the operation. If zero is returned, no task was waiting 
	 * on the receiving side of the queue, and the message has been enqueued. 
	 * Upon error, one of the following error codes is returned:
	 *	-EINVAL is returned if q is not a message queue descriptor.
	 *	-EIDRM is returned if q is a deleted queue descriptor.
	 *	-ENOMEM is returned if queuing the message would exceed the limit 
	 *	defined for the queue at creation.
	 */
	retval = rt_queue_send(sig->queue,(void*)&sig->sig,sizeof(int32),Q_NORMAL);

	if (retval < 0) {
		switch (retval) {
		case -EINVAL:
			DBGWRT_ERR((DBH,"*** OSS_RtaiSigSend: invalid Queue Desc.!\n"));
			break;
		case -EIDRM:
			DBGWRT_ERR((DBH,"*** OSS_RtaiSigSend: Queue Desc. is deleted!\n"));
			break;
		case -ENOMEM:
			DBGWRT_ERR((DBH,"*** OSS_RtaiSigSend: exhausted Queue Memory!\n"));
			break;
		default:
			DBGWRT_ERR((DBH,"*** OSS_RtaiSigSend: unknown error!\n"));
		}
		return ERR_OSS_SIG_SEND;
	}

	/* ??? retval = 0: No task waited according to API Documentation but 
	 *   that might be ok, the Userspace App might be started somewhat later 
	 */

#else
	if( sig == NULL || sig->mbx == NULL )
		return ERR_OSS_SIG_SEND;

	/* send to mailbox, don't block. retval here represents unsent bytes */
	retval = rt_mbx_send_wp( sig->mbx, &sig->sig, sizeof(int32) );

	if( retval != 0 ){
		DBGWRT_ERR((DBH,"*** OSS_RtaiSigSend: sig=%ld to proc=0x%08x lost\n",
					(long)sig->sig,(long)sig->task));
		return ERR_OSS_SIG_SEND;
	}

#endif
	
	return 0;
}
	

/**********************************************************************/
/** Get info about signal
 *
 * \copydoc oss_specification.c::OSS_SigInfo()
 */
int32 OSS_RtaiSigInfo(
    OSS_HANDLE     *oss,
    OSS_SIG_HANDLE *sig,
    int32          *signalP,
    int32          *pidP)
{
	*signalP = sig->sig;
	*pidP    = (int32)sig->task;

	return 0;
}


EXPORT_SYMBOL(OSS_RtaiSigTaskUnregister);
EXPORT_SYMBOL(OSS_RtaiSigTaskRegister);
EXPORT_SYMBOL(OSS_TaskToSigEntry);


#endif /* MDIS_RTAI_SUPPORT */
