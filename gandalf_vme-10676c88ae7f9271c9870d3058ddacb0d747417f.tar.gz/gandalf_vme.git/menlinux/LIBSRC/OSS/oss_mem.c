/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_mem.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2005/07/07 17:17:24 $
 *    $Revision: 1.4 $
 * 
 *	   \project  MDIS4Linux
 *  	 \brief  Memory handling functions of the OSS module
 *      
 *    \switches  MDIS_RTAI_SUPPORT 
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_mem.c,v $
 * Revision 1.4  2005/07/07 17:17:24  cs
 * Copyright line changed
 *
 * Revision 1.3  2003/04/11 16:13:27  kp
 * Comments changed to Doxygen
 *
 * Revision 1.2  2003/02/21 11:25:11  kp
 * added RTAI dispatching functions
 *
 * Revision 1.1  2001/01/19 14:39:13  kp
 * Initial Revision
 *---------------------------------------------------------------------------
 * (c) Copyright 2000-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/
#include "oss_intern.h"

/*
 * Dispatcher functions. They switch between the std linux or RT 
 * implementations depending of the oss->rtMode flag
 */
#ifdef MDIS_RTAI_SUPPORT
void *OSS_LinMemGet( OSS_HANDLE*, u_int32, u_int32 *);
int32 OSS_LinMemFree( OSS_HANDLE *, void *, u_int32 );
void *OSS_RtaiMemGet( OSS_HANDLE*, u_int32, u_int32 *);
int32 OSS_RtaiMemFree( OSS_HANDLE *, void *, u_int32 );

void* OSS_MemGet(
    OSS_HANDLE  *oss,
    u_int32     size,
    u_int32     *gotsizeP
)
{
	if( oss->rtMode )
		return OSS_RtaiMemGet( oss, size, gotsizeP );
	else
		return OSS_LinMemGet( oss, size, gotsizeP );
}

int32 OSS_MemFree(
    OSS_HANDLE *oss,
    void       *addr,
    u_int32    size
)
{
	if( oss->rtMode )
		return OSS_RtaiMemFree( oss, addr, size );
	else
		return OSS_LinMemFree( oss, addr, size );
}

#undef  OSS_MemGet
#define OSS_MemGet 		OSS_LinMemGet

#undef	OSS_MemFree
#define OSS_MemFree 	OSS_LinMemFree

#endif /* MDIS_RTAI_SUPPORT */

/**********************************************************************/
/** Allocates general memory block.	
 *
 * \copydoc oss_specification.c::OSS_MemGet()
 *
 * \linux Puts calling process to sleep if no free pages available (i.e.
 *	should never return NULL). 
 *
 * \linrtai See OSS_RtaiMemGet()
 *
 * \sa OSS_MemFree
 */
void* OSS_MemGet(
    OSS_HANDLE  *oss,
    u_int32     size,
    u_int32     *gotsizeP
)
{

	void *mem = kmalloc( size, GFP_KERNEL );
	if( mem != NULL )
		*gotsizeP = size;
	else
		*gotsizeP = 0;

	DBGWRT_1((DBH,"OSS_MemGet (Lin): size=0x%lx allocated addr=0x%p\n", 
			  size, mem ));
	return mem;
}/*OSS_MemGet*/

/**********************************************************************/
/** Return memory block.
 *
 * \copydoc oss_specification.c::OSS_MemFree()
 *
 * \linux \linrtai See OSS_RtaiMemFree()
 * \sa OSS_MemGet
 */
int32 OSS_MemFree(
    OSS_HANDLE *oss,
    void       *addr,
    u_int32    size
)
{
	DBGWRT_1((DBH,"OSS_MemFree (Lin): addr=0x%p size=0x%lx\n", addr, size));
	kfree(addr);
    return(0);
}/*OSS_MemFree*/


/**********************************************************************/
/** Check if memory block accessible by caller
 *
 * \copydoc oss_specification.c::OSS_MemChk()
 *
 * \linux This function is a no-op. When used in MDIS context, all user
 * buffers are copied first from user space and are therefore always
 * valid kernel addresses.
 */
int32 OSS_MemChk(
    OSS_HANDLE *oss,
    void       *addr,
    u_int32    size,
    int32      mode)
{
	return 0;
}


