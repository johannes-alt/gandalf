/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  oss_irq_rtai.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/09/26 10:17:31 $
 *    $Revision: 2.4 $
 * 
 *	   \project  MDIS4Linux/RTAI
 *  	 \brief  Interrupt related routines
 *      
 *    \switches  MDIS_RTAI_SUPPORT - must be set to enable this code
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: oss_irq_rtai.c,v $
 * Revision 2.4  2006/09/26 10:17:31  ts
 * adapted for either classic RTAI or Xenomai usage
 *
 * Revision 2.3  2005/07/07 17:17:18  cs
 * Copyright line changed
 *
 * Revision 2.2  2003/04/11 16:13:44  kp
 * Comments changed to Doxygen
 * added new OSS_IrqMaskR etc.
 *
 * Revision 2.1  2003/02/21 11:27:03  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003-2005 by MEN Mikro Elektronik GmbH, Nuremberg, Germany
 ****************************************************************************/

#include "oss_intern.h"

#ifdef MDIS_RTAI_SUPPORT
/*-----------------------------------------+
|  STATICS                                 |
+------------------------------------------*/
static int G_irqDisabled = 0;	/* nesting counter */
static int G_savedFlags;

/**********************************************************************/
/** Mask device interrupts.
 * \copydoc oss_specification.c::OSS_IrqMaskR()
 *
 * \rtai Masks \b all processor interrupts
 * \linrtai For Linux implementation, see OSS_IrqMaskR().
 * \sa OSS_RtaiIrqRestore()
 */
OSS_IRQ_STATE OSS_RtaiIrqMaskR( OSS_HANDLE *oss, OSS_IRQ_HANDLE* irqHandle )
{
	OSS_IRQ_STATE flags;

	DBGWRT_1((DBH,"OSS_IrqMaskR (RTAI)\n"));

	flags = rt_global_save_flags_and_cli();	/* mask interrupts */

	return flags;
}

/**********************************************************************/
/** Unmask device interrupts.
 * \copydoc oss_specification.c::OSS_IrqRestore()
 * \rtai \linrtai For RTAI implementation, see OSS_IrqRestore().
 *
 * \sa OSS_RtaiIrqMaskR()
 */
void OSS_RtaiIrqRestore( 
	OSS_HANDLE *oss, 
	OSS_IRQ_HANDLE* irqHandle, 
	OSS_IRQ_STATE oldState )
{
	DBGWRT_1((DBH,"OSS_IrqUnMaskR (RTAI)\n"));
	rt_global_restore_flags( oldState );
}

/**********************************************************************/
/** Mask device interrupts (old implementation).
 * \copydoc oss_specification.c::OSS_IrqMask()
 *
 * \rtai Masks \b all processor interrupts
 * \linrtai For Linux implementation, see OSS_IrqMask().
 * \sa OSS_RtaiIrqUnMask()
 */
void OSS_RtaiIrqMask( OSS_HANDLE *oss, OSS_IRQ_HANDLE* irqHandle )
{
	int flags;

	DBGWRT_1((DBH,"OSS_IrqMask (RTAI)\n"));

	flags = rt_global_save_flags_and_cli();	/* mask interrupts */

	if( G_irqDisabled++ == 0 ){
		G_savedFlags = flags;
	}
	else {
		/* programmer's error */
		DBGWRT_3((DBH,"*** OSS_IrqMask RTAI: Irq already disabled\n"));
	}
}/*OSS_IrqMask*/

/**********************************************************************/
/** Unmask device interrupts (old implementation).
 * \copydoc oss_specification.c::OSS_IrqUnMask()
 * \rtai \linrtai For Linux implementation, see OSS_IrqUnMask().
 * \sa OSS_RtaiIrqMask()
 */
void OSS_RtaiIrqUnMask( OSS_HANDLE *oss, OSS_IRQ_HANDLE *irqHandle )
{
	int flags;
	DBGWRT_1((DBH,"OSS_IrqUnMask (RTAI)\n"));

	if( G_irqDisabled == 0 ){
		/* programmer's error */
		DBGWRT_ERR((DBH,"*** OSS_IrqUnMask RTAI: Irq not disabled\n"));
		return;
	}

	if( --G_irqDisabled == 0 ){
		flags = G_savedFlags;
		rt_global_restore_flags(flags);
	}
				
}/*OSS_IrqUnMask*/

#endif /* MDIS_RTAI_SUPPORT */


