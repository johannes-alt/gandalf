/***********************  I n c l u d e  -  F i l e  ************************
 *  
 *         Name: usr_oss_int.h
 *
 *       Author: kp
 *        $Date: 2006/12/15 13:02:31 $
 *    $Revision: 1.3 $
 * 
 *  Description: UOS internal include file
 *                      
 *     Switches: UOS_GLOBAL - if set, instanciate global variables
 *
 *-------------------------------[ History ]---------------------------------
 *
 * $Log: uos_int.h,v $
 * Revision 1.3  2006/12/15 13:02:31  ts
 * replaced several RTAI includes by <MEN/men_mdis_rt.h>
 *
 * Revision 1.2  2004/10/27 14:35:13  kp
 * RTAI 3.0 adaption
 *
 * Revision 1.1  2003/04/11 16:17:09  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#ifndef _UOS_INT_H
#define _UOS_INT_H

#define __NO_VERSION__

#include <linux/module.h>
#include <MEN/sysdep.h>

#include <MEN/men_mdis_rt.h>

#include <MEN/RTAI_STDC/stdio.h>
#include <MEN/RTAI_STDC/stdlib.h>

#include <MEN/men_typs.h>
#include <MEN/mdis_api.h>
#include <MEN/dbg.h>
#include <MEN/oss.h>
#include <MEN/oss_rtai_sig.h>
#include <MEN/usr_oss.h>
#include <MEN/usr_err.h>
#include <MEN/rtagent.h>


#ifndef UOS_GLOBAL
# define GLOBAL extern
#else
# define GLOBAL
#endif

GLOBAL OSS_HANDLE *UOS_osh;			/* OSS handle */

int __dtostr(double d,char *buf,unsigned int maxlen,unsigned int prec,unsigned int prec2);
int __lltostr(char *s, int size, unsigned long long i, int base, char UpCase);
int __ltostr(char *s, unsigned int size, unsigned long i, unsigned int base, int UpCase);


#endif /* _UOS_INT_H */
