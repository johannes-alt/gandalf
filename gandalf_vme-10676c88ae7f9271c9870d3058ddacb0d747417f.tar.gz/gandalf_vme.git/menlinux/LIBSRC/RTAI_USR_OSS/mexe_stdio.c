/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  mexe_stdio.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2003/06/06 09:36:37 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  Provides some C-stdio library calls 
 *				 (executed through mdis_rtagent)
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: mexe_stdio.c,v $
 * Revision 1.2  2003/06/06 09:36:37  kp
 * changed headers for doxygen
 *
 * Revision 1.1  2003/04/11 16:17:03  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#include "uos_int.h"

/**********************************************************************/
/** Check if any key pressed on console
 * 
 * \copydoc usr_oss_specification.c::UOS_KeyPressed()
 *
 * \rtai This function is performed through an MEXE service, which 
 * requires that the RTAI application has been linked with rtai_mexe.c
 * and \b mdis_rtagent runs in linux user space.
 *
 * \sa UOS_KeyWait
 */
int32 UOS_KeyPressed( void )
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_CHECKKEY, 0 );
	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return -1;
	
	return rspSdb.u.rsp.param.l;
}

/**********************************************************************/
/** Wait until any key pressed on console
 * 
 * \copydoc usr_oss_specification.c::UOS_KeyWait()
 *
 * \rtai This function is performed through an MEXE service, which 
 * requires that the RTAI application has been linked with rtai_mexe.c
 * and \b mdis_rtagent runs in linux user space.
 *
 * \sa UOS_KeyPressed
 */
int32 UOS_KeyWait( void )
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_WAITKEY, 0 );
	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return -1;
	
	return rspSdb.u.rsp.param.l;
}


/**********************************************************************/
/** perform fgets through mdis_rtagent
 * 
 * size is limited to \c RTA_MAX_DATALEN.
 * Mainly used to read a line from stdin (or file)
 */
char *fgets(char *s, int size, FILE *fp)
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FGETS, 0 );
	reqSdb.u.req.param1.vp = fp;
	reqSdb.u.req.param2.i = size;
	
	if( MexeService( &reqSdb, NULL, &rspSdb, s ) != 0 ){
		rt_printk("fgets (1)\n");
		return NULL;
	}

	if( rspSdb.u.rsp.errNum != 0 ){
		rt_printk("fgets errnum=%d\n",rspSdb.u.rsp.errNum );
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );
		return NULL;
	}
	return s;
}

/**********************************************************************/
/** open file through mdis_rtagent
 * 
 */
FILE *fopen (const char *path, const char *mode)
{
	char buf[RTA_MAX_DATALEN];
	RTA_SDB reqSdb, rspSdb;
	int len1=strlen(path), len2=strlen(mode);

	if( len1 + len2 + 2 > RTA_MAX_DATALEN )
		return NULL;

	strcpy( buf, path );
	strcpy( buf + strlen(path) + 1, mode );

	RTA_SDB_REQ( &reqSdb, RTA_FOPEN, len1 + len2 + 2);
	
	if( MexeService( &reqSdb, buf, &rspSdb, NULL ) != 0 )
		return NULL;

	if( rspSdb.u.rsp.param.vp == NULL ){
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );
		return NULL;
	}
	return (FILE*)rspSdb.u.rsp.param.vp;
}

/**********************************************************************/
/** close file through mdis_rtagent
 * 
 */
int fclose( FILE *fp )
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FCLOSE, 0 );
	reqSdb.u.req.param1.vp = fp;

	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return EOF;
	
	if( rspSdb.u.rsp.param.i != 0 )
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );

	return rspSdb.u.rsp.param.i;
}

/**********************************************************************/
/** do fread through mdis_rtagent
 * 
 */
size_t fread( void *ptr, size_t size, size_t nmemb, FILE *fp )
{
	int bytes = size * nmemb;
	int remain = bytes;
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FREAD, 0 );
	reqSdb.u.req.param1.vp = fp;

	while( remain ){
		long curLen = remain > RTA_MAX_DATALEN ? RTA_MAX_DATALEN : remain;

		reqSdb.u.req.param2.l = curLen;

		rt_printk("fread dl=%d p=%p\n", curLen, ptr );
		if( MexeService( &reqSdb, NULL, &rspSdb, ptr ) != 0 )
			break;
	
		remain -= rspSdb.u.rsp.param.l;
		ptr = (void *)((char *)ptr + rspSdb.u.rsp.param.l);

		if( rspSdb.u.rsp.param.l != curLen )
			break;
	}

	if( rspSdb.u.rsp.errNum )
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );

	nmemb = (bytes-remain) / size;

	return nmemb;
}

/**********************************************************************/
/** do fwrite through mdis_rtagent
 * 
 */
size_t fwrite( const void *ptr, size_t size, size_t nmemb, FILE *fp )
{
	int bytes = size * nmemb;
	int remain = bytes;
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FWRITE, 0 );
	reqSdb.u.req.param1.vp = fp;

	while( remain ){
		long curLen = remain > RTA_MAX_DATALEN ? RTA_MAX_DATALEN : remain;

		reqSdb.dataLen = curLen;

		if( MexeService( &reqSdb, ptr, &rspSdb, NULL ) != 0 )
			break;
	
		remain -= rspSdb.u.rsp.param.l;
		ptr = (void *)((char *)ptr + rspSdb.u.rsp.param.l);

		if( rspSdb.u.rsp.param.l != curLen )
			break;
	}

	if( rspSdb.u.rsp.errNum )
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );

	nmemb = (bytes-remain) / size;

	return nmemb;
}

/**********************************************************************/
/** do feof through mdis_rtagent
 * 
 */
int feof( FILE *fp )
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FEOF, 0 );
	reqSdb.u.req.param1.vp = fp;

	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return 0;
	
	return rspSdb.u.rsp.param.i;
}

/**********************************************************************/
/** do ferror through mdis_rtagent
 * 
 */
int ferror( FILE *fp)
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_FERROR, 0 );
	reqSdb.u.req.param1.vp = fp;
	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return 0;
	
	return rspSdb.u.rsp.param.i;
}

/**********************************************************************/
/** do clearerr through mdis_rtagent
 * 
 */
void clearerr( FILE *fp)
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_CLEARERR, 0 );
	reqSdb.u.req.param1.vp = fp;
	MexeService( &reqSdb, NULL, &rspSdb, NULL );
}

/**********************************************************************/
/** do fseek through mdis_rtagent
 * 
 */
int fseek( FILE *fp, long offset, int whence)
{
	RTA_SDB reqSdb, rspSdb;
	int rv;

	RTA_SDB_REQ( &reqSdb, RTA_FSEEK, sizeof(int));
	reqSdb.u.req.param1.vp = fp;
	reqSdb.u.req.param2.l = offset;

	if( MexeService( &reqSdb, &whence, &rspSdb, NULL ) != 0 )
		return -1;
	
	rv = rspSdb.u.rsp.param.i;
	if( rv == -1 )
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );

	return rv;
}

/**********************************************************************/
/** do ftell through mdis_rtagent
 * 
 */
long ftell( FILE *fp)
{
	RTA_SDB reqSdb, rspSdb;
	long rv;

	RTA_SDB_REQ( &reqSdb, RTA_FTELL, 0 );
	reqSdb.u.req.param1.vp = fp;

	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return -1;
	
	rv = rspSdb.u.rsp.param.l;
	if( rv == -1 )
		UOS_ErrnoSet( rspSdb.u.rsp.errNum );

	return rv;	
}

/**********************************************************************/
/** perform getc through mdis_rtagent
 * 
 */
int getc(FILE *fp)
{
	RTA_SDB reqSdb, rspSdb;

	RTA_SDB_REQ( &reqSdb, RTA_GETC, 0 );
	reqSdb.u.req.param1.vp = fp;

	if( MexeService( &reqSdb, NULL, &rspSdb, NULL ) != 0 )
		return EOF;
	
	return rspSdb.u.rsp.param.i;
}


