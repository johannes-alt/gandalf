/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  rtai_uos.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2004/06/09 10:30:31 $
 *    $Revision: 1.3 $
 * 
 *  	 \brief  MDIS RTAI USR_OSS main file
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: rtai_uos.c,v $
 * Revision 1.3  2004/06/09 10:30:31  kp
 * cosmetics
 *
 * Revision 1.2  2003/06/06 09:36:41  kp
 * changed headers for doxygen
 *
 * Revision 1.1  2003/04/11 16:17:05  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#define UOS_GLOBAL
#include "uos_int.h"

/*! \mainpage 
 
 This is the documentation of the MEN USR_OSS module (User state
 Operating System Services) for RTAI in kernel mode.

 Refer to the \ref usrosscommonspec "USR_OSS Common Specification" for the
 plain common specification.

 For RTAI, the USR_OSS module is compiled as a static library \c
 lib-rtaik-usr_oss.a that is linked to the RTAI application kernel
 module.

 Under RTAI, an application has to call UOS_RtaiInit() before this
 library can be used. UOS_RtaiExit() must be called at the end of the
 application. This is not required when using the the MEXE
 environment; i.e. application is linked with \c rtai_mexe.c.

 In addition to the standard USR_OSS calls, \c lib-rtaik-usr_oss.a
 provides the following RTAI-specific functional groups:

 - \b Initialisation/termination: UOS_RtaiInit(), UOS_RtaiExit()
 - <b> Native signal handling </b>: UOS_RtaiSigInit(), UOS_RtaiSigExit() 
 - <b> MDIS example execution environment MEXE</b>:
   - stdio calls: fopen(), fclose(), fgets(), fread(), fwrite(), feof(),
     ferror(), clearerr(), fseek(), ftell(), getc(), vfprintf(), vprintf(),
	 fprintf(), vsnprintf(), vsprintf(), sprintf(), snprintf().
   - stdlib calls: atoi(), strtol(), strtoul(), malloc(), free(), isspace()

*/
/*! \page dummy
 \menimages
*/

/**********************************************************************/
/** initialize the RTAI USR_OSS module 
 *
 * Typically called from rtai_mexe.c
 * \return negative linux error number
 */
int UOS_RtaiInit(void)
{
	if( OSS_Init( "USR_OSS", &UOS_osh, 1 /* rtMode */ ) != 0 ){
		printk("*** RTAI:USR_OSS: cannot init OSS\n");
		return -ENODEV;
	}	
	return 0;
}

/**********************************************************************/
/** deinitialize the RTAI USR_OSS module 
 *
 * Typically called from rtai_mexe.c
 */
void UOS_RtaiExit(void) 
{
	if( UOS_osh )
		OSS_Exit( &UOS_osh );
}

