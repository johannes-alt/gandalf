/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  uos_randommap.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2003/06/06 09:36:47 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  UOS randommap routine.
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: uos_randommap.c,v $
 * Revision 1.2  2003/06/06 09:36:47  kp
 * changed headers for doxygen
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/
#include "uos_int.h"


/**********************************************************************/
/** Map created integer value into specified range
 *
 * \copydoc usr_oss_specification.c::UOS_RandomMap()
 * 
 * \rtai To use this function, the task must be started with floating
 * point support.
 *
 * \sa UOS_Random
 */
u_int32 UOS_RandomMap(u_int32 val, u_int32 ra, u_int32 re)
{
   double  f;
   u_int32 r;

   f = (double)val / 0xffffffff;      			/* make double 0..1 */
   r = (f * (double)(re-ra)) + 0.5 + ra;    	/* expand to set, add offset */

   return(r);
}
