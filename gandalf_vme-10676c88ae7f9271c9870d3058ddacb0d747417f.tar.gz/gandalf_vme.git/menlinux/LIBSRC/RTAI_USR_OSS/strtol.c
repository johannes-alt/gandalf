/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  strtol.c
 *
 *      \author  klaus.popp@men.de, from dietlibc-0.22
 *        $Date: 2003/06/06 09:36:43 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  strtol routine
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: strtol.c,v $
 * Revision 1.2  2003/06/06 09:36:43  kp
 * changed headers for doxygen
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/
#include "uos_int.h"

#define ABS_LONG_MIN 2147483648UL

/**********************************************************************/
/** C-lib routine strtol
 */
long int strtol(const char *nptr, char **endptr, int base)
{
  int neg=0;
  unsigned long int v;

  while(isspace(*nptr)) nptr++;

  if (*nptr == '-') { neg=-1; ++nptr; }
  v=strtoul(nptr,endptr,base);
  if (v>=ABS_LONG_MIN) {
    if (v==ABS_LONG_MIN && neg) {
	  UOS_ErrnoSet(0);
      return v;
    }
    UOS_ErrnoSet(ERANGE);
    return (neg?LONG_MIN:LONG_MAX);
  }
  return (neg?-v:v);
}
