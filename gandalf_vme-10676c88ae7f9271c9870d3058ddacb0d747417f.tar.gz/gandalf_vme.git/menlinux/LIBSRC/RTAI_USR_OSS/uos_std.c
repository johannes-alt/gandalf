/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  uos_std.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2006/12/15 13:03:20 $
 *    $Revision: 1.6 $
 * 
 *  	 \brief  MDIS RTAI USR_OSS standard (Common) functions
 *
 *               To be used by RTAI *kernel* mode (not lxrt) tasks
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: uos_std.c,v $
 * Revision 1.6  2006/12/15 13:03:20  ts
 * using wrappers for either RTIA or Xenomai usage
 *
 * Revision 1.5  2005/01/18 17:34:20  ts
 * Cosmetics, test debug prints removed
 *
 * Revision 1.4  2004/12/09 09:55:36  ts
 * RTAI support for MDIS
 *
 * Revision 1.3  2004/10/27 14:35:15  kp
 * RTAI 3.0 adaption
 *
 * Revision 1.2  2003/06/06 09:36:49  kp
 * changed headers for doxygen
 *
 * Revision 1.1  2003/04/11 16:17:11  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#include "uos_int.h"

#define UOS_RTAI_SIG_MBX_ENTRIES 32	/* number of signals in MBX */
#define SIGTASK_STACK_SIZE		 4096
#define SIGTASK_USES_FPU		 1
#define SIGTASK_USE_NO_FPU		 0

static int SetErrno( int error )
{
	RT_TASK *tsk = men_rt_this();
	tsk->errno = error;	
	return error;
}


/**********************************************************************/
/** Return ident string of UOS module
 * \copydoc usr_oss_specification.c::UOS_Ident()
 */
char* UOS_Ident( void )
{
	return("UOS - RTAI User Operating System Services: $Id: uos_std.c,v 1.6 2006/12/15 13:03:20 ts Exp $");
}

/**********************************************************************/
/** Let a process sleep for a specified time
 *
 * \copydoc usr_oss_specification.c::UOS_Delay()
 * \sa UOS_MikroDelay
 */
int32 UOS_Delay(u_int32 msec)
{
	return OSS_Delay( UOS_osh, msec );
}

/**********************************************************************/
/** Get global error code (task/process specific errno)
 *	
 * \copydoc usr_oss_specification.c::UOS_ErrnoGet()
 * \sa UOS_ErrnoSet, UOS_ErrStringTs, UOS_ErrString
 */
u_int32 UOS_ErrnoGet( void )
{
	RT_TASK *tsk = men_rt_this();
	return (u_int32)tsk->errno;	
}

/**********************************************************************/
/** Set global error code (task/process specific errno)
 * 
 * \copydoc usr_oss_specification.c::UOS_ErrnoSet()
 * \sa UOS_ErrnoGet
 */
u_int32 UOS_ErrnoSet( u_int32 error )
{
	return (u_int32)SetErrno( (int)error );
}

/**********************************************************************/
/** Calibrates the loop counter for UOS_MikroDelay
 * 
 * \copydoc usr_oss_specification.c::UOS_MikroDelayInit()
 * \rtai not required for RTAI
 * \sa UOS_MikroDelay
 */
int32 UOS_MikroDelayInit( void )
{
	return 0;
}

/**********************************************************************/
/** Busy sleep for specified time
 * 
 * \copydoc usr_oss_specification.c::UOS_MikroDelay()
 * \sa UOS_MikroDelayInit
 */
int32 UOS_MikroDelay(u_int32 usec)
{
	OSS_MikroDelay( UOS_osh, usec ); /* returns 0 always */
	return 0;
}

/**********************************************************************/
/** Create a new pseudo random integer value
 * 
 * \copydoc usr_oss_specification.c::UOS_Random()
 * \sa UOS_RandomMap
 */
u_int32 UOS_Random(u_int32 old)
{
	register u_int32 a = old;
			 
	a <<= 11;
	a += old;
	a <<= 2;
	old += a;
	old += 13849;
	return old;
}

/**********************************************************************/
/** Init RTAI native signal handling
 *
 * This is a native RTAI call that does not exist in other MDIS 
 * implementations.
 *
 * It installs a mailbox that receives all signals sent from any device
 * to the calling RTAI task.
 *
 * \rtai See \ref rtaisigusage "RTAI signals" to see how signals handling is
 * implemented for RTAI. 
 *
 * Passed Parameter depends wether classic RTAI or Xenomai is used:
 *
 * classic RTAI Interface:
 *
 * \param mbxP		pointer to variable where created mailbox pointer will
 *					be stored
 *
 * RTAI/fusion (Xenomai) Interface:
 *
 * \param queueP	pointer to variable where created queue will be stored
 *
 * This RTAI call needs the special char device /dev/rtheap (10,254) when 
 * 	called from user-space tasks.
 *
 * \return success (0) or error code and errno set
 * \sa UOS_SigInit, UOS_RtaiSigExit
 */
#ifdef MDIS_XENOMAI
int32 UOS_RtaiSigInit( RT_QUEUE **qP )
{
	int error;

	RT_QUEUE *queue;

	*qP = NULL;

	queue = men_rt_malloc( sizeof(RT_QUEUE) );

	if( queue == NULL )
		return SetErrno(ERR_UOS_MEM_ALLOC);

	if (error = rt_queue_create(queue, 
								"MDIS_RT_QUEUE", 
								SIGTASK_STACK_SIZE,
								UOS_RTAI_SIG_MBX_ENTRIES, 
								Q_FIFO)) {
		/* detailed error dump to help pinpoint Xenomai problems */
		switch (error) {
		case -EEXIST: 
			men_rt_printk("*** UOS_RtaiSigInit: Name already in use!\n");
			break;
		case -EINVAL:
			men_rt_printk("*** UOS_RtaiSigInit: invalid poolsize!\n");
			break;
		case -ENOMEM:
			men_rt_printk("*** UOS_RtaiSigInit: Not enough system Memory!\n");
			break;
		case -EPERM:
			men_rt_printk("*** UOS_RtaiSigInit: Invalid context!\n");
			break;
		case -ENOENT:
			men_rt_printk("*** UOS_RtaiSigInit: cant open /dev/rtheap!\n");
			break;
		case -ENOSYS:
			men_rt_printk("*** UOS_RtaiSigInit: No Userspace RT support!\n");
			break;
		}

		men_rt_free(queue);
		return SetErrno(ERR_UOS_MEM_ALLOC);
	}
				
	if( (error = OSS_RtaiSigTaskRegister( queue )) ){
		rt_queue_delete(queue);
		men_rt_free(queue);
		return SetErrno(error);
	}

	*qP = queue;
	
	return 0;
}
#else
int32 UOS_RtaiSigInit( MBX **mbxP )
{
	int error;
	MBX *mbx;

	*mbxP = NULL;
	mbx = men_rt_malloc( sizeof(MBX) );

	if( mbx == NULL )
		return SetErrno(ERR_UOS_MEM_ALLOC);

	if( rt_typed_mbx_init( mbx, sizeof(int32)*UOS_RTAI_SIG_MBX_ENTRIES, 
						   FIFO_Q ) != 0 ){
		men_rt_free(mbx);
		return SetErrno(ERR_UOS_MEM_ALLOC);
	}
				
	if( (error = OSS_RtaiSigTaskRegister( mbx )) ){
		rt_mbx_delete(mbx);
		men_rt_free(mbx);
		return SetErrno(error);
	}
	*mbxP = mbx;
	
	return 0;
}
#endif /* MDIS_XENOMAI */




/**********************************************************************/
/** Terminate RTAI native signal handling
 *
 * This is a native RTAI call that does not exist in other MDIS 
 * implementations.
 *
 * Removes the mailbox and invalidates any signal that might have been
 * installed for that mailbox.
 *
 * \return success (0) or error code and errno set
 * \sa UOS_RtaiSigInit
 */
int32 UOS_RtaiSigExit( void )
{
	int error;
	MBX *mbx;

	if( (error = OSS_RtaiSigTaskUnregister( &mbx ) ))
		return SetErrno(error);

	rt_mbx_delete(mbx);
	men_rt_free(mbx);
	
	return 0;
}

/**********************************************************************/
/** Signal handler task
 * 
 * Started for each task that calls UOS_SigInit (with a non-zero signal 
 * handler).
 *
 * Runs at a priority one higher than the requesting task.
 *
 * \param arg pointer to tasks OSS_RTAI_SIG_TASK structure
 */
static void SigHandlerTask(int arg)
{
	u_int32 sigCode;
	OSS_RTAI_SIG_TASK *entry = (OSS_RTAI_SIG_TASK *)arg;

	while( TRUE ){
		/* wait for signal to come in */
		/* 
		 * note: rt_mbx_receive documentation is wrong (24.1.9). It says
		 * that it returns the number of read bytes, but returns the
		 * number of *unread* bytes.
		 */
		if( rt_mbx_receive( entry->mbx, &sigCode, sizeof(sigCode)) >= 0 ){

			/* call user's signal handler (if installed) */
			if( entry->sigHandler )
				entry->sigHandler( sigCode );
		}
	}
}

/**********************************************************************/
/** Init signal handling
 *
 * \copydoc usr_oss_specification.c::UOS_SigInit()
 *
 * \rtai See \ref rtaisigusage "RTAI signals" to see how signals handling is
 * implemented for RTAI. 
 *
 * \sa UOS_RtaiSigInit, UOS_SigExit
 */
int32 UOS_SigInit(void (*sigHandler)(u_int32 sigCode) )
{
	MBX *mbx;
	int32 error;

	/* register task to signal system */
	if( (error = UOS_RtaiSigInit( &mbx )) != 0 )
		return error;

	if( sigHandler ){
		OSS_RTAI_SIG_TASK *entry;
		RT_TASK *sigTask = NULL;
		int prio;

		entry = OSS_TaskToSigEntry( rt_whoami() );
		if( entry == NULL ){
			UOS_SigExit();
			return SetErrno(ERR_UOS_ILL_PARAM);	/* fatal */
		}
		
		/* Create signal task */
		sigTask = men_rt_malloc( sizeof(*sigTask) );
		if( sigTask == NULL ){
			UOS_SigExit();
			return SetErrno(ERR_UOS_MEM_ALLOC);	
		}

		prio = rt_get_prio( rt_whoami() ) - 1;
		if( prio <= RT_SCHED_HIGHEST_PRIORITY )
			prio = RT_SCHED_HIGHEST_PRIORITY+1;

		/* attempt to create sig task with FPU support */
		if( rt_task_init(sigTask, 
						 SigHandlerTask, 
						 (int)entry, 
						 SIGTASK_STACK_SIZE, 
						 prio, 
						 SIGTASK_USES_FPU, 
						 0) != 0 ){
			/* failed... create it without FPU support */
			if (rt_task_init(sigTask, 
							 SigHandlerTask, 
							 (int)entry, 
							 SIGTASK_STACK_SIZE, 
							 prio, 
							 SIGTASK_USE_NO_FPU, 
							 0) !=0 ){

				men_rt_free( sigTask );

				UOS_SigExit();
				return SetErrno(ERR_UOS_MEM_ALLOC);	
			}
		}
			
		entry->sigTask = sigTask;
		entry->sigHandler = sigHandler;
		rt_task_resume( sigTask ); /* start signal task */
	}
	return 0;
}

/**********************************************************************/
/** Terminate signal handling
 *
 * \copydoc usr_oss_specification.c::UOS_SigExit()
 *
 * \rtai See \ref rtaisigusage "RTAI signals" to see how signals handling is
 * implemented for RTAI. 
 *
 * \sa UOS_RtaiSigExit, UOS_SigInit
 */
int32 UOS_SigExit(void)
{
	OSS_RTAI_SIG_TASK *entry;
	RT_TASK *sigTask;

	entry = OSS_TaskToSigEntry( rt_whoami() );
	if( entry == NULL )
		return SetErrno(ERR_UOS_NOT_INIZED);   

	/* kill signal task */
	if( (sigTask = entry->sigTask) != NULL ){
		rt_task_delete( sigTask );
		entry->sigTask = NULL;
		entry->sigHandler = NULL;
	}
	/* cleanup mailbox */
	return UOS_RtaiSigExit();
}

/**********************************************************************/
/** Install a signal to be received
 *
 * \copydoc usr_oss_specification.c::UOS_SigInstall()
 *
 * \rtai No-op for RTAI
 * \sa UOS_SigRemove
 */
int32 UOS_SigInstall(u_int32 sigCode)
{
	return 0;
}

/**********************************************************************/
/** Remove signal to be received
 *
 * \copydoc usr_oss_specification.c::UOS_SigRemove()
 *
 * \rtai No-op for RTAI
 * \sa UOS_SigInstall
 */
int32 UOS_SigRemove(u_int32 sigCode)
{
	return 0;
}

/**********************************************************************/
/** Mask all signals
 *
 * \copydoc usr_oss_specification.c::UOS_SigMask()
 *
 * \rtai Stops the signal handler task of the calling task.
 * \sa UOS_SigUnMask
 */
int32 UOS_SigMask(void)
{
	OSS_RTAI_SIG_TASK *entry;

	entry = OSS_TaskToSigEntry( rt_whoami() );
	if( entry == NULL )
		return SetErrno(ERR_UOS_NOT_INIZED);   

	/* stop signal task (if not already done) */
	if( entry->sigTask ){
		if( ! (rt_get_task_state( entry->sigTask ) & RT_SCHED_SUSPENDED )){
			rt_task_suspend( entry->sigTask );
			/*
			 * !!! too much knowledge of mbx internals!
			 * in order to allow UOS_SigWait to read from the mbx,
			 * the mbx's receive semaphore must be released.
			 */
			rt_sem_signal(&entry->mbx->rcvsem);
		}
	}
	return 0;
}

/**********************************************************************/
/** Unmask all signals
 *
 * \copydoc usr_oss_specification.c::UOS_SigUnMask()
 *
 * \rtai Resumes the signal handler task of the calling task.
 * \sa UOS_SigMask
 */
int32 UOS_SigUnMask(void)
{
	OSS_RTAI_SIG_TASK *entry;

	entry = OSS_TaskToSigEntry( rt_whoami() );
	if( entry == NULL )
		return SetErrno(ERR_UOS_NOT_INIZED);   

	/* stop signal task */
	if( entry->sigTask ){
		if( (rt_get_task_state( entry->sigTask ) & RT_SCHED_SUSPENDED )){
			rt_sem_wait(&entry->mbx->rcvsem);
			rt_task_resume( entry->sigTask );
		}
	}
	return 0;
}

/**********************************************************************/
/** Wait until signal received
 *
 * \copydoc usr_oss_specification.c::UOS_SigWait()
 * \sa UOS_SigInit, UOS_SigInstall
 */
int32 UOS_SigWait(u_int32 msec, u_int32 *sigCodeP)
{
	OSS_RTAI_SIG_TASK *entry;
	int n=0;
	int32 error=0;
	u_int32 sigCode;

	entry = OSS_TaskToSigEntry( rt_whoami() );
	if( entry == NULL )
		return SetErrno(ERR_UOS_NOT_INIZED);   

	/* make sure signal task is stopped (should have been done by caller)*/
	UOS_SigMask();

	if( msec ){
		RTIME count;
		if( (error = OSS_RtaiMsToCount( msec, &count )))
			goto EXIT;

		n = rt_mbx_receive_timed( entry->mbx, &sigCode, sizeof(sigCode),
								  count );		
	}
	else {
		/* endless */
		n = rt_mbx_receive( entry->mbx, &sigCode, sizeof(sigCode));
	}
	if( n != 0 )				/* n is the number of *unread* bytes */
		error = ERR_UOS_TIMEOUT;
	else {
		*sigCodeP = sigCode;
		/* call user's signal handler (if installed) */
		if( entry->sigHandler )
			entry->sigHandler( sigCode );
	}
 EXIT:
	if( error )
		SetErrno( error );
	return error;
}

/**********************************************************************/
/** Read the current timer value in mseconds
 *
 * \copydoc usr_oss_specification.c::UOS_MsecTimerGet()
 * \sa UOS_MsecTimerResolution
 */
u_int32 UOS_MsecTimerGet(void)
{
	unsigned long rem;

	// ??? wrapover
	return ulldiv( rt_get_time_ns(), 1E6, &rem );
}

/**********************************************************************/
/** Get timer resolution of UOS_MsecTimerGet()
 *
 * \copydoc usr_oss_specification.c::UOS_MsecTimerResolution()
 * \rtai this function lies... in periodic mode, resolution might not be 1ms
 * \sa UOS_MsecTimerGet
 */
u_int32 UOS_MsecTimerResolution(void)
{
	return 1;
}

