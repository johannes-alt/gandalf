/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  strtoul.c
 *
 *      \author  klaus.popp@men.de, from dietlibc-0.22
 *        $Date: 2003/06/06 09:36:45 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  strtoul routine
 *
 * 	   \project  MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: strtoul.c,v $
 * Revision 1.2  2003/06/06 09:36:45  kp
 * changed headers for doxygen
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/
#include "uos_int.h"

/**********************************************************************/
/** C-lib routine strtoul
 */
unsigned long int strtoul(const char *nptr, char **endptr, int base)
{
  int neg = 0;
  unsigned long int v=0;

  while(isspace(*nptr)) ++nptr;
  if (*nptr == '-') { neg=1; nptr++; }
  if (*nptr == '+') ++nptr;
  if (base==16 && nptr[0]=='0') goto skip0x;
  if (!base) {
    if (*nptr=='0') {
      base=8;
skip0x:
      if (nptr[1]=='x'||nptr[1]=='X') {
	nptr+=2;
	base=16;
      }
    } else
      base=10;
  }
  while(*nptr) {
    register unsigned char c=*nptr;
    c=(c>='a'?c-'a'+10:c>='A'?c-'A'+10:c<='9'?c-'0':0xff);
    if (c>=base) break;
    {
      register unsigned long int w=v*base;
      if (w<v) {
		  UOS_ErrnoSet(ERANGE);
		  return ULONG_MAX;
      }
      v=w+c;
    }
    ++nptr;
  }
  if (endptr) *endptr=(char *)nptr;
  UOS_ErrnoSet(0);	/* in case v==ULONG_MAX, ugh! */
  return (neg?-v:v);
}
