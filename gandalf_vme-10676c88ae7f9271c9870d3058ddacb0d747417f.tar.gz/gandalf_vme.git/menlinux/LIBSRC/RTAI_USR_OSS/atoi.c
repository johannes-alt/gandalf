/*********************  P r o g r a m  -  M o d u l e ***********************/
/*!  
 *        \file  atoi.c
 *
 *      \author  klaus.popp@men.de
 *        $Date: 2003/06/06 09:36:33 $
 *    $Revision: 1.2 $
 * 
 *  	 \brief  atoi routine
 *
 * 	    \project MDIS4Linux/RTAI
 *
 *    \switches  none
 */
/*-------------------------------[ History ]---------------------------------
 *
 * $Log: atoi.c,v $
 * Revision 1.2  2003/06/06 09:36:33  kp
 * cosmetics
 *
 * Revision 1.1  2003/04/11 16:16:59  kp
 * Initial Revision
 *
 *---------------------------------------------------------------------------
 * (c) Copyright 2003 by MEN mikro elektronik GmbH, Nuernberg, Germany 
 ****************************************************************************/

#include "uos_int.h"

/**********************************************************************/
/** C-lib routine atoi 
 */
int atoi(const char *s) 
{
	int i, sign = 0;
	int n;

	for(i = 0; (s[i] == ' ') || (s[i] == '\n') || (s[i] == '\t'); ++i)
		;
	switch(s[i])
    {
    case '-':
		sign++;
		/* and fall through */
    case '+':
		++i;
		break;
    }
	for(n = 0; s[i]>='0' && s[i]<='9'; ++i)
		n = 10 * n + s[i] - '0';
	return (sign == 0 ? n : -n);
}
