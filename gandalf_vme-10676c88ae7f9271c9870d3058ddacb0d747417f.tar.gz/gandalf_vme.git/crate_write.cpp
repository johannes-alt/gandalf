//============================================================================
// Name        : gandalf_status.cpp
// Author      : FH
//===========================================================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

#include <MEN/vme4l.h>
#include <MEN/vme4l_api.h>

#define MODULE_VME_ADDR	0xe0000000

static inline unsigned int swapbe32(unsigned int val)
{
	return (((val & 0xff000000) >> 24) | ((val & 0xff0000) >> 8) |
		((val & 0xff00) << 8) | ((val & 0xff) << 24));
}

struct board {
	unsigned char hex;
	unsigned char init;
	unsigned short reset;
};



int main(int argc, char **argv) {

        char *endptr;
        unsigned int radd;
	unsigned int val=0;
	struct board slot[32];
	unsigned char lastSlot;
	bool error=true;
 
        std::string msg;
 
	int h, i, ret;
	int spaceFd;

	size_t size=4;

	memset(slot, 0, 32*sizeof(struct board));
	spaceFd = VME4L_Open( VME4L_SPC_A32_D32 );

	if (argc == 1) {
                printf("Usage: arg1 is written to all loaded modules");
                printf("       arg1=Gandalf adr offset e0ID[arg1]\n");
                printf("       arg2=value to write\n");
                printf("       if arg2 missing: read access\n");
                exit(1);
        }

	radd = (strtoul(argv[1], &endptr, 16));

	if( spaceFd < 0 ) {
		printf("!ERROR:1001:cannot open VME space \n");
		exit(1);
	}

//	ret = VME4L_SysReset(spaceFd);
//	if (ret<0)
//		goto error;

	i = 0;
	lastSlot = 0;
	for(h=0; h<255; h++) {
		ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + 0xFC) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
		if(  ret < 0 || (unsigned int)ret != size ) // handle bus error first
		{
			if (ret < 0)
				continue;
			else if ((unsigned int)ret!= size)
				goto error;
		}

		// this Gandalf is alive ! get its status

		val = swapbe32(val);
		slot[i].hex = (val>>20) & 0xFF;
		slot[i].init = (val>>28) & 0xF;

		// if Gandalf is initiated, get more info
		if (slot[i].init==0xf) {

		        /* Read access */
	 	       msg="!ERROR:1001:VME bus error";
 		       if (argc == 2) {
		                ret = VME4L_Read( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + radd) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
		                if(  ret < 0 || (unsigned int)ret != size ) goto error;
		                printf("%02Xh %08x\n",slot[i].hex, swapbe32(val));
	        	}

		        /* Write data on bus */
		        msg="!ERROR:1001:VME bus error";
		        if (argc == 3) {
		                val = strtoul(argv[2], &endptr, 16);
		                val = swapbe32(val);
		                ret = VME4L_Write( spaceFd , (vmeaddr_t)(MODULE_VME_ADDR + (h<<16) + radd) , 4 , size , (void *)&val , VME4L_RW_NOFLAGS );
		                if(  ret < 0 || (unsigned int)ret != size ) goto error;
				printf("%02Xh %08x\n",slot[i].hex, swapbe32(val));
	        	}

		}

	}
	// everything went well
	error=false;

error:
	if (error)
	{
		printf("!ERROR: (%s)\n", strerror(errno));
		VME4L_Close( spaceFd ); // try to close the handle
		return EXIT_FAILURE;
	}

	ret = VME4L_Close( spaceFd );
	if (ret<0)
		goto error;

	return EXIT_SUCCESS;
}
