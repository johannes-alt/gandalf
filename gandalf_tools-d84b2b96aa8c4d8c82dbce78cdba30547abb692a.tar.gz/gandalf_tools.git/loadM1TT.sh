#!/bin/bash

#BINF="$GANDALF_BINFILE_FOLDER/production/g_dsp_m1_tt_001.bin"
BINF="$GANDALF_BINFILE_FOLDER/buechele/g_dsp_m1_tt.bin"

if [ $# -eq 3 ]
then
  LOAD="$(gansm3 ${BINF} $GANDALF_BINFILE_FOLDER/gandalf_mem_2009 ${1})"
  WINDOW=$(echo "obase=16; (${2}/2.572)" | bc)
  while [ ${#WINDOW} -lt 4 ]
  do
      WINDOW="0${WINDOW}"
  done
  LATENCY=$(echo "obase=16; (${3}/2.572)" | bc)
        while [ ${#LATENCY} -lt 4 ]
        do
                LATENCY="0${LATENCY}"
        done
  LATWIN="$(vme_write e0${1}2BA0 ${WINDOW}${LATENCY})"
  RELOAD="$(vme_write e0${1}7034 2)"
  #HONDAIN="$(vme_write e0${1}211c 1)"
  SWEEP="$(vme_write e0${1}70f0 2)"
  SOURCEID=$(echo '801' | bc)
  vme_write "e0"${1}"2804" $(printf "%08x\n" $SOURCEID) > /dev/null

  #INVINPUT="$(vme_write e0${1}7110 1)"

  echo "------------------------------------------------"
  echo "BINFILE: ${BINF}"
else
        echo ""
        echo "---------------------USAGE:---------------------"
        echo "arg1 = GANDALF HEX ID [8 bit]"
        echo "arg2 = trigger window in ns"
        echo "arg3 = trigger latency in ns"
  echo ""
  exit 1
fi

echo "gansm3 output: ${LOAD}"
echo "source ID:" $SOURCEID
echo "window & latency: ${LATWIN}"
echo "update conf_Mem: ${RELOAD}"
#echo "Honda Cable input: ${HONDAIN}"
echo "SI sweep: ${SWEEP}"
#echo "Inverted TDC inputs: ${INVINPUT}"
echo ""
