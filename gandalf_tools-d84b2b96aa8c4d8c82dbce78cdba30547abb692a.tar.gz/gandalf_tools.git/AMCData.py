#!/usr/bin/python
import os
import sys
import time
import struct
import ConfigParser
import array

debug = False
file_buffsize = 10
 #    \     \  |   __|  _ \         |
 #   _ \   |\/ |  (     |  |  _` |   _|   _` |
 # _/  _\ _|  _| \___| ___/ \__,_| \__| \__,_|
"""

"""

def bswap ( input ):
    output = array.array('I',input[:])
    output.byteswap()
    return output.tostring()

class AMCData:

    def __init__(self, conf_file_name, outfile_name="", skip_frames=False):
        self.old_evt_no = 0
        self.rawdata = ""
        self.fp=0
        self.outfile_dirname=os.path.dirname(outfile_name)
        self.outfile_basename=os.path.basename(outfile_name)
        self.run_no=1000
        self.spill_evt_list=[]
        self.skip_frames=skip_frames
        if outfile_name!="":
            self.fp=open("%s/%s_%.4i.raw"%(self.outfile_dirname, self.outfile_basename, self.run_no), "wb+", file_buffsize)
        self.conf = ConfigParser.RawConfigParser()
        self.conf.readfp(open(conf_file_name, "r"))
        self.dataformats = dict()
        self.datasections = dict()
        self.datapos = long(0)
        for sec in self.conf.sections():
            self.dataformats[sec] = []
            self.datasections[sec] = []
            for i in range(0, len(self.conf.options(sec))):
                conf = self.getConfigList(self.conf.get(sec,'%s'%i))
                self.dataformats[sec].append(conf)
            self.datasections[sec] = DataSection(sec, self.dataformats[sec])

    def DateHeader(self, length, run, spill, event):
        now = time.time()
        a = bytearray()
        gdcHeaderSize=68 # 4*17
        ldcHeaderSize=68 # 4*17
        restOfHeaderSize=28 # 4*6
        a.extend(struct.pack("<I",length+gdcHeaderSize+ldcHeaderSize+restOfHeaderSize))
        # GDC Header
        a.extend(struct.pack("<I",0xDA1E5AFE))
        a.extend(struct.pack("<I",gdcHeaderSize))
        a.extend(struct.pack("<I",0x00030006))    # event version
        a.extend(struct.pack("<I",7))            # event type: (7) physical
        a.extend(struct.pack("<I",run))            # run nb
        a.extend(struct.pack("<I",spill * 0x100000 + event))    # nb in run
        a.extend(struct.pack("<I",spill * 0x100000 + event))    # nb in run
        a.extend(struct.pack("<I",0))            # trigger pattern
        a.extend(struct.pack("<I",0))            # trigger pattern
        a.extend(struct.pack("<I",3))            # det pattern
        a.extend(struct.pack("<I",0))            # attr
        a.extend(struct.pack("<I",0))            # attr
        a.extend(struct.pack("<I",0x10))        # attr
        a.extend(struct.pack("<I",0xffffffff))        # LDC
        a.extend(struct.pack("<I",0))            # GDC
        a.extend(struct.pack("<I",int(now)))    # time
        a.extend(struct.pack("<I",length+ldcHeaderSize+restOfHeaderSize))
        # LDC Header
        a.extend(struct.pack("<I",0xDA1E5AFE))
        a.extend(struct.pack("<I",68))            # header size
        a.extend(struct.pack("<I",0x00030006))    # event version
        a.extend(struct.pack("<I",7))            # event type: (7) physical
        a.extend(struct.pack("<I",run))            # run nb
        a.extend(struct.pack("<I",spill * 0x100000 + event))    # nb in run
        a.extend(struct.pack("<I",spill * 0x100000 + event))    # nb in run
        a.extend(struct.pack("<I",0))            # trigger pattern
        a.extend(struct.pack("<I",0))            # trigger pattern
        a.extend(struct.pack("<I",3))            # det pattern
        a.extend(struct.pack("<I",0))            # attr
        a.extend(struct.pack("<I",0))            # attr
        a.extend(struct.pack("<I",0))            # attr
        a.extend(struct.pack("<I",0))            # LDC
        a.extend(struct.pack("<I",0))            # GDC
        a.extend(struct.pack("<I",int(now)))    # time
        a.extend(struct.pack("<I",length+restOfHeaderSize))
        # Unknown
        a.extend(struct.pack("<I",0x40))        #
        a.extend(struct.pack("<I",0x40))        #
        a.extend(struct.pack("<I",0))            #
        a.extend(struct.pack("<I",0))            #
        a.extend(struct.pack("<I",0))            #
        a.extend(struct.pack("<I",0))            #
        return a

    def dumpData(self, eventNo = -1):
        if debug: print "DumpData called on event No %i"%eventNo


        dataformats = self.dataformats
        datasections = self.datasections

        rawdata = self.rawdata
        date_dump_data = ""
        date_dump_size=0
        datalen = len(rawdata)
        datapos = long(0)
        dataname = "SMUX_HEADER"
        if dataname in dataformats:
            datapos += 4*len(dataformats[dataname])
            datasections[dataname].setRawData(self.rawdata[0:datapos])
            print datasections[dataname].get("evt_size")
            date_dump_size=datasections[dataname].get("evt_size") - 2
            print datasections[dataname].dumpData()
        while (datapos < datalen):
            dataname = "SLINK_HEADER"
            if debug: print "Parsing %s"%dataname
            parselen = 4*len(dataformats[dataname])
            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
            datapos += parselen
            evt_no = datasections[dataname].get("evt_no")
            if self.old_evt_no != 0 and evt_no > 1 and self.old_evt_no + 1 != evt_no:
                print "Warning: EventNoMissmatch, expected: %i, got %i" % (self.old_evt_no + 1, evt_no)
            self.old_evt_no = evt_no
            if (eventNo<0): print datasections[dataname].dumpData()
            else:
                if (eventNo==evt_no): print datasections[dataname].dumpData()
            evt_size = datasections[dataname].get("evt_size") - 3
            dataformat = datasections[dataname].get("format")

            # first event of run has format 152 or 168 (if frame data)
            if dataformat == 25 or dataformat == 152 or dataformat == 168:
                date_dump_data += datasections[dataname].getRawdata()
                dataname = "NORMAL_DATA"
                if debug: print "Parsing %s"%dataname
                seclen = 4*len(dataformats[dataname])
                for i in range(datapos, datapos + 4*evt_size, seclen):
                    parsedata = self.rawdata[i:i+seclen]
                    datasections[dataname].setRawData(parsedata)
                    date_dump_data += parsedata
                    if (eventNo<0): print datasections[dataname].dumpData()
                    else:
                        if (eventNo==evt_no): print datasections[dataname].dumpData()
                datapos += 4*evt_size

            elif dataformat == 48:
                #TODO TDC DATA IN SMUX.CFG
                datapos += 4*evt_size

            elif dataformat == 9:
                dataname = "TIGER_DATA"
                date_dump_size -= evt_size+3;
                if debug: print "Parsing %s"%dataname
                seclen = 4*len(dataformats[dataname])
                for i in range(datapos, datapos + 4*evt_size, seclen):
                    parsedata = self.rawdata[i:i+seclen]
                    datasections[dataname].setRawData(parsedata)
                    if (eventNo<0): print datasections[dataname].dumpData()
                    else:
                        if (eventNo==evt_no): print datasections[dataname].dumpData()
                datapos += 4*evt_size

            elif dataformat == 128:
                dataname = "TRIGGER_DATA"
                date_dump_size -= evt_size+3;
                if debug: print "Parsing %s"%dataname
                seclen = 4*len(dataformats[dataname])
                for i in range(datapos, datapos + 4*evt_size, seclen):
                    parsedata = self.rawdata[i:i+seclen]
                    datasections[dataname].setRawData(parsedata)
                    if (eventNo<0): print datasections[dataname].dumpData()
                    else:
                        if (eventNo==evt_no): print datasections[dataname].dumpData()
                datapos += 4*evt_size

            elif dataformat == 1:
                startpos = datapos
                parselen = 4
                while (datapos < startpos + 4*(evt_size)):
                    if debug: print "Parsing %s"%dataname
                    try: isHeader = int(rawdata[datapos].encode("hex"), 16) >> 7
                    except IndexError as e:
                        print "Index Error while parsing M1 Data. Datapos: %i, datalength: %i, size: %i"%(datapos, len(rawdata), 4*(evt_size))
                        return
                    if (isHeader == 1):
                        dataname = "M1_DATA"
                    else:
                        dataname = "M1_HEAD"
                    datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                    print datasections[dataname].dumpData().strip()
                    datapos += parselen


            elif dataformat == 28 or dataformat == 129:
                date_dump_data += datasections[dataname].getRawdata()
                startpos = datapos
                while (datapos < startpos + 4*(evt_size)):
                    dataname = "DEBUG_HEADER"
                    if debug: print "Parsing %s"%dataname
                    parselen = 4*len(dataformats[dataname])
                    datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                    date_dump_data += datasections[dataname].getRawdata()
                    if (eventNo<0): print datasections[dataname].dumpData().rstrip('\n')
                    else:
                        if (eventNo==evt_no): print datasections[dataname].dumpData().rstrip('\n')
                    datapos += parselen

                    seclen = int(datasections[dataname].get("framesize"))

                    dataname = "DEBUG_FRAME"
                    if debug: print "Parsing %s"%dataname
                    if not self.skip_frames:
                        ADCvals = []
                        for i in range(datapos, datapos + 4*(seclen), 4):
                            parsedata = self.rawdata[i:i+4]
                            datasections[dataname].setRawData(parsedata)
                            date_dump_data += datasections[dataname].getRawdata()
                            ADCvals.append(datasections[dataname].get("ADC0"))
                            ADCvals.append(datasections[dataname].get("ADC1"))
                        if (eventNo<0): print "\t \t[%s]"%dataname, ADCvals
                        else:
                            if (eventNo==evt_no): print "\t \t[%s]"%dataname, ADCvals
                    datapos += 4*(seclen)

                    while (datapos < startpos + 4*(evt_size)):
                        if ((ord(rawdata[datapos]) >> 7) == 0):
                            dataname = "DEBUG_FOOTER"
                            if debug: print "Parsing %s"%dataname
                            parselen = 4*len(dataformats[dataname])
                            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                            date_dump_data += datasections[dataname].getRawdata()
                            if (eventNo<0): print datasections[dataname].dumpData()
                            else:
                                if (eventNo==evt_no): print datasections[dataname].dumpData()
                            datapos += parselen
                            break
                        else:
                            dataname = "DEBUG_EVENT"
                            if debug: print "Parsing %s"%dataname
                            parselen = 4*len(dataformats[dataname])
                            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                            date_dump_data += datasections[dataname].getRawdata()
                            if (eventNo<0): print datasections[dataname].dumpData().rstrip('\n')
                            else:
                                if (eventNo==evt_no): print datasections[dataname].dumpData().rstrip('\n')
                            datapos += parselen

                datapos = startpos + 4* evt_size
            else:
                print "Error: unknown Format"
                return
        if self.fp != 0:
            evt_no=datasections["SLINK_HEADER"].get("evt_no")
            spill_no=datasections["SLINK_HEADER"].get("spill_no")
            if (spill_no, evt_no) in self.spill_evt_list:
                self.run_no+=1
                del self.spill_evt_list[:]
                self.spill_evt_list.append((spill_no, evt_no))
                self.fp.close()
                self.fp=open("%s/%s_%.4i.raw"%(self.outfile_dirname, self.outfile_basename, self.run_no), "wb+", file_buffsize)
            else:
                self.spill_evt_list.append((spill_no, evt_no))
            # The date header has a gdc header a 68 and a ldc header a 68. plus 7*4=28 for unknown bullshit
            event_buffer = self.DateHeader(4*date_dump_size, self.run_no, spill_no, evt_no)
            event_buffer.extend(bswap(date_dump_data))
            self.fp.write(event_buffer)
            self.fp.flush()

    def getM1Data(self):
        parselen = 4
        retval = dict()
        datapos = long(0)
        evt_size = datasections[dataname].get("evt_size") - 3
        if self.datasections["SLINK_HEADER"].get("format") != 1:
            return retval
        if "SMUX_HEADER" in dataformats:
            datapos = 5 * 4
        else:
            datapos = 3 * 4
        startpos = datapos
        while (datapos < startpos + 4*(evt_size)):
            if debug: print "Parsing %s"%dataname

            isHeader = int(rawdata[datapos].encode("hex"), 16) >> 7
            if (isHeader == 1):
                dataname = "M1_DATA"
            else:
                dataname = "M1_HEAD"
            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
            print datasections[dataname].dumpData().strip()
            datapos += parselen
        return retval

    def getM1Data(self):
        dataformats = self.dataformats
        datasections = self.datasections
        rawdata = self.rawdata
        datalen = len(rawdata)
        datapos = long(0)
        retval = dict()
        dataname = "SMUX_HEADER"
        if dataname in dataformats:
            datapos += 4*len(dataformats[dataname])
            datasections[dataname].setRawData(self.rawdata[0:datapos])
        while (datapos < datalen):
            dataname = "SLINK_HEADER"
            parselen = 4*len(dataformats[dataname])
            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
            datapos += parselen
            src_id = datasections[dataname].get("source_id")
            format = datasections[dataname].get("format")
            evt_size = datasections[dataname].get("evt_size") - 3

            if format == 1:
                parselen = 4
                startpos = datapos
                headerKey = ""
                while (datapos < startpos + 4*(evt_size)):
                    isData = int(rawdata[datapos].encode("hex"), 16) >> 7
                    if (isData == 1):
                        dataname = "M1_DATA"
                        datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                        portStr = "%.2i"%datasections[dataname].get("port")
                        if portStr not in retval:
                            retval[portStr] = dict()
                        chipStr = "%.2i"%datasections[dataname].get("chip")
                        if chipStr not in retval[portStr]:
                            retval[portStr][chipStr] = dict()
                        chanStr = "%.2i"%datasections[dataname].get("chan")
                        if chanStr not in retval[portStr][chipStr]:
                            retval[portStr][chipStr][chanStr] = []
                        retval[portStr][chipStr][chanStr].append(datasections[dataname].get("data"))
                    else:
                        dataname = "M1_HEAD"
                        datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                    datapos += parselen
            else:
                datapos += 4*evt_size # skip other data
        return retval

    def setRawData(self, data):
        self.rawdata = data
        parselen = 4*len(self.dataformats["SLINK_HEADER"])
        self.datasections["SLINK_HEADER"].setRawData(data[0:parselen])

    def getADCVals(self):
        dataformats = self.dataformats
        datasections = self.datasections
        rawdata = self.rawdata
        datalen = len(rawdata)
        datapos = long(0)
        retval = []
        dataname = "SMUX_HEADER"
        if dataname in dataformats:
            datapos += 4*len(dataformats[dataname])
            datasections[dataname].setRawData(self.rawdata[0:datapos])
        while (datapos < datalen):
            dataname = "SLINK_HEADER"
            parselen = 4*len(dataformats[dataname])
            datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
            datapos += parselen
            src_id = datasections[dataname].get("source_id")
            format = datasections[dataname].get("format")
            evt_size = datasections[dataname].get("evt_size") - 3

            if format == 24:
                datapos += 4*evt_size # skip normal data

            elif format == 28:
                startpos = datapos
                while (datapos < startpos + 4*(evt_size)):
                    dataname = "DEBUG_HEADER"
                    parselen = 4*len(dataformats[dataname])
                    datasections[dataname].setRawData(rawdata[datapos:datapos + parselen])
                    chan = datasections[dataname].get("chan")
                    datapos += parselen

                    seclen = int(datasections[dataname].get("framesize"))

                    dataname = "DEBUG_FRAME"
                    ADCvals = []
                    ADCsec=[]
                    ADCvals.append([src_id, chan])
                    for i in range(datapos, datapos + 4*(seclen), 4):
                        parsedata = self.rawdata[i:i+4]
                        datasections[dataname].setRawData(parsedata)
                        ADCsec.append(datasections[dataname].get("ADC0"))
                        ADCsec.append(datasections[dataname].get("ADC1"))
                    ADCvals.append(ADCsec)
                    retval.append(ADCvals)
                    datapos += 4*(seclen)

                    while (datapos < startpos + 4*(evt_size)):
                        if ((ord(rawdata[datapos]) >> 7) == 0):
                            dataname = "DEBUG_FOOTER"
                            parselen = 4*len(dataformats[dataname])
                            datapos += parselen
                            break
                        else:
                            dataname = "DEBUG_EVENT"
                            parselen = 4*len(dataformats[dataname])
                            datapos += parselen

                datapos = startpos + 4* evt_size
        return retval

    def getConfigList(self, s):
        retval=[]
        for val in s.split(']')[:-2]:
            retval.append(val.replace('"',
                '').strip().strip(',').strip().strip('[').split(','))
        return retval


 #  _ \         |            __|             |   _)
 #  |  |  _` |   _|   _` | \__ \   -_)   _|   _|  |   _ \    \
 # ___/ \__,_| \__| \__,_| ____/ \___| \__| \__| _| \___/ _| _|
"""
"""
class DataSection:

    def __init__(self, name, dataformat):
        self.dataformat = dataformat
        self.data = dict()
        nline=-1
        for line in self.dataformat:
            nline += 1
            for val in line:
                if (len(val)<=1):continue
                self.data[val[0]] = val[1:3]
                self.data[val[0]].append(nline)
        self.rawdata = ""
        self.datawords = len(dataformat)
        self.name = name

    def setRawData(self, data):
        if (len(data) == 0): return
        self.rawdata = data
        if (len(data)/4 != self.datawords):
            print "%s Warning: length mismatch. len=\t%i. Expected=\t%i"%(self.name, len(data), self.datawords*4)
            print "Rawdata was: %s"%self.rawdata.encode("hex")

    """ Dump Data to stdout.
    """
    def dumpData(self, n = -1):
        rawdata = self.rawdata
        datalen = len(rawdata)
        nline = 0
        if (datalen == 0): return "%s Error: No Data"%self.name
        retval = ""
        for line in self.dataformat:
            newline = rawdata[nline*4 : (nline+1)*4].encode("hex")
            #~ retval += "%s:\t[%s]\t"%(newline,  self.name)

            nval = 0
            for val in line:
                if(len(val) <= 2):continue
                if nval%9 == 0: retval += "\n%s:\t[%s]\t"%(newline,  self.name)
                bitmask = 0
                for i in range(0, int(val[1])): bitmask |= 1<<i
                retval += "%s:\t%i\t"%(val[0], int(newline, 16) >> int(val[2]) & bitmask)
                nval += 1
            nline += 1
        return retval

    def get(self, key):
        if (len(self.rawdata) == 0): return "Error: No Data"
        val = self.data[key]
        bitmask = 0
        for i in range(0, int(val[0])): bitmask |= 1<<i
        return int(self.rawdata[val[2]*4 : (val[2]+1)*4].encode("hex"), 16) >> int(val[1]) & bitmask

    def getFormat(self):
        return self.dataformat

    def getRawdata(self):
        return self.rawdata
