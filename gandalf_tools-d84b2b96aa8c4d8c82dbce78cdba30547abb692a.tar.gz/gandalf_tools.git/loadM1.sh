#!/bin/bash

#BINF="/sc/gandalf/binfiles/paul/m1_usb_ocx_08.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/g_dsp_m1_VXS.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_tt_006.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_tt_004.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_016.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_017.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_019.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_020.bin"
BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_022.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_m1_019_8chan.bin"
#BINF="/online/util/gandalf/binfiles/g_dsp_m1_tt.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/g_dsp_m1_tt.bin"
#BINF="$GANDALF_BINFILE_FOLDER/buechele/gandalf_dsp_tdc_scaler_012.bin"

if [ $# -eq 3 ]
then
  LOAD="$(gansm3 ${BINF} ${GANDALF_BINFILE_FOLDER}/gandalf_mem_2009 ${1})"
  WINDOW=$(echo "obase=16; (${2}/2.572)" | bc)
  while [ ${#WINDOW} -lt 4 ]
  do
      WINDOW="0${WINDOW}"
  done
  LATENCY=$(echo "obase=16; (${3}/2.572)" | bc)
        while [ ${#LATENCY} -lt 4 ]
        do
                LATENCY="0${LATENCY}"
        done

  LATWIN="$(vme_write e0${1}2BA0 ${WINDOW}${LATENCY})"
#  VXSSLINK="$(vme_write e0${1}70a4 1)"
  #SWEEP="$(vme_write e0${1}70f0 2)"
  SOURCEID=$(echo '800 + '${1} | bc)
  vme_write "e0"${1}"2804" $(printf "%08x\n" $SOURCEID) > /dev/null
  RELOAD="$(vme_write e0${1}7034 2)"

  #INVINPUT="$(vme_write e0${1}7118 1)"

  echo "------------------------------------------------"
  echo "BINFILE: ${BINF}"
else
        echo ""
        echo "---------------------USAGE:---------------------"
        echo "arg1 = GANDALF HEX ID [8 bit]"
        echo "arg2 = trigger window in ns"
        echo "arg3 = trigger latency in ns"
  echo ""
  exit 1
fi

echo "gansm3 output: ${LOAD}"
echo "source ID:" $SOURCEID
echo "window & latency: ${LATWIN}"
echo "update conf_Mem: ${RELOAD}"
echo "TIGER VXS readout: ${VXSSLINK}"
echo "SI sweep: ${SWEEP}"
echo "Inverted TDC inputs: ${INVINPUT}"
echo ""
