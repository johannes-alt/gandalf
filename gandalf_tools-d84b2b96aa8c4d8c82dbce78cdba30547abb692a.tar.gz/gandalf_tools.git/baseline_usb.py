#!/usr/bin/env python2
import sys
import os
import math
import threading
from subprocess import Popen, PIPE
from optparse import OptionParser
from time import strftime
ALL_HEX_IDS=[20,21,22,23,24,25,30,31,32,33,34,35]
#~ ALL_HEX_IDS=[22,23]
path = os.path.abspath(os.path.dirname(sys.argv[0]))
logfile_path = "/tmp/dac_log"
binfile_folder= os.path.join(os.path.dirname(__file__), "binfiles")
debug = True
hello = """
#   __| __|__ __|  _ )   \    __| __| |   _ _|  \ | __|  __|
# \__ \ _|    |    _ \  _ \ \__ \ _|  |     |  .  | _| \__ \\
# ____/___|  _|   ___/_/  _\____/___|____|___|_|\_|___|____/
# of Gandalf's Analog Mezzanine Cards
#                   -->  USB version.
"""
gstatus_header = """
#  SN  HEX  GA  INIT SRCID  TCS_SL  SI_G  SI_A  SI_B  RESET  MCSup  MCSd   Gtemp  VCCAUX VCCINT SYSMON
# ---------------------------------------------------------  ------------  ------ ------ ------ ------"""
# Options
parser = OptionParser()
parser.add_option("-a", "--all", action="store_true", dest="do_all", default=False,
    help="Set Baseline on all Gandalfs")
parser.add_option("-b", "--id", dest="id", default="-1",
    help="board id")
parser.add_option("-v", "--value", dest="val", default=200,
    help="ADC Value to set DACs to")
parser.add_option("-e", "--error", dest="err", default=2,
    help="Error ADC Values may have for convergance")
parser.add_option("-s", "--start", dest="d0", default="7000",
    help="Start DAC Values for Iteration")
parser.add_option("-p", "--procentual", dest="p", default=5,
    help="Percentual Constant of our P-Controller")
parser.add_option("-f", "--filename", dest="fn", default=os.path.join(binfile_folder, "setdac_OCX.bin"),
    help="Filename of binfile for calibration")
(opts, args) = parser.parse_args()

# Sanity checks
if ((opts.id == "-1") and (not opts.do_all)):
    print "Hex ID is needed (use -b option) -h for Help"
    sys.exit(-1)

# TODO: exclude this
class SlinkHeader:
    def __init__(self, raw_data):
        self.data = raw_data
    def getFormat(self):
        return hex(int(self.data[2][0:8], 2))[2:]
    def getEventNo(self):
        return int(self.data[1][12:32], 2)
    def getEventSize(self):
        return int(self.data[0][16:32], 2)
    def printInfo(self):
        print "\n[SLINK Header] EventNo:%s\tEventSize:%s\tFormat:%s"%(self.getEventNo(), self.getEventSize(), self.getFormat())

class DebugHeader:
    def __init__(self, raw_data, isFooter):
        self.data = raw_data
        self.isFooter = isFooter
        if isFooter: self.infoStr = "Footer"
        else: self.infoStr = "Header"
    def getChannel(self):
        return int(self.data[8:12], 2)
    def getEventNo(self):
        return int(self.data[2:8], 2)
    def getSysMon(self):
        return hex(int(self.data[12:17], 2))[2:]
    def getFramesize(self):
        return int(self.data[17:28],2)
    def getRDM(self):
        return hex(int(self.data[28:32], 2))[2:]
    def printInfo(self):
        print "%s evt_no:%s\tch:%s\tFrameSize:%s\t"%(self.infoStr, self.getEventNo(), self.getChannel(), self.getFramesize())

class DebugData:
    def __init__(self, raw_data):
        self.data = raw_data
    def getADCValues(self):
        retval = []
        for data in self.data[:-1]:
            retval.append(int(data[2:16],2))
            retval.append(int(data[18:32],2))
        return retval

def bin(n, count=32):
    return "".join([str((n >> y) & 1) for y in range(count-1, -1, -1)])

def avg(values):
    h = reduce(lambda d,x: dict(d.items() + [(x, d.get(x, 0)+1)]), values, {})
    nbins, sumor= 0, 0
    for (n, bin) in sorted([(v, k) for (k, v) in h.iteritems()], reverse=True)[:3]:
        nbins += n
        sumor += n*bin
    return float(sumor) / float(nbins)

def ensure_dir(f):
    d = os.path.dirname(f)
    if not os.path.exists(d):
        os.makedirs(d)

def printList(l, n):
    nl = []
    nl.append("%i"%n)
    for v in l: nl.append("\t%.1f"%v)
    return info('%s' % ''.join(map(str, nl)))

def getDebugData(hex_id):
    readData=[]
    read_cmd        = "spyread -b %s"%(hex_id)
    trg_cmd = "vme_write e0%s718c 2"%(hex_id)
    for nread in range(0, 1):
        readData    .append([])
        data = []
        isDebugData = False
        oldLine = ""
        p = Popen("vme_write e0%s702c 2; sleep .5"%hex_id, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        (stdout, stderr)=p.communicate()
        p = Popen("vme_write e0%s704c 2"%hex_id, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        (stdout, stderr)=p.communicate()
        p = Popen(read_cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()
        nchan = 0
        for line in stdout.strip('\n').split('\n'):
            bindata = bin(int(line.strip(), 16))
            if (line.strip()!='cfed1200'):
                data.append(bindata)
            if (bindata[0:2] == '00'): #DebugHeader
                del data[:]
            if (bindata[0:2] == '01'): #DebugFooter
                dbg_data = DebugData(data)
                adc_vals = dbg_data.getADCValues()
                if (len(adc_vals) > 0):
                    readData[nread].append(adc_vals)
            if ((line.strip()!='00000000') and (oldLine=='00000000')):
                del data[:]
                data.append(bindata)
            oldLine = line.strip()
    retval=[]
    for i in range(0,16):retval.append([])
    for read in readData:
        nchan = 0
        for chan in read:
            for val in chan: retval[nchan].append(val)
            nchan += 1
    return retval

def getAVGs(hex_id):
    retval = []
    err_cnt = 0
    while (err_cnt < 3):
        adc = getDebugData(hex_id)
        nchan = 0
        for chan in adc:
            retval.append(avg(chan))
            nchan +=1
        if (len(retval) != 16):
            del retval[:]
            err_cnt += 1
        else:break
    if (err_cnt == 3):
        print "Error: AVG length was not 16 in 3 iterations"
        sys.exit(-1)
    return retval

def setDACs(set_dac_cmds, DAC_vals):
    for i in range(0, len(set_dac_cmds)):
        cmd = set_dac_cmds[i]%"%s%s"%(DAC_vals[2*i+1], DAC_vals[2*i])
        p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        (stdout, stderr)=p.communicate()

def info(s):
    if (not opts.do_all): print s
    return "# %s\n"%s

def setBaseline(hex_id):
    converged = False
    DAC_vals=[opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0,
            opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0, opts.d0]
    DAC_converged=[False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False, False]
    set_dac_cmds     = ["vme_write e0%s20c0"%(hex_id)+" %s",
                        "vme_write e0%s20c4"%(hex_id)+" %s",
                        "vme_write e0%s20c8"%(hex_id)+" %s",
                        "vme_write e0%s20cc"%(hex_id)+" %s",
                        "vme_write e0%s24c0"%(hex_id)+" %s",
                        "vme_write e0%s24c4"%(hex_id)+" %s",
                        "vme_write e0%s24c8"%(hex_id)+" %s",
                        "vme_write e0%s24cc"%(hex_id)+" %s"]
    fileout=""
    fileout += info(hello)

    cmd = "gansm3 %s %s %s; sleep 1"%(opts.fn, os.path.join(binfile_folder, "gandalf_mem_2009"), hex_id)
    if debug: print "Loading gandalf. Command: %s"%cmd
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()
    nLoadErr=0
    nTries= 30
    cmd = "gandalf_status|grep %sh"%(hex_id)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()
    if (len(stdout) == 0):
        if (not opts.do_all): print "Could not find Hex ID %s in gandalf_status, IS IT SWITCHED ON AND WORKING?"%(hex_id)
        else: print "%s\tNOT FOUND IN GANDALF_STATUS. IS IT SWITCHED ON AND WORKING?"%(hex_id)
        return
    while (("ERROR" in stdout) and (nLoadErr <= nTries)):
        if (not opts.do_all): print "Load Error, reloading...", stdout, stderr
        p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        (stdout, stderr)=p.communicate()
        nLoadErr += 1
    if (nLoadErr > nTries):
        if (not opts.do_all): print "Could not load Hex ID %s, it failed %i times."%(hex_id, nTries)
        else: "%s\tLOADING FAILED %i TIMES. SKIPPING NOW."%(hex_id, nTries)
        return
    #setDACs(set_dac_cmds, DAC_vals)
    getDebugData(hex_id)
    fileout += info("Iter\tADC0\tADC1\tADC2\tADC3\tADC4\tADC5\tADC6\tADC7\tADC8\tADC9\tADC10\tADC11\tADC12\tADC13\tADC14\tADC15")
    # increasing values
    jump_dac_vals = 200
    iteration = 1
    max_iterations = 50
    while (True):
        if (DAC_converged[0] and DAC_converged[1]
            and DAC_converged[2] and DAC_converged[3]
            and DAC_converged[4] and DAC_converged[5]
            and DAC_converged[6] and DAC_converged[7]
            and DAC_converged[8] and DAC_converged[9]
            and DAC_converged[10] and DAC_converged[11]
            and DAC_converged[12] and DAC_converged[13]
            and DAC_converged[14] and DAC_converged[15]):
            done = "Done.\n# UP"
            for i in range(0,16): done += "\t%s"%DAC_vals[i]
            fileout += info("%s/n"%done)
            break
        setDACs(set_dac_cmds, DAC_vals)
        adc_avg = getAVGs(hex_id)
        fileout += printList(adc_avg, iteration)
        for i in range(0, len(adc_avg)):
            adc_err = int(opts.val) - adc_avg[i]
            if (abs(adc_err) <= float(opts.err)):
                DAC_converged[i] = True
            if (DAC_converged[i]): continue

            calc = int(DAC_vals[i], 16) - int(float(opts.p) * adc_err)
            DAC_vals[i] = hex(calc).lstrip('0x')
        iteration += 1
        if (iteration == max_iterations):
            fileout += info("Error. Did not converge after %i iterations. Aborting."%max_iterations)
            if (opts.do_all): print "%s\tINC FAILED AFTER %i ITERATIONS."%(hex_id, max_iterations)
            break
    DAC_vals_inc = DAC_vals[:]
    # decreasing values
    iteration = 1
    DAC_converged=[False, False, False, False, False, False, False,
        False, False, False, False, False, False, False, False, False]
    for i in range(len(DAC_vals)):
        DAC_vals[i] = hex(int(DAC_vals[i], 16) - jump_dac_vals).lstrip("0x")
    while (True):
        if (DAC_converged[0] and DAC_converged[1]
            and DAC_converged[2] and DAC_converged[3]
            and DAC_converged[4] and DAC_converged[5]
            and DAC_converged[6] and DAC_converged[7]
            and DAC_converged[8] and DAC_converged[9]
            and DAC_converged[10] and DAC_converged[11]
            and DAC_converged[12] and DAC_converged[13]
            and DAC_converged[14] and DAC_converged[15]):
            done = "Done.\n# DOWN"
            for i in range(0,16): done += "\t%s"%DAC_vals[i]
            fileout += info("%s"% done)
            break
        setDACs(set_dac_cmds, DAC_vals)
        adc_avg = getAVGs(hex_id)
        fileout += printList(adc_avg, iteration)
        for i in range(0, len(adc_avg)):
            adc_err = int(opts.val) - adc_avg[i]
            if (abs(adc_err) <= float(opts.err)):
                DAC_converged[i] = True
            if (DAC_converged[i]): continue

            calc = int(DAC_vals[i], 16) - int(float(opts.p) * adc_err)
            DAC_vals[i] = hex(calc).lstrip('0x')
        iteration += 1
        if (iteration == max_iterations):
            fileout += info("Error. Did not converge after %i iterations. Aborting."%max_iterations)
            if (opts.do_all): print "%s\tDEC FAILED AFTER %i ITERATIONS."%(hex_id, max_iterations)
            break
    DAC_vals_dec = DAC_vals[:]

    for i in range(len(DAC_vals)):
        DAC_vals[i] = hex((int(DAC_vals_inc[i], 16) + int(DAC_vals_dec[i], 16)) / 2 ).lstrip("0x")

    done = "\n# Summary of Increasing and Decreasing Dac Values:\n# INC"
    for i in range(0,16): done += "\t%s"%DAC_vals_inc[i]
    fileout += info(done)

    setDACs(set_dac_cmds, DAC_vals)
    done = "# DEC"
    for i in range(0,16): done += "\t%s"%DAC_vals_dec[i]
    fileout += info(done)[2:]

    done = "-------------------------------------------------------------------------------------------------------------------------------------\n# AVG"
    for i in range(0,16): done += "\t%s"%DAC_vals[i]
    fileout += info(done)
    if (opts.do_all): print "%s\t%s"%(hex_id, done.split('\n')[1].lstrip("# AVG\t"))
    fileout += info("Writing EEPROM.")

    p = Popen("vme_write e0%s702c 2"%hex_id, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()

    cmd = "vme_write e0%s701c 2; sleep 1.5"%(hex_id)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()

    cmd = "vme_write e0%s7024 2; sleep 1.5"%(hex_id)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()

    cmd = "gandalf_status |grep %sh| awk '{ print $14 }'"%(hex_id)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()
    amc1_sn = stdout.strip()
    cmd = "gandalf_status |grep %sh| awk '{ print $12 }'"%(hex_id)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()
    amc2_sn = stdout.strip()

    now = strftime("%d.%m.%Y_%H:%M:%S")
    filename_1 = os.path.join(logfile_path, hex_id, now)

    if (not opts.do_all): print "log file written to %s"%filename_1

    ensure_dir(filename_1)
    fp_1 = open(filename_1, "w")

    fp_1.write(fileout)

    fp_1.write("# Reload script:\n")

    fp_1.write("echo  'Gandalf HEX ID: %s'\n"%(hex_id))

    for i in range(0, len(set_dac_cmds)):
        cmd = "%s\n"%set_dac_cmds[i]%"%s%s"%(DAC_vals[2*i+1], DAC_vals[2*i])
        fp_1.write(cmd)
    fp_1.write("vme_write e0%s701c 2; sleep 1.5\n"%(hex_id))
    fp_1.write("vme_write e0%s7024 2; sleep 1.5\n"%(hex_id))

    cmd = "chmod +x %s"%(filename_1)
    p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    (stdout, stderr)=p.communicate()

    fp_1.close()

if (opts.do_all):
    print hello
    print "setting Baselines on Gandalfs ", ALL_HEX_IDS
    print "only showing Results for each Gandalf, this might seem slow"
    print
    print "HEXID\tDAC0\tDAC1\tDAC2\tDAC3\tDAC4\tDAC5\tDAC6\tDAC7\tDAC8\tDAC9\tDAC10\tDAC11\tDAC12\tDAC13\tDAC14\tDAC15"
    print "-------------------------------------------------------------------------------------------------------------------------------------"
    for id in ALL_HEX_IDS:
        setBaseline(id)
else:
    setBaseline(opts.id)

