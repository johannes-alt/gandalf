#!/bin/bash

BINF="$GANDALF_BINFILE_FOLDER/buechele/gpatterngen.bin"
#BINF="$GANDALF_BINFILE_FOLDER/gandalf_patterngen/g_patterngen_not_0_8.bin"

HEXID=$1

LOAD="$(gansm3 ${BINF} $GANDALF_BINFILE_FOLDER/gandalf_mem_2009 ${HEXID})"

echo "gansm3 output: ${LOAD}"
