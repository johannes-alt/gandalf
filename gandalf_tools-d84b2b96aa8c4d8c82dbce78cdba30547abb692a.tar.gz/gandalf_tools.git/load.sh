# This Loadscript is a modified version of the one used during 2012
# datataking at CERN. Modified framesize, prescaler and binfile location
# played with adc delay shift to optimize biterrors

#Loadscript for CAMERA Gandalfs
#Sanity checks implemented:
#  - first get valid Hex IDS from gandalf_status
#  - if there are valid Hex IDS to prog, try it.
#  - if programming fails N_FAILS_TO_BREAK_GAN_PROG times, skip that Gandalf
#  - if a Gandalf was progged, check init flag to become "f"
#  - ONLY valid and progged (init = f) Gandalfs are configured.
#  - ONLY valid and progged (init = f) Gandalfs are Memory checked.

# MODIFIED, NOT THE DVCS SETTING but the same binfile ...
#BINFILE="/sc/userdata/pk47/binfiles/triest_02.bin" #online idel shift, for runs until 999999
#BINFILE="/sc/userdata/pk47/binfiles/gta_new_01.bin" #online idel shift, for runs until 999999
#BINFILE="/sc/userdata/pk47/binfiles/spyread_big_9.bin" #online idel shift, for runs until 999999
#BINFILE="/sc/userdata/pk47/binfiles/savior_13.bin" #online idel shift, for runs until 999999
#BINFILE="/sc/userdata/pk47/binfiles/g_dsp_mes_delays_02.bin" #online idel shift, for runs until 999999
BINFILE="/sc/userdata/pk47/binfiles/g_dsp_GTA_r745.0.bin" #online idel shift, for runs until 999999
#old files, please add comment
#BINFILE=/paul/GTAadv_r734_bos_count_sync_CT84.bin  # for runs until 108677
#BINFILE=/paul/GTAadv_dsp_r724_cs_01.bin            # for runs until 108460
#BINFILE="../binfiles/g_dsp_r708.2.bin"             # for runs until 107017
#BINFILE="../tgfiles/binfiles/grussy/gandalf_matze.bin" #for matze .. ask befor remove
#BINFILE="../tgfiles/binfiles/grussy/gandalfref724/seed_89.bin" #the new, great, secret binfile ... please test this on 22.10., sebastian
#BINFILE="../binfiles/paul/GTAadv_dsp_r724_cs.bin" #for debug - with chipscope on sdr_slink and io_manager. cdc in ../binfiles/paul/cs.cdc

#load settings
SLEEPTIME=0.1
SLEEP_SHORT=.01
DISABLE_SDR=false
RESET_AFTER_LOAD=false
DISABLE_READBACK=false
DISABLE_DB=true
N_FAILS_TO_BREAK_VME_CMD=10
N_FAILS_TO_BREAK_GAN_PROG=10
ALL_FLAG_HEXIDS=" 20 21 22 23 24 25 30 31 32 33 34 35 40"

#gandalf settings
WIN="064"       # window size 1f4 is max atm MODIFIED, NOT THE DVCS SETTING
LAT="032"       # window latency
TFD="0b0c03"    # cf parameters: tresh del frac DVCS: 0b0c03, ff0000 to disable cfd? MODIFIED, NOT THE DVCS SETTING
TDF="0b0c03"    # tiger cf parameters: tresh del frac
RMAX="5"        # tiger cf max dist
TMAX="5"        # for laser take RMax,TMax=2,1,0 aproximately
BASEL="0c8"     # baseline MODIFIES, was 0c8
PRESCALER="4"  # debug event prescaler MODIFIED, NOT THE DVCS SETTING

#gandalf addresses
ADDR_WIN_LAT="2b00"
ADDR_TFD="2b14"
ADDR_TDF="2d00"
ADDR_RTMAX="2d04"
ADDR_BASE_PRE="20d0"

#usage
USAGE="""Usage: `basename $0` [options] <HEXID_1> <HEXID_2> <HEXID_3>
    options:    -f <binfile>    Binfile to load.
                    default: $BINFILE
            -d      Disable SDR Data Links to Tiger
                    default: $DISABLE_SDR
            -w      Disable read settings from database
                    default: $DISABLE_DB
            -r      Reset Gandalf(s) after loading
                    default: $RESET_AFTER_LOAD
            -n      Dont check cfmem Readback after loading
                    default: $DISABLE_READBACK
            -a      load all Gandalfs of Camera.
                    HEX IDS= ($ALL_FLAG_HEXIDS)
"""

#variables
IDS=""
PROGGED_IDS=""
CHECK_ADDR=""
CHECK_DATA=""
SRC_IDS=""
HEXIDS_IN_GANSTAT=""
HEXIDS_NOT_FOUND=""

db_win=""
db_lat=""
db_tfd=""
db_tdf=""
db_rmax=""
db_tmax=""
db_basel=""
db_pre=""

db_addr_win_lat=""
db_addr_tfd=""
db_addr_tdf=""
db_addr_rtmax=""
db_addr_base_pre=""

#execute vme command and check for errors, repeat if error
function verifyCmd() {
    todo=true
    nattempts=0
    while $todo; do
        if [ $nattempts -eq $N_FAILS_TO_BREAK_VME_CMD ]; then
            echo "Command $1 failed after $N_FAILS_TO_BREAK_VME_CMD attempts."
            todo=false
        fi
        retval=$($1)
        case "$retval" in
            *VME*)
                echo VME Error. Redoing.
                ;;
            *ERROR*)
                echo Error. Redoing.
                ;;
            *)
                todo=false
        esac
        nattempts=$(echo $nattempts+1|bc);
    done
}

#parse command line options.
while getopts ardenwhf: OPT; do
    case "$OPT" in
        h)
            echo "$USAGE"
            exit 0
            ;;
        f)
            BINFILE=$OPTARG
            ;;
        w)
            DISABLE_DB=false
            ;;
        d)
            DISABLE_SDR=true
            ;;
        e)
            echo "Enable SDR is default now, -d to disable."
            ;;
        r)
            RESET_AFTER_LOAD=true
            ;;
        n)
            DISABLE_READBACK=true
            ;;
        a)
            IDS=$ALL_FLAG_HEXIDS
            ;;
        \?)
            echo "$USAGE" >&2
            exit 1
            ;;
    esac
done

#remove the switches we parsed above.
shift `expr $OPTIND - 1`

# If no -a switch, save given Hex Ids in IDS Variable
if [ "$IDS" == "" ]; then
    for PARAM; do
        IDS=$IDS" "$PARAM
    done
fi

#now, IDS must contain a HEX ID, otherwise:
if [ "$IDS" == "" ]; then
    echo "Error: At least one HEXID Needed" >&2
    echo "$USAGE" >&2
    exit 1
fi

#sanity: check if IDS are available.
echo "Searching for Gandalfs"
CHECK_IDS=$IDS
IDS=""
for id in $(gandalf_status | awk '{print $2}'); do
    ACTID=$(echo $id| grep 'h$'|cut -d "h" -f 1);
    if [ -z $ACTID ]; then continue; fi
    case "$CHECK_IDS" in
        *" $ACTID"*)
            IDS=$IDS" "$ACTID
            ;;
        *)  ;;
    esac
    HEXIDS_IN_GANSTAT=$HEXIDS_IN_GANSTAT" "$ACTID;
done
for id_to_check in $CHECK_IDS; do
    found=false
    case "$IDS" in
        *" $id_to_check"*)
            ;;
        *)
            HEXIDS_NOT_FOUND=$HEXIDS_NOT_FOUND" "$id_to_check
            ;;
    esac
done

#now, IDS can be empty again, so:
if [ "$IDS" == "" ]; then
    echo " None of the given Hex IDS seems to be present. Please recheck gandalf_status. " >&2
    echo " Given IDS: $CHECK_IDS"
    echo " Found IDS: $HEXIDS_IN_GANSTAT"
    exit 1
else
    if [ ! -z "$HEXIDS_NOT_FOUND" ]; then
        echo " Could not find Gandalf(s) $HEXIDS_NOT_FOUND in gandalf_status."
        echo " will not try to programm them."
    fi
fi

#compare settiings with db
#~ function verifyDBData() {
    #~ if [ "$1" != "$2" ]; then
        #~ echo " DB $3 differs from loadscript $3. DB: $1 load: $2"
    #~ fi
#~ }
#~
#~ #load settiings from db
#~ echo "Loading Settings from DB"
#~ QUERRY="""
#~ use $DB_DB;
#~ select distinct Detector, Gate_window, Gate_latency
#~ from FRONTEND
#~ where Detector like '%CAMERA%'
    #~ and Version_tag like '%latest%';"""
#~ db=$(echo $(mysql -u$DB_USER -p$DB_PASSWD --host=$DB_SERVER -e "$QUERRY") | cut -d " " -f 5-6)
#~ db_win=$(printf "%03x\n" $(echo $db | cut -d " " -f 1 | cut -d "=" -f2))
#~ db_lat=$(printf "%03x\n" $(echo $db | cut -d " " -f 2 | cut -d "=" -f2))
#~ verifyDBData "$db_win" "$WIN"  "window"
#~ verifyDBData "$db_lat" "$LAT"  "latency"
#~
#~ DB_SETTINGS_NAMES="mod-prescaler-baseline readout-cfd trigger-cfd
#~ trigger-maxdist mod-load-g-conf-val mod-set-dacs mod-VXS-bus-cal
#~ mod-readout-tiger-ready mod-synchronize-time mod-sweep-si"
#~ QUERRY="""
#~ use $DB_DB;
#~ select Name, Expansion
#~ from MACROS
#~ where Name like '%<arg>%'
    #~ and Version_tag like '%latest%';"""
#~ for name in $DB_SETTINGS_NAMES; do
    #~ db=$(echo $(mysql -u$DB_USER -p$DB_PASSWD --host=$DB_SERVER -e "${QUERRY/<arg>/$name}") | cut -d " " -f 3-4)
    #~ val=$(echo $db | cut -d " " -f 2 | cut -d "=" -f2)
    #~ addr=$(echo $db | cut -d " " -f 2 | cut -d "=" -f1 | cut -d "x" -f2)
    #~ case "$name" in
        #~ *baseline*)
            #~ db_basel=$(echo $val | cut -b 6-8| tr '[A-Z]' '[a-z]')
            #~ db_pre=$(echo $val | cut -b 4-5| tr '[A-Z]' '[a-z]')
            #~ db_addr_base_pre=$addr
            #~ verifyDBData "$db_addr_base_pre" "$ADDR_BASE_PRE"  "baseline_prescaler_address"
            #~ verifyDBData "$db_basel" "$BASEL"  "baseline"
            #~ verifyDBData "$db_pre" "$PRESCALER"  "prescaler"
        #~ ;;
        #~ *readout-cfd*)
            #~ db_tfd=$(echo $val | cut -b 3-16 | tr '[A-Z]' '[a-z]')
            #~ db_addr_tfd=$addr
            #~ verifyDBData "$db_addr_tfd" "$ADDR_TFD"  "readout_cfd_address"
            #~ verifyDBData "$db_tfd" "$TFD"  "readout_cfd_params"
        #~ ;;
        #~ *trigger-cfd*)
            #~ db_tdf=$(echo $val | cut -b 3-16 | tr '[A-Z]' '[a-z]')
            #~ db_addr_tdf=$addr
            #~ verifyDBData "$db_addr_tdf" "$ADDR_TDF"  "trigger_cfd_address"
            #~ verifyDBData "$db_tdf" "$TDF"  "trigger_cfd_params"
        #~ ;;
        #~ *trigger-maxdist*)
            #~ db_rmaxtmax=$(echo $val | cut -b 7-8 | tr '[A-Z]' '[a-z]')
            #~ db_rmax=${db_rmaxtmax:0:1}
            #~ db_tmax=${db_rmaxtmax:1:1}
            #~ db_addr_rtmax=$addr
            #~ verifyDBData "$db_addr_rtmax" "$ADDR_RTMAX"  "trigger_maxdist_address"
            #~ verifyDBData "$db_rmax" "$RMAX"  "trigger_maxdist_rmax"
            #~ verifyDBData "$db_tmax" "$TMAX"  "trigger_maxdist_tmax"
        #~ ;;
    #~ esac
#~ done
#~ if (! $DISABLE_DB ); then
    #~ echo "Using DB Parameters"
    #~ WIN=$db_win          # window size
    #~ LAT=$db_lat          # window latency
    #~ TFD=$db_tfd          # cf parameters: tresh del frac
    #~ TDF=$db_tdf          # tiger cf parameters: tresh del frac
    #~ RMAX=$db_rmax        # tiger cf max dist
    #~ TMAX=$db_tmax        # for laser take RMax,TMax=2,1,0 aproximately
    #~ BASEL=$db_basel      # baseline
    #~ PRESCALER=$db_pre    # debug event prescaler
#~ else
    #~ echo "Using load Parameters"
#~ fi

#start sending
#wall 'Programming Gandalf(s) '$(echo $IDS)' with '$BINFILE
sleep $SLEEP_SHORT

#load modules
for VAL in $IDS; do
  unprogramed=true
  nattempts=0
  while $unprogramed; do
    if [ $nattempts -eq $N_FAILS_TO_BREAK_GAN_PROG ]; then
        echo "Programming Gandalf $VAL failed after $N_FAILS_TO_BREAK_GAN_PROG attempts." >&2
        unprogramed=false
    fi
    retval=$(gansm3 $BINFILE /sc/userdata/pk47/binfiles/gandalf_mem_2009 $VAL)
    case "$retval" in
      *ERROR*)
        if [[ "$retval" == *"Input/output"* ]]; then
                echo "Gandalf $VAL not found. can you see it in gandalf_status?" >&2
                break;
        fi
        echo "Error while loading $VAL: $retval. Reloading..." >&2
        ;;
      *)
        #Sanity, check for init flag. now it must become f
        initf=$(gandalf_status | grep "$VAL"h | awk '{print $4}')
        if [ $initf == "f" ]; then
          header_mis=$(gandalf_status | grep "$VAL"h | awk '{print $5}')
          if [ $header_mis == "PLEASE" ]; then
            echo "Status Word Header Mismatch. Reloading ..." >&2
          else
            echo Gandalf $VAL programmed.
            unprogramed=false
            PROGGED_IDS=$PROGGED_IDS" "$VAL
          fi
        else
          echo "Init Flag of Gandalf $VAL not f after loading. Reloading..." >&2
        fi
    esac
    nattempts=$(echo $nattempts+1|bc);
  done
done

#now, PROGGED_IDS must contain a HEX ID, otherwise:
if [ "$PROGGED_IDS" == "" ]; then
    echo " We did not programm any Gandalf, so no need to set anything." >&2
    exit 1
fi

#reset
if $RESET_AFTER_LOAD; then
    echo ' resetting'
    for VAL in $PROGGED_IDS; do
      verifyCmd "vme_write e0$(echo $VAL)7040 1"
      sleep $SLEEP_SHORT
    done
    sleep $SLEEPTIME
    for VAL in $PROGGED_IDS; do
      verifyCmd "vme_write e0$(echo $VAL)7040 0"
      sleep $SLEEP_SHORT
    done
    sleep $SLEEPTIME
fi

#set source ids
for VAL in $PROGGED_IDS; do
  SOURCEID=$(echo '800 + '$VAL | bc)
  SID_HEX=$(printf "%08x\n" $SOURCEID)
  SRC_IDS=$SRC_IDS" $SID_HEX"
  echo ' setting source ID' $SOURCEID
  verifyCmd "vme_write e0$(echo $VAL)2804 $SID_HEX"
  sleep $SLEEP_SHORT
done

#set window latency
echo ' setting Window = '${WIN}' and Latency = ' ${LAT}
CHECK_ADDR="f04 "$CHECK_ADDR
CHECK_DATA="0$(echo $WIN)0$(echo $LAT) "$CHECK_DATA
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)$(echo $ADDR_WIN_LAT) 0$(echo $WIN)0$(echo $LAT)"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#set cf parameters: tresh del frac
echo ' setting cf parameters: = '${TFD}
CHECK_ADDR="f0c "$CHECK_ADDR
CHECK_DATA="00$(echo $TFD) "$CHECK_DATA
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)$(echo $ADDR_TFD) 00$(echo $TFD)"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#set T cf parameters: tresh del frac
echo ' setting T cf parameters: = '${TDF}
# TODO since only T parameter is used, we have to parse here.
#~ CHECK_ADDR="d00 "$CHECK_ADDR
#~ CHECK_DATA="00$(echo $TDF) "$CHECK_DATA
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)$(echo $ADDR_TDF) 00$(echo $TDF)"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#set T cf max dist --> for laser take RMax,TMax=2,1,0 aproximately <--
echo ' setting cf max dist: = '${RMAX}
echo ' setting T cf max dist: = '${TMAX}
CHECK_ADDR="f14 "$CHECK_ADDR
CHECK_DATA="000000$(echo $RMAX)$(echo $TMAX) "$CHECK_DATA
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)$(echo $ADDR_RTMAX) 000000$(echo $RMAX)$(echo $TMAX)"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#define baseline, select prim prescaler
echo ' setting Baseline = '${BASEL}' and Prescaler= '${PRESCALER}
CHECK_ADDR="f08 "$CHECK_ADDR
CHECK_DATA="000$(echo $PRESCALER)$(echo $BASEL) "$CHECK_DATA
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)$(echo $ADDR_BASE_PRE) 000$(echo $PRESCALER)$(echo $BASEL)"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#set dacs
echo ' setting DACs'
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)702c 2"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#read temp
echo ' reading temp'
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)7010 2"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#load conf
echo ' loading conf'
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)7034 2"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#readback
if ! $DISABLE_READBACK; then
    echo ' starting cfmem readback'
    for VAL in $PROGGED_IDS; do
        verifyCmd "vme_write e0$(echo $VAL)70c8 2"
        sleep $SLEEP_SHORT
    done
    echo ' checking cfmem data'
    nval=1
    for VAL in $PROGGED_IDS; do
        i=1
        for ADDR in $CHECK_ADDR; do
            GOOD_DATA=$(echo $CHECK_DATA|awk '{print $'$i'}');
            STATUS="$(vme_write e0${VAL}2${ADDR})"
            if [[ "$(echo $STATUS | tr '[A-Z]' '[a-z]')" == *"$(echo $GOOD_DATA | tr '[A-Z]' '[a-z]')"* ]]; then
                echo "  data $STATUS at addr $ADDR on Gandalf $VAL verfied."
            else
                echo "  error on Gandalf $VAL: Data $STATUS at addr $ADDR not correct. Should be $GOOD_DATA"
            fi
            i=$(echo $i+1|bc);
        done
        GOOD_DATA=$(echo $SRC_IDS|awk '{print $'$nval'}');
        STATUS="$(vme_write e0${VAL}2f00 )"
        if [[ "$(echo $STATUS | tr '[A-Z]' '[a-z]')" == *"$(echo $GOOD_DATA | tr '[A-Z]' '[a-z]')"* ]]; then
            echo "  srcid $STATUS at addr $ADDR on Gandalf $VAL verfied."
        else
            echo "  error on Gandalf $VAL: srcid $STATUS at addr $ADDR not correct. Should be $GOOD_DATA"
        fi
        nval=$(echo $nval+1|bc);
        sleep $SLEEP_SHORT
    done
    sleep $SLEEPTIME
fi

#calibrate VXS bus
echo ' calibrating VXS bus (Trigger tiger)'
for VAL in $PROGGED_IDS; do
    verifyCmd "vme_write e0$(echo $VAL)70ac 2"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

#enable sdr
if ! $DISABLE_SDR; then
    echo ' enabling sdr Tiger Data Link'
    for VAL in $PROGGED_IDS; do
      verifyCmd "vme_write e0$(echo $VAL)70a4 1"
      sleep $SLEEP_SHORT
    done
    sleep $SLEEPTIME
fi

#sync time to Mastertime
#echo ' syncing to Mastertime'
#verifyCmd "crate_write 705c 2"
#ssh pccofe41 '/online/detector/gandalf/GandalfTools/VME_MEN/vme_write e001705c 2 >> /dev/null' &
#sleep $SLEEPTIME

#reprog si
echo ' reprogramming SIs'
for VAL in $PROGGED_IDS; do
  verifyCmd "vme_write e0$(echo $VAL)7028 2"
  sleep $SLEEP_SHORT
done
sleep $SLEEPTIME

# This was MODIFIED, NOT THE DVCS SETTING
#HACK:shift adc delay of adc9 for -10 tabs, TODO: remove, build binfile without biterrors
#echo ' removing bit errors from chan4'
#for VAL in $PROGGED_IDS; do
#    HEX_VAL="0200" # 0000001000000000 in binary, so only adc9 has a 1 (adc15 .. adc0)
#    for nBit in {0..13}; do
#        #if [ $nBit == 11 ]; then continue; fi; # Bit 11 is special ...
#        ADDR=$(echo $(printf "%03x" $(echo "768 + (4 * $nBit)" | bc)))
#        cmd="vme_write e0$(echo $VAL)2$(echo $ADDR) $(echo $HEX_VAL)0000 >> /dev/null" # decrease
#        $cmd
#    done
#    cmd="vme_write e0$(echo $VAL)70cc 2 >> /dev/null"
#    for nShift in {0..10}; do
#        $cmd
#    done
#    sleep $SLEEP_SHORT
#done
#sleep $SLEEPTIME

#HACK:shift adc delay of adc3 for +10 tabs, TODO: remove, build binfile without biterrors
#~ echo ' removing bit errors from chan1'
#~ for VAL in $PROGGED_IDS; do
    #~ HEX_VAL="1000" # 0001000000000000 in binary, so only adc3 has a 1 (adc15 .. adc0)
    #~ for nBit in {0..13}; do
        #~ ADDR=$(echo $(printf "%03x" $(echo "768 + (4 * $nBit)" | bc)))
        #~ cmd="vme_write e0$(echo $VAL)2$(echo $ADDR) $(echo $HEX_VAL)$(echo $HEX_VAL) >> /dev/null" # increase
        #~ $cmd
    #~ done
    #~ cmd="vme_write e0$(echo $VAL)70cc 2 >> /dev/null"
    #~ for nShift in {0..10}; do
        #~ $cmd
    #~ done
    #~ sleep $SLEEP_SHORT
#~ done
sleep $SLEEPTIME

#sweep si
echo ' starting SI sweep'
sleep $SLEEPTIME
sleep $SLEEPTIME
sleep $SLEEPTIME
sleep $SLEEPTIME
sleep $SLEEPTIME
for VAL in $PROGGED_IDS; do
 verifyCmd "vme_write e0$(echo $VAL)70f0 2"
 sleep $SLEEP_SHORT
done

echo 'Done.'

