#!/usr/bin/env python2
import optparse, sys, os, time
import subprocess
import ConfigParser

# switch to enable/disable debug output
debug = False
MAX_N_READS = 10

def exec_cmd(cmd, msg = ""):
  """Executes cmd in a Bash. Uses Popen and PIPEs to do that."""
  if len(msg) > 0: print msg
  if debug: print "Executing: %s"%(cmd)
  p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  (stdout, stderr)=p.communicate()
  if debug: print "stdout: %s\t stderr: %s"%(stdout, stderr)
  return (stdout, stderr)

class ConfBus:
  def print_status(self, status_type):
    for addr, val in self.cfg.items('addrs'):
      type, name = val.split(':')
      if type != status_type : continue
      print "\nStatus of %s"%name
      output = int(self.read(addr), 16)
      print self.cfg.get(status_type, "header").replace(':', '\t')
      for group, val in self.cfg.items(status_type):
        if group == "header": continue
        str = "%s\t\t" % group
        bitstring = "{:032b}".format(output)
        for bitrange in val.split(':'):
          bits = bitrange.split(',')
          str += "%x\t\t" % int(bitstring[int(bits[0]):int(bits[1])], 2)
        print str

  def print_options(self):
    stat_cnt, cfg_cnt = 0, 0
    retval = {'r' : {}, 'w' : {}}
    stat_str = "\nReadable Sections: "
    cfg_str = "Writable Sections: "
    for section in self.cfg.sections():
      if not (("status" in section) or ("config" in section)): continue
      if "config" in section:
        cfg_str += "%s[w%i], "%( section, cfg_cnt )
        retval["w%i"%cfg_cnt] = section
        cfg_cnt += 1
      stat_str += "%s[r%i], "%( section, stat_cnt )
      retval["r%i"%stat_cnt] = section
      stat_cnt += 1
    print stat_str.strip(", ")
    print cfg_str.strip(", ")
    return retval

class Ganbus(ConfBus):
  def __init__(self, cfg, hexid, addr_addr = "114", addr_data = "118", fr_doop = "0b4"):
    self.cfg = ConfigParser.ConfigParser()
    self.cfg.read(cfg)
    self.cmd_write_addr = "vme_write e0{hexid}2{addr}".format(hexid=hexid, addr=addr_addr) + " {data}"
    self.cmd_write_data = "vme_write e0{hexid}2{addr}".format(hexid=hexid, addr=addr_data) + " {data}"
    self.cmd_fr_doop = "vme_write e0{hexid}7{addr} 2".format(hexid = hexid, addr = fr_doop)

  def write(self, addr, data):
    exec_cmd(self.cmd_write_addr.format(data = addr))
    exec_cmd(self.cmd_write_data.format(data = data))
    exec_cmd(self.cmd_fr_doop)

  def read(self, addr):
    retval, op_done = "", "0"
    exec_cmd(self.cmd_write_addr.format(data = "1%s"%addr))
    exec_cmd(self.cmd_fr_doop)
    while op_done == "0":
      op_done = exec_cmd(self.cmd_write_addr.format(data = ""))[0][1]
    retval = exec_cmd(self.cmd_write_data.format(data = ""))[0]
    return retval

class Optbus(ConfBus):
  def __init__(self, cfg, hexid, read_addr, write_addr, read_reg_addr, write_reg_addr):
    self.ganbus = Ganbus(cfg, hexid)
    self.cfg = ConfigParser.ConfigParser()
    self.cfg.read(cfg)
    self.read_addr = read_addr
    self.write_addr = write_addr
    self.read_reg_addr = read_reg_addr
    self.write_reg_addr = write_reg_addr

  def write(self, addr, data):
    #setting the data
    self.ganbus.write(self.read_reg_addr, data)
    #setting the addr and starting the transmit to the omc
    self.ganbus.write(self.read_addr, addr)

  def read(self, addr):
    #sending the addr of the omc register which is to be read
    self.ganbus.write(self.write_reg_addr, addr)
    return self.ganbus.read(self.write_addr)

class Tigbus(ConfBus):
  def __init__(self, cfg, addr_addr = "45", addr_data = "46", fr_doop = "45"):
    self.cfg = ConfigParser.ConfigParser()
    self.cfg.read(cfg)
    self.cmd_write_addr = "tg_configmem -w {addr}".format(addr = addr_addr) + " {data}"
    self.cmd_write_data = "tg_configmem -w {addr}".format(addr = addr_data) + " {data}"
    self.cmd_read_doop  = "tg_configmem -r {addr}".format(addr = addr_addr)
    self.cmd_read_data  = "tg_configmem -r {addr}".format(addr = addr_data)
    self.cmd_fr_doop = "tg_register -w -f{addr} 2".format(addr = fr_doop)

  def write(self, addr, data):
    exec_cmd(self.cmd_write_addr.format(data = addr))
    exec_cmd(self.cmd_write_data.format(data = data))
    exec_cmd(self.cmd_fr_doop)

  def read(self, addr):
    retval, op_done, err_cnt = "", "0", 0
    exec_cmd(self.cmd_write_addr.format(data = "1%s"%addr))
    exec_cmd(self.cmd_fr_doop)
    while op_done == "0":
      op_done = exec_cmd(self.cmd_read_doop)[0].split('\n')[1][1]
      err_cnt += 1
      if err_cnt >= MAX_N_READS:
        print "Error reading from confbus. Operation done was not signaled after %i tries."%err_cnt
        sys.exit()
    retval = exec_cmd(self.cmd_read_data)[0].split('\n')[1]
    return retval

  def bitset(self, addr, bitmask, value):
    # this line reads the addr, clears bits defined by bitmask and sets values bits there
    new_state = ( int(self.read(addr), 16) & ~bitmask ) | ( bitmask & value )
    self.write(addr, "%.8X"%new_state)

def parse_args():
    description = "generic configbus tool"
    usage = "usage: %prog [options] hexid"
    p = optparse.OptionParser(description=description, usage=usage)
    p.add_option("-c", "--cfg",     dest="cfg", default="cfbus_configs/tiger_readout.cfg", help="The config file to read all settings from")
    (opts, args) = p.parse_args()
    if len(args) != 1:
      p.print_usage()
      sys.exit()
    return (opts, args)

def main():
  opts, args = parse_args()
  tb = Tigbus(opts.cfg)
  user_quit = False
  while not user_quit:
    options = tb.print_options()
    input = raw_input("Your choice (q to quit):")

    if input == "q": user_quit = True
    elif input in options:
      if "r" in input: tb.print_status(options[input])
      else:
        raw_input("Data to write to %s"%options[input])
    else: print "unknown option"

if __name__ == "__main__": main()
