#!/usr/bin/python
import optparse, sys, os, time
import subprocess
import ConfigParser
from time import sleep

#debug = True
debug = False

def parse_args():
    usage = "usage: %prog -g hexid [-i -n]"
    description = "LVDS fabout board configuration tool providing test pulses to aragorn"
    p = optparse.OptionParser(description=description, usage=usage)
    p.add_option("-g", "--gandalf",      dest="gandalf",      default="-1",     help="hexid of gandalf")
    p.add_option("-i", "--interleaved",  dest="interleaved",  default=False,  help="interleaved mode", action="store_true")
    p.add_option("-n", "--nim",          dest="nim",          default=False,  help="use nim inputs, default is internal signals", action="store_true")
    (opts, args) = p.parse_args()
    return (opts, args)

def exec_cmd(cmd, msg = ""):
  """Executes cmd in a Bash. Uses Popen and PIPEs to do that."""
  if len(msg) > 0: print msg
  if debug: print "Executing: %s"%(cmd)
  p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  (stdout, stderr)=p.communicate()
  if debug: print "stdout: %s\t stderr: %s"%(stdout, stderr)
  return (stdout, stderr)

def main():
    (options, args) = parse_args()
#sanity checks
    if options.gandalf != "-1":
        hexid = options.gandalf
    else:
        print "gandalf hexid not set!"
        return(0)
        
    if options.interleaved:
        exec_cmd("vme_write e0%s7120 1" %hexid, "Enable X-point switch S20,40 for interleaved mode")
        exec_cmd("vme_write e0%s7124 1" %hexid, "Enable X-point switch S21,41 for interleaved mode")
    else:
        exec_cmd("vme_write e0%s7120 0" %hexid)
        exec_cmd("vme_write e0%s7124 0" %hexid)

    if options.nim:
        exec_cmd("vme_write e0%s7140 1" %hexid, "Enable gandalf nim inputs")
    else:
        exec_cmd("vme_write e0%s7140 0" %hexid)
        print "Enter infinite loop: apply fastregisters to provide input signals..." 
        while 1:
            exec_cmd("vme_write e0%s7118 2" %hexid)
	    sleep(0.1)
#            exec_cmd("vme_write e0%s711c 2" %hexid)
		  
if __name__ == "__main__":
  main()
