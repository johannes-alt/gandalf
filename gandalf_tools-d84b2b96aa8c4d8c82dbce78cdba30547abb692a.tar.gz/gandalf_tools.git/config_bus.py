#!/usr/bin/python
# GANdalf conFIGurator
import optparse, sys, os, time
import subprocess
import ConfigParser
#from bitstring import BitArray, BitStream
#debug = True
debug = False

def parse_args():
    usage = "usage: %prog -g hexid -a addr [-w -d data -o up/down]"
    description = "Gandalf Configuration Tool for config_bus  --  default operation is reading registers, to write a reg give the -w option"
    p = optparse.OptionParser(description=description, usage=usage)
    p.add_option("-o", "--omc",     dest="omc",     default="-1",  help="we want a arwen card")
    p.add_option("-a", "--addr",    dest="addr",    default="-1",  help="addr of register")
    p.add_option("-g", "--gandalf", dest="gandalf", default="-1",  help="hexid of gandalf")
    p.add_option("-d", "--data",    dest="data",    default="-1",  help="data to write")
    p.add_option("-w", "--write",   dest="write",   default=False, help="write register", action="store_true")
    (opts, args) = p.parse_args()
    return (opts, args)

def exec_cmd(cmd, msg = ""):
  """Executes cmd in a Bash. Uses Popen and PIPEs to do that."""
  if len(msg) > 0: print msg
  if debug: print "Executing: %s"%(cmd)
  p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  (stdout, stderr)=p.communicate()
  if debug: print "stdout: %s\t stderr: %s"%(stdout, stderr)
  return (stdout, stderr)

def write_gandalf(hexid, addr, data):
    exec_cmd("vme_write e0%s2114 %s" % (hexid, addr), "setting addr for write")
    exec_cmd("vme_write e0%s2118 %s" % (hexid, data), "setting data for write")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

def read_gandalf(hexid, addr):
    exec_cmd("vme_write e0%s2114 1%s" % (hexid, addr), "reading from gandalf")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

    #wait until op is finished
    op_in_progress = True
    while op_in_progress:
        output = exec_cmd("vme_write e0%s2114" % hexid, "reading op_done flag")
        if "1" in output[0][1]:
            op_in_progress = False

    #gather data
    output = exec_cmd("vme_write e0%s2118" % hexid, "reading data from operation")            
    return output[0]

def write_omc(hexid, read_addr, read_reg_addr, addr, data):
    #setting the data
    exec_cmd("vme_write e0%s2114 %s" % (hexid, read_reg_addr), "setting addr for read_reg of mezzanine")
    exec_cmd("vme_write e0%s2118 %s" % (hexid, data), "writing data to the read_reg (reading from bus) for upper mezzanine")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

    #setting the addr and starting the transmit to the omc
    exec_cmd("vme_write e0%s2114 %s" % (hexid, read_addr), "setting addr for read (from bus) of upper mezzanine")
    exec_cmd("vme_write e0%s2118 %s" % (hexid, addr), "writing addr for upper register, starting transfer")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

def read_omc(hexid, write_addr, write_reg_addr, addr):
    #sending the addr of the omc register which is to be read
    exec_cmd("vme_write e0%s2114 %s" % (hexid, write_reg_addr), "setting addr for write_reg of mezzanine")
    exec_cmd("vme_write e0%s2118 %s" % (hexid, addr), "writing addr for mezzanine register to read")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

    #starting transfer
    exec_cmd("vme_write e0%s2114 1%s" % (hexid, write_addr), "reading from of mezzanine")
    exec_cmd("vme_write e0%s70b4 2" % hexid, "Do OP fastregister")

    #wait until op is finished
    op_in_progress = True
    while op_in_progress:
        output = exec_cmd("vme_write e0%s2114" % hexid, "reading op_done flag")
        if "1" in output[0][1]:
            op_in_progress = False

    #gather data
    output = exec_cmd("vme_write e0%s2118" % hexid, "reading data from operation")            
    return output[0]

def main():
    (options, args) = parse_args()
#sanity checks
    if options.gandalf != "-1":
        hexid = options.gandalf
    else:
        print "gandalf hexid not set!"
        return(0)
        
    if options.addr != "-1":
        addr = options.addr
    else:
        print "addr not set!"
        return(0)

    if options.write:
        if options.data == "-1":
            print "data not set! For a write we need data"
            return(0)

# writing or reading to/from a omc register
    if options.omc != "-1":
        if options.omc == "up":
            read_addr = "0041"
            write_addr = "0042"
            read_reg_addr = "0043"
            write_reg_addr = "0044"
            if options.write:
                write_omc(hexid, write_addr, write_reg_addr, addr, options.data)
            else:
                print read_omc(hexid, read_addr, read_reg_addr, addr)
        elif options.omc == "down":
            read_addr = "0045"
            write_addr = "0046"
            read_reg_addr = "0047"
            write_reg_addr = "0048"
            if options.write:
                write_omc(hexid, write_addr, write_reg_addr, addr, options.data)
            else:
                print read_omc(hexid, read_addr, read_reg_addr, addr)
        else:
            print "no valid omc selected, choose up or down"
            return(0)
        return(0)

# writing or reading to/from gandalf register
    if options.write:
                write_gandalf(hexid, addr, options.data)
    else:
        print read_gandalf(hexid, addr)

if __name__ == "__main__":
  main()
