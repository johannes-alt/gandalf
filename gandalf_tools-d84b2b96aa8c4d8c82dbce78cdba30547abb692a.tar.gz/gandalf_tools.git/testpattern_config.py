#!/usr/bin/python
# GANdalf conFIGurator
import optparse, sys, os, time
import subprocess
import ConfigParser
#from bitstring import BitArray, BitStream
debug = False

def parse_args():
  p = optparse.OptionParser(description="Gandalf Configuration Tool")
  p.add_option("-s", "--set", dest="set", default="-1",      help="set length")
  p.add_option("-i", "--sourceid", dest="sourceid", default="-1",      help="set SourceId")
  (opts, args) = p.parse_args()
  return (opts, args)

def exec_cmd(cmd, msg = ""):
  """Executes cmd in a Bash. Uses Popen and PIPEs to do that."""
  if len(msg) > 0: print msg
  if debug: print "Executing: %s"%(cmd)
  p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  (stdout, stderr)=p.communicate()
  if debug: print "stdout: %s\t stderr: %s"%(stdout, stderr)
  return (stdout, stderr)


def main():
  (options, args) = parse_args()
  id = args[0]
  if options.set != "-1":
    dwords = options.set
    exec_cmd("vme_write e0%s2114 3" % id, "Setting Address for write of 3 (dwords config)")
    exec_cmd("vme_write e0%s2118 %s" % (id, dwords), "Setting dwords data")
    exec_cmd("vme_write e0%s70b4 2" % id, "Do OP fastregister")
    
  if options.sourceid != "-1":
    sourceid = options.sourceid
    exec_cmd("vme_write e0%s2114 2" % id, "Setting Address for write of 2 (sourceid config)")
    exec_cmd("vme_write e0%s2118 %s" % (id, sourceid), "Setting sourceid data")
    exec_cmd("vme_write e0%s70b4 2" % id, "Do OP fastregister")

if __name__ == "__main__":
  main()
