#!/bin/bash
# program serial numbers in AMCs mounted in Gandalf with named hexid
# works only with VXS gimli


if [ $# -lt 3 ]
then
  echo 'usage: '$0' <HEXID> <SN_AMC_UP> <SN_AMC_DOWN> (type in hexid of the Gandalf, the AMCs are mounted in, and then the serial numbers 
(as integer) you want to program, first upper card then lower card)'
  exit
else
  hexid=$1
  sn_amc_up=$(printf %.4x $2)
  sn_amc_down=$(printf %.4x $3)
fi
echo "programming AMCs in Gandalf with hexid $hexid with following serial numbers: up $2, down  $3"
#gansm3 /sc/gandalf/binfiles/setdac_VXS.bin /sc/gandalf/binfiles/gandalf_mem_2009 $hexid
vme_write E0$(echo $hexid)2000 0000$sn_amc_up
vme_write E0$(echo $hexid)2400 0000$sn_amc_down
vme_write E0$(echo $hexid)701c 2
sleep 3
vme_write E0$(echo $hexid)7024 2
